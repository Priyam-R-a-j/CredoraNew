import { Opportunity, OpportunityMatchBreakdown, StudentProfile, UserSkill, CareerPath } from '../types';

export function calculateOpportunityMatch(
  opportunity: Opportunity,
  profile: StudentProfile,
  userSkills: UserSkill[]
): OpportunityMatchBreakdown {
  const userSkillNames = userSkills.map(s => s.name.toLowerCase());
  
  // 1. Skills Matching
  const reqSkills = opportunity.requiredSkills.map(s => s.toLowerCase());
  const prefSkills = opportunity.preferredSkills.map(s => s.toLowerCase());
  
  const matchedReq = opportunity.requiredSkills.filter(s => 
    userSkillNames.some(us => us.includes(s.toLowerCase()) || s.toLowerCase().includes(us))
  );
  
  const missingReq = opportunity.requiredSkills.filter(s => 
    !userSkillNames.some(us => us.includes(s.toLowerCase()) || s.toLowerCase().includes(us))
  );

  const matchedPref = opportunity.preferredSkills.filter(s => 
    userSkillNames.some(us => us.includes(s.toLowerCase()) || s.toLowerCase().includes(us))
  );

  const reqScore = reqSkills.length > 0 ? (matchedReq.length / reqSkills.length) * 80 : 80;
  const prefScore = prefSkills.length > 0 ? (matchedPref.length / prefSkills.length) * 20 : 20;
  const skillsScore = Math.min(100, Math.round(reqScore + prefScore));

  // 2. Education Matching
  const educationScore = opportunity.degreeRequirements.includes(profile.degreeLevel) ? 100 : 75;

  // 3. Experience Matching
  const totalVerifiedEvidence = userSkills.reduce((acc, s) => acc + s.evidence.filter(e => e.verified).length, 0);
  const experienceScore = Math.min(100, Math.round(60 + (totalVerifiedEvidence * 8)));

  // 4. Location Matching
  let locationScore = 80;
  if (opportunity.workMode === 'Remote' || profile.workPreference === 'Remote') {
    locationScore = 100;
  } else if (opportunity.location.toLowerCase().includes(profile.city.toLowerCase()) || 
             opportunity.location.toLowerCase().includes(profile.country.toLowerCase())) {
    locationScore = 95;
  }

  // 5. Eligibility Matching
  const eligibilityScore = (profile.cgpa && profile.cgpa >= 7.5) ? 100 : 85;

  // Overall Weighted Score
  // Skills: 40%, Education: 20%, Experience: 20%, Location: 10%, Eligibility: 10%
  const overallScore = Math.round(
    (skillsScore * 0.40) +
    (educationScore * 0.20) +
    (experienceScore * 0.20) +
    (locationScore * 0.10) +
    (eligibilityScore * 0.10)
  );

  // Reasons & Suggestions
  const matchReasons: string[] = [];
  if (matchedReq.length > 0) {
    matchReasons.push(`You possess ${matchedReq.length} of ${opportunity.requiredSkills.length} required skills, including ${matchedReq.slice(0, 2).join(', ')}.`);
  }
  if (opportunity.degreeRequirements.includes(profile.degreeLevel)) {
    matchReasons.push(`Your enrolled degree (${profile.degreeLevel} in ${profile.major}) directly satisfies institutional requirements.`);
  }
  if (locationScore >= 95) {
    matchReasons.push(`Preferred location & ${opportunity.workMode} work arrangement match your preferences.`);
  }

  const improvementSuggestions: string[] = [];
  if (missingReq.length > 0) {
    improvementSuggestions.push(`Acquire or add verified evidence for ${missingReq.slice(0, 3).join(', ')} to boost match probability.`);
  }
  if (totalVerifiedEvidence < 4) {
    improvementSuggestions.push(`Attach additional project repositories or credentials to your skill map.`);
  }

  return {
    overallScore,
    skillsScore,
    educationScore,
    experienceScore,
    locationScore,
    eligibilityScore,
    matchedSkills: [...matchedReq, ...matchedPref],
    missingSkills: missingReq,
    matchReasons,
    improvementSuggestions
  };
}

export function calculatePlacementReadiness(profile: StudentProfile, skills: UserSkill[]): {
  overallScore: number;
  technicalReadiness: number;
  evidenceStrength: number;
  profileCompleteness: number;
  strengths: string[];
  gaps: string[];
  actionItems: string[];
} {
  const verifiedSkillsCount = skills.filter(s => s.verified).length;
  const totalEvidenceCount = skills.reduce((acc, s) => acc + s.evidence.length, 0);
  const verifiedEvidenceCount = skills.reduce((acc, s) => acc + s.evidence.filter(e => e.verified).length, 0);

  // Sub-scores
  const technicalReadiness = Math.min(100, Math.round((verifiedSkillsCount / 6) * 100));
  const evidenceStrength = Math.min(100, Math.round((verifiedEvidenceCount / 5) * 100));
  const profileCompleteness = profile.profileCompletionPercentage;

  const overallScore = Math.round(
    (technicalReadiness * 0.45) +
    (evidenceStrength * 0.35) +
    (profileCompleteness * 0.20)
  );

  const strengths: string[] = [];
  const gaps: string[] = [];
  const actionItems: string[] = [];

  if (verifiedSkillsCount >= 4) {
    strengths.push(`Strong core verified competencies across ${skills.slice(0, 3).map(s => s.name).join(', ')}.`);
  }
  if (profile.cgpa && profile.cgpa >= 8.0) {
    strengths.push(`High academic standing (${profile.cgpa} CGPA) qualifying for elite tier placement tracks.`);
  }
  if (verifiedEvidenceCount >= 4) {
    strengths.push('Multiple validated project repositories and university course assessments.');
  }

  // Identify gaps
  const missingCore = ['Data Structures & Algorithms', 'Distributed Systems', 'SQL & Relational Databases']
    .filter(req => !skills.some(s => s.name.toLowerCase().includes(req.toLowerCase()) && s.level !== 'Beginner'));
  
  if (missingCore.length > 0) {
    gaps.push(`Missing advanced evidence in: ${missingCore.join(', ')}.`);
    actionItems.push(`Complete a verified project or assessment in ${missingCore[0]}.`);
  }

  if (profile.verification.status !== 'Verified') {
    gaps.push('Institutional identity verification not finalized.');
    actionItems.push('Complete university email and student identity verification.');
  }

  actionItems.push('Target 2 active university-industry capstone project applications.');

  return {
    overallScore,
    technicalReadiness,
    evidenceStrength,
    profileCompleteness,
    strengths: strengths.length > 0 ? strengths : ['Active learning trajectory in computer engineering'],
    gaps: gaps.length > 0 ? gaps : ['Maintain continuous test coverage in active projects'],
    actionItems
  };
}

export function calculateCareerFit(
  career: CareerPath,
  userSkills: UserSkill[]
): {
  fitScore: number;
  matchingCoreSkills: string[];
  missingCoreSkills: string[];
  whyItMatches: string[];
  whatToImprove: string[];
} {
  const userSkillNames = userSkills.map(s => s.name.toLowerCase());
  
  const matchingCoreSkills = career.requiredCoreSkills.filter(req => 
    userSkillNames.some(us => us.includes(req.toLowerCase()) || req.toLowerCase().includes(us))
  );

  const missingCoreSkills = career.requiredCoreSkills.filter(req => 
    !userSkillNames.some(us => us.includes(req.toLowerCase()) || req.toLowerCase().includes(us))
  );

  const fitScore = Math.min(100, Math.round(
    ((matchingCoreSkills.length / career.requiredCoreSkills.length) * 80) + 15
  ));

  const whyItMatches = [
    `You have mastered ${matchingCoreSkills.length} of ${career.requiredCoreSkills.length} foundational skills for this pathway.`,
    `High industry demand index (${career.industryDemandScore}/100) across top ${career.industry} employers.`
  ];

  const whatToImprove = missingCoreSkills.map(skill => 
    `Build an evidence-backed project or complete an assessment in "${skill}".`
  );

  return {
    fitScore,
    matchingCoreSkills,
    missingCoreSkills,
    whyItMatches,
    whatToImprove
  };
}
