import { IndustryPulseMetric } from '../types';

export const INDUSTRY_PULSE_DATA: IndustryPulseMetric[] = [
  {
    id: 'ip-1',
    skillOrRole: 'Generative AI Engineering & RAG Systems',
    category: 'Skill',
    industry: 'Technology',
    growthRatePercent: 148,
    openPositionsEstimated: 14200,
    demandIndex: 'Critical Demand',
    topHiringCompanies: ['Google / Alphabet', 'Microsoft', 'NVIDIA', 'Amazon', 'Meta'],
    source: 'SkillOrbit Aggregated Global Tech Hiring Index',
    dataPeriod: 'Q2 2026 - Q3 2026',
    lastUpdated: '2026-09-07'
  },
  {
    id: 'ip-2',
    skillOrRole: 'Distributed Systems & Low-Latency C++',
    category: 'Skill',
    industry: 'Finance',
    growthRatePercent: 62,
    openPositionsEstimated: 9800,
    demandIndex: 'Surging Demand',
    topHiringCompanies: ['JPMorgan Chase', 'Goldman Sachs', 'Morgan Stanley', 'CME Group'],
    source: 'Global Financial Markets Technology Benchmark',
    dataPeriod: 'Q2 2026 - Q3 2026',
    lastUpdated: '2026-09-07'
  },
  {
    id: 'ip-3',
    skillOrRole: 'Technology Strategy & Enterprise AI Transformation',
    category: 'Role',
    industry: 'Consulting',
    growthRatePercent: 84,
    openPositionsEstimated: 8400,
    demandIndex: 'Surging Demand',
    topHiringCompanies: ['McKinsey & Company', 'Boston Consulting Group (BCG)', 'Deloitte', 'Accenture'],
    source: 'Management Consulting Talent Outlook 2026',
    dataPeriod: 'H1 2026',
    lastUpdated: '2026-09-06'
  },
  {
    id: 'ip-4',
    skillOrRole: 'Cloud Native Orchestration (Kubernetes & Istio)',
    category: 'Skill',
    industry: 'Technology',
    growthRatePercent: 54,
    openPositionsEstimated: 21500,
    demandIndex: 'High Demand',
    topHiringCompanies: ['Amazon', 'Microsoft', 'ServiceNow', 'Cisco Systems', 'Infosys'],
    source: 'Cloud Native Computing Talent Survey',
    dataPeriod: 'Q2 2026',
    lastUpdated: '2026-09-05'
  },
  {
    id: 'ip-5',
    skillOrRole: 'Quantitative Credit & Risk Modeling',
    category: 'Skill',
    industry: 'Finance',
    growthRatePercent: 47,
    openPositionsEstimated: 7300,
    demandIndex: 'High Demand',
    topHiringCompanies: ['HDFC Bank', 'ICICI Bank', 'BlackRock', 'Bajaj Finance', 'State Bank of India (SBI)'],
    source: 'Reserve & Retail Banking Analytics Report',
    dataPeriod: 'Q2 2026',
    lastUpdated: '2026-09-06'
  },
  {
    id: 'ip-6',
    skillOrRole: 'Zero-Trust Cybersecurity & Cloud Identity',
    category: 'Specialization',
    industry: 'Technology',
    growthRatePercent: 71,
    openPositionsEstimated: 16800,
    demandIndex: 'Critical Demand',
    topHiringCompanies: ['Cisco Systems', 'IBM', 'PwC', 'Tata Consultancy Services (TCS)', 'Google / Alphabet'],
    source: 'Enterprise Information Security Index',
    dataPeriod: 'Q2 2026 - Q3 2026',
    lastUpdated: '2026-09-07'
  }
];
