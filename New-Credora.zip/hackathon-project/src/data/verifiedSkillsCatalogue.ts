import { 
  SkillVerificationCatalogueItem, 
  UserVerifiedSkill, 
  AssessmentOpportunity 
} from '../types/verifiedSkills';

export const SKILL_VERIFICATION_CATALOGUE: SkillVerificationCatalogueItem[] = [
  // Programming Languages
  {
    id: 'vsk-python',
    name: 'Python',
    iconEmoji: '🐍',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Demonstrates knowledge of Python programming, core data models, object-oriented concepts, asynchronous programming, problem-solving, practical coding, and debugging.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Iterators, Generators, Decorators & Metaclasses',
      'Data Structures & Time Complexities',
      'AsyncIO, Multiprocessing & Concurrency',
      'Memory Management & Garbage Collection',
      'Practical Scripting & Algorithm Implementation'
    ],
    activeTestCentersCount: 14,
    nextScheduledDate: 'October 5, 2026'
  },
  {
    id: 'vsk-cpp',
    name: 'C++',
    iconEmoji: '⚡',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Validates rigorous memory management, modern C++ (C++17/C++20), RAII, STL algorithms, move semantics, multithreading, and low-latency systems optimization.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Pointers, References & Smart Pointers (unique_ptr, shared_ptr)',
      'Template Metaprogramming & Concepts',
      'STL Containers, Iterators & Custom Allocators',
      'Concurrency & Memory Models (std::atomic, std::mutex)',
      'Memory Profiling & Cache Locality'
    ],
    activeTestCentersCount: 12,
    nextScheduledDate: 'October 12, 2026'
  },
  {
    id: 'vsk-c',
    name: 'C',
    iconEmoji: '⚙️',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates low-level systems programming, manual memory management, pointer arithmetic, bitwise manipulations, and POSIX system call integrations.',
    structure: {
      fundamentalsPercent: 25,
      problemSolvingPercent: 25,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Pointer Arithmetic & Dynamic Memory (malloc, calloc, free)',
      'Struct Padding, Memory Alignment & Bit Fields',
      'POSIX Threads (pthreads) & Inter-Process Communication',
      'GDB Debugging & Valgrind Leak Elimination'
    ],
    activeTestCentersCount: 10,
    nextScheduledDate: 'October 19, 2026'
  },
  {
    id: 'vsk-java',
    name: 'Java',
    iconEmoji: '☕',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates enterprise Java, JVM internals, garbage collection tuning, concurrent programming, functional streams, and robust object-oriented system design.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'JVM Architecture (ClassLoader, JIT Compiler, GC Algorithms)',
      'Collections Framework & Concurrent Collections',
      'Java Memory Model (JMM), Volatile & Synchronized',
      'Streams API & Functional Interfaces',
      'Unit Testing with JUnit 5 & Mockito'
    ],
    activeTestCentersCount: 15,
    nextScheduledDate: 'October 24, 2026'
  },
  {
    id: 'vsk-javascript',
    name: 'JavaScript',
    iconEmoji: '🟨',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Assesses modern ES6+ runtime mechanics, event loop, closures, prototypal inheritance, asynchronous promise chains, and DOM/Node.js execution profiling.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Event Loop, Microtasks & Macrotasks',
      'Prototypal Inheritance & Scoping Chain',
      'Promises, Async/Await & Error Propagation',
      'Functional Programming & Immutability Patterns'
    ],
    activeTestCentersCount: 14,
    nextScheduledDate: 'November 2, 2026'
  },
  {
    id: 'vsk-csharp',
    name: 'C#',
    iconEmoji: '🔷',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Tests proficiency in .NET Core runtime, LINQ expressions, asynchronous Task patterns, memory efficiency with Span<T>, and clean C# architectural idioms.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      '.NET CLR & Garbage Collection Lifecycles',
      'Advanced LINQ Queries & Expression Trees',
      'Async/Await State Machines',
      'Memory Allocation Optimization with Memory<T> and Span<T>'
    ],
    activeTestCentersCount: 8,
    nextScheduledDate: 'November 8, 2026'
  },
  {
    id: 'vsk-go',
    name: 'Go',
    iconEmoji: '🐹',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Validates idiomatic Go, goroutines, channels, context cancellation, memory escape analysis, and high-performance cloud microservice implementations.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Goroutines, Channels & Select Concurrency',
      'Interfaces, Composition & Type Assertions',
      'Context Propagation & Timeout Management',
      'Benchmarking & Memory Profiling (pprof)'
    ],
    activeTestCentersCount: 9,
    nextScheduledDate: 'November 15, 2026'
  },
  {
    id: 'vsk-rust',
    name: 'Rust',
    iconEmoji: '🦀',
    category: 'Programming Languages',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates borrow checker mastery, ownership, lifetimes, fearless concurrency, zero-cost abstractions, unsafe blocks, and systems safety.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Ownership, Move Semantics & Borrow Checker',
      'Explicit Lifetimes & Struct Lifetime Annotations',
      'Traits, Generics & Dynamic Dispatch',
      'Concurrency with Rayon & Tokio Asynchronous Runtime'
    ],
    activeTestCentersCount: 7,
    nextScheduledDate: 'November 22, 2026'
  },

  // Web Development
  {
    id: 'vsk-react',
    name: 'React',
    iconEmoji: '⚛️',
    category: 'Web Development',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Demonstrates deep knowledge of component composition, React reconciliation fiber engine, custom hooks, state synchronization, and render optimization.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Virtual DOM, Reconciliation & Fiber Tree Mechanics',
      'Custom Hooks & Closure Bug Prevention',
      'State Management Strategies & Context Memoization',
      'React 19 Actions, Server Components & Suspense Boundaries'
    ],
    activeTestCentersCount: 16,
    nextScheduledDate: 'October 16, 2026'
  },
  {
    id: 'vsk-node',
    name: 'Node.js',
    iconEmoji: '🟢',
    category: 'Web Development',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates backend Node.js performance, libuv event loop phases, Streams & Buffers, cluster scaling, and production HTTP server development.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Libuv Thread Pool & Event Loop Phases',
      'Node.js Streams (Readable, Writable, Transform) & Backpressure',
      'Worker Threads & Child Processes for Heavy Compute',
      'Secure Authentication, Rate Limiting & REST API Architecture'
    ],
    activeTestCentersCount: 13,
    nextScheduledDate: 'October 28, 2026'
  },
  {
    id: 'vsk-html',
    name: 'HTML',
    iconEmoji: '🌐',
    category: 'Web Development',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 1.5 Hours',
    description: 'Tests semantic HTML5 markup, WCAG 2.2 accessibility standards, ARIA roles, form validations, SEO optimization, and browser parsing standards.',
    structure: {
      fundamentalsPercent: 30,
      problemSolvingPercent: 20,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Semantic Structure & Document Outlines',
      'ARIA Specifications & Screen Reader Compliance',
      'Form Validation API & Custom Input Elements',
      'Microdata, OpenGraph & Structured Metadata'
    ],
    activeTestCentersCount: 15,
    nextScheduledDate: 'November 4, 2026'
  },
  {
    id: 'vsk-css',
    name: 'CSS',
    iconEmoji: '🎨',
    category: 'Web Development',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Validates modern CSS layout engines (Flexbox, Grid), responsive fluid design, container queries, CSS variables, cascade specificity, and animations.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 25,
      practicalCodingPercent: 45,
      debuggingPercent: 10
    },
    curriculum: [
      'CSS Grid Layouts & Subgrid Specifications',
      'Container Queries & Fluid Typography Scales',
      'Cascade Layers (@layer) & Specificity Calculation',
      'Hardware-Accelerated Transitions & Keyframe Animations'
    ],
    activeTestCentersCount: 14,
    nextScheduledDate: 'November 11, 2026'
  },
  {
    id: 'vsk-angular',
    name: 'Angular',
    iconEmoji: '🅰️',
    category: 'Web Development',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Tests enterprise Angular, RxJS reactive pipelines, dependency injection, routing guards, signals, and modular architectural standards.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Signals & Fine-Grained Reactivity',
      'RxJS Operators (switchMap, exhaustMap, combineLatest)',
      'Hierarchical Dependency Injection & Tree-Shakable Services',
      'OnPush Change Detection Strategy'
    ],
    activeTestCentersCount: 8,
    nextScheduledDate: 'November 18, 2026'
  },

  // Databases
  {
    id: 'vsk-sql',
    name: 'SQL',
    iconEmoji: '🗄️',
    category: 'Databases',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates advanced ANSI SQL, complex window functions, recursive CTEs, indexing strategies (B-Tree, Hash), transaction isolation, and query plan optimization.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Window Functions (ROW_NUMBER, DENSE_RANK, NTILE, LAG/LEAD)',
      'Recursive Common Table Expressions (CTEs)',
      'ACID Guarantees & Transaction Isolation Anomalies',
      'EXPLAIN ANALYZE & Query Optimization Strategies'
    ],
    activeTestCentersCount: 16,
    nextScheduledDate: 'October 9, 2026'
  },
  {
    id: 'vsk-mysql',
    name: 'MySQL',
    iconEmoji: '🐬',
    category: 'Databases',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Focuses on MySQL InnoDB engine architecture, redo/undo logging, locking mechanisms, composite index tuning, and replication topology.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'InnoDB Buffer Pool, Redo Log & Doublewrite Buffer',
      'Row-Level Locking (Record, Gap, Next-Key Locks)',
      'Multi-Source Replication & GTID Synchronization',
      'Partitioning & Index Selectivity Tuning'
    ],
    activeTestCentersCount: 11,
    nextScheduledDate: 'October 21, 2026'
  },
  {
    id: 'vsk-postgresql',
    name: 'PostgreSQL',
    iconEmoji: '🐘',
    category: 'Databases',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates advanced Postgres features: JSONB indexing (GIN/GiST), MVCC mechanics, VACUUM tuning, foreign data wrappers, and PL/pgSQL procedures.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Multi-Version Concurrency Control (MVCC) & Heap Organization',
      'GIN, GiST & BRIN Index Selection for High Volume',
      'JSONB Queries, Functions & Partial Indexes',
      'Connection Pooling (PgBouncer) & WAL Archiving'
    ],
    activeTestCentersCount: 12,
    nextScheduledDate: 'October 30, 2026'
  },
  {
    id: 'vsk-mongodb',
    name: 'MongoDB',
    iconEmoji: '🍃',
    category: 'Databases',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Assesses document schema modeling, aggregation framework pipelines, WiredTiger storage engine, replica set elections, and sharding strategies.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Aggregation Framework ($facet, $lookup, $unwind, $graphLookup)',
      'Schema Design: Embedding vs Referencing Strategies',
      'Replica Sets, Raft Consensus & Write Concerns (w:majority)',
      'Sharded Cluster Topology & Shard Key Selection'
    ],
    activeTestCentersCount: 10,
    nextScheduledDate: 'November 6, 2026'
  },

  // Core Computer Science
  {
    id: 'vsk-dsa',
    name: 'Data Structures & Algorithms',
    iconEmoji: '🌳',
    category: 'Core Computer Science',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2.5 Hours',
    description: 'Comprehensive evaluation of advanced data structures, graph traversals, dynamic programming, greedy algorithms, divide-and-conquer, and algorithmic complexity proofs.',
    structure: {
      fundamentalsPercent: 15,
      problemSolvingPercent: 35,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Trees & Graphs: Segment Trees, Fenwick Trees, Tarjan & Dijkstra',
      'Dynamic Programming: Memoization, Tabulation & Bitmask DP',
      'String Algorithms: KMP, Rabin-Karp, Z-Algorithm & Tries',
      'Amortized Analysis & Formal Big-O Complexity Proofs'
    ],
    activeTestCentersCount: 18,
    nextScheduledDate: 'October 7, 2026'
  },
  {
    id: 'vsk-oop',
    name: 'Object-Oriented Programming',
    iconEmoji: '🧱',
    category: 'Core Computer Science',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Validates mastery of encapsulation, inheritance, polymorphism, abstraction, SOLID architectural principles, and Gang of Four (GoF) design patterns.',
    structure: {
      fundamentalsPercent: 25,
      problemSolvingPercent: 25,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'SOLID Principles in Production Codebases',
      'Creational Patterns (Singleton, Factory, Builder)',
      'Structural & Behavioral Patterns (Adapter, Strategy, Observer, Decorator)',
      'Coupling vs Cohesion Tradeoffs in Large Systems'
    ],
    activeTestCentersCount: 14,
    nextScheduledDate: 'October 14, 2026'
  },
  {
    id: 'vsk-os',
    name: 'Operating Systems',
    iconEmoji: '🖥️',
    category: 'Core Computer Science',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Tests deep understanding of process scheduling, virtual memory, paging, thrashing, deadlocks (Banker algorithm), file systems, and kernel privilege rings.',
    structure: {
      fundamentalsPercent: 30,
      problemSolvingPercent: 25,
      practicalCodingPercent: 35,
      debuggingPercent: 10
    },
    curriculum: [
      'CPU Scheduling Algorithms & Context Switch Overhead',
      'Virtual Memory Management: TLB, Multi-Level Page Tables & Inverted Tables',
      'Synchronization Primitives: Semaphores, Mutexes, Spinlocks & Monitors',
      'Deadlock Prevention, Detection & Avoidance Algorithms'
    ],
    activeTestCentersCount: 13,
    nextScheduledDate: 'October 26, 2026'
  },
  {
    id: 'vsk-dbms',
    name: 'Database Management Systems',
    iconEmoji: '💾',
    category: 'Core Computer Science',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Validates theoretical foundations of relational algebra, normalization up to BCNF/4NF, serializability schedules, two-phase locking, and write-ahead logging.',
    structure: {
      fundamentalsPercent: 30,
      problemSolvingPercent: 25,
      practicalCodingPercent: 35,
      debuggingPercent: 10
    },
    curriculum: [
      'Relational Algebra & Tuple Relational Calculus',
      'Functional Dependencies, Normalization (1NF, 2NF, 3NF, BCNF)',
      'Conflict & View Serializability Testing',
      'Concurrency Control: Strict 2PL, Timestamp Ordering & Recovery (ARIES)'
    ],
    activeTestCentersCount: 13,
    nextScheduledDate: 'November 9, 2026'
  },

  // Emerging Technologies
  {
    id: 'vsk-ai',
    name: 'Artificial Intelligence',
    iconEmoji: '🤖',
    category: 'Emerging Technologies',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Evaluates search heuristics (A*, Minimax, Alpha-Beta pruning), constraint satisfaction problems, probabilistic reasoning, and knowledge graph representations.',
    structure: {
      fundamentalsPercent: 25,
      problemSolvingPercent: 30,
      practicalCodingPercent: 35,
      debuggingPercent: 10
    },
    curriculum: [
      'Informed Search Heuristics & Admissibility Criteria',
      'Adversarial Search & Game Playing (Alpha-Beta Pruning)',
      'Bayesian Networks & Markov Decision Processes (MDPs)',
      'Reinforcement Learning Fundamentals (Q-Learning, Policy Gradients)'
    ],
    activeTestCentersCount: 11,
    nextScheduledDate: 'October 17, 2026'
  },
  {
    id: 'vsk-ml',
    name: 'Machine Learning',
    iconEmoji: '🧠',
    category: 'Emerging Technologies',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Tests mathematical derivations, supervised/unsupervised algorithms, gradient descent optimization, regularization, feature engineering, and model evaluation metrics.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Loss Functions & Backpropagation Derivations',
      'Ensemble Methods (Random Forests, XGBoost, LightGBM)',
      'Dimensionality Reduction (PCA, t-SNE, UMAP)',
      'Cross-Validation, Bias-Variance Tradeoff & ROC-AUC Metrics'
    ],
    activeTestCentersCount: 12,
    nextScheduledDate: 'October 23, 2026'
  },
  {
    id: 'vsk-cloud',
    name: 'Cloud Computing',
    iconEmoji: '☁️',
    category: 'Emerging Technologies',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Assesses cloud infrastructure design, 12-factor apps, containerization (Docker), Kubernetes primitives, serverless architectures, and reliable distributed networking.',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'Virtualization, Hypervisors & Container Isolation (cgroups, namespaces)',
      'Kubernetes Architecture: Pods, Services, Ingress, Deployments & StatefulSets',
      'Serverless Compute & Event-Driven Architecture (EventBridge, SQS, Kafka)',
      'High Availability, Disaster Recovery & Multi-Region Resiliency'
    ],
    activeTestCentersCount: 10,
    nextScheduledDate: 'November 13, 2026'
  },
  {
    id: 'vsk-cybersecurity',
    name: 'Cybersecurity',
    iconEmoji: '🛡️',
    category: 'Emerging Technologies',
    verificationStatus: 'Assessment Available',
    assessmentDuration: 'Approximately 2 Hours',
    description: 'Demonstrates defensive and offensive security principles, OWASP Top 10 vulnerabilities, asymmetric cryptography, TLS handshakes, and network packet analysis.',
    structure: {
      fundamentalsPercent: 25,
      problemSolvingPercent: 25,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    },
    curriculum: [
      'OWASP Top 10 Mitigations (SQLi, XSS, CSRF, SSRF, IDOR)',
      'Cryptography: RSA, ECC, AES-GCM, Diffie-Hellman Key Exchange',
      'Authentication Protocols: OAuth 2.0, OpenID Connect, JWT Security',
      'Penetration Testing Methodology & Threat Modeling (STRIDE)'
    ],
    activeTestCentersCount: 9,
    nextScheduledDate: 'November 20, 2026'
  }
];

export const INITIAL_USER_VERIFIED_SKILLS: UserVerifiedSkill[] = [
  {
    id: 'uvs-1',
    skillId: 'vsk-python',
    skillName: 'Python',
    iconEmoji: '🐍',
    category: 'Programming Languages',
    status: 'Professionally-Verified',
    proficiencyLevel: 'Advanced',
    score: 847,
    maxScore: 1000,
    percentileRank: 93.4,
    dateAdded: '2026-08-10',
    assessmentDate: 'October 5, 2026',
    credentialId: 'VS-PY-2026-89214',
    verificationExpiryDate: 'October 5, 2028'
  },
  {
    id: 'uvs-2',
    skillId: 'vsk-dsa',
    skillName: 'Data Structures & Algorithms',
    iconEmoji: '🌳',
    category: 'Core Computer Science',
    status: 'Professionally-Verified',
    proficiencyLevel: 'Advanced',
    score: 912,
    maxScore: 1000,
    percentileRank: 97.8,
    dateAdded: '2026-07-15',
    assessmentDate: 'September 18, 2026',
    credentialId: 'VS-DSA-2026-77341',
    verificationExpiryDate: 'September 18, 2028'
  },
  {
    id: 'uvs-3',
    skillId: 'vsk-cpp',
    skillName: 'C++',
    iconEmoji: '⚡',
    category: 'Programming Languages',
    status: 'Assessment-Scheduled',
    currentPhaseStep: 3,
    dateAdded: '2026-08-20',
    scheduledDate: 'October 12, 2026',
    reportingTime: '09:00 AM',
    testCenter: 'Manipal University Jaipur - High-Performance Computing Lab 3',
    seatNumber: 'A-124',
    admitCard: {
      verificationId: 'VS-2026-92814',
      candidateName: 'Aarav Sharma',
      candidateEmail: 'student@jaipur.manipal.edu',
      institutionName: 'Manipal University Jaipur (MUJ)',
      rollNumber: '239103049',
      skillName: 'C++ Systems Programming',
      iconEmoji: '⚡',
      assessmentDate: 'October 12, 2026',
      reportingTime: '9:00 AM',
      duration: '2 Hours (09:30 AM – 11:30 AM)',
      assignedTestCenter: 'Manipal University Jaipur - High-Performance Computing Lab 3',
      centerAddress: 'Dehmi Kalan, Jaipur-Ajmer Expressway, Academic Block 2, Ground Floor Lab 003',
      seatNumber: 'A-124',
      roomNumber: 'AB2-G03',
      qrCodeToken: 'MUJ-VERIF-VS-2026-92814-CPP-A124',
      instructions: [
        'Mandatory physical reporting time is 09:00 AM sharp. Entry gates will lock at 09:20 AM.',
        'Candidates must bring their original University Student ID Card and this printed or digital Admit Card.',
        'No external electronic devices, USB keys, smartwatches, or personal notebooks permitted in the examination terminal hall.',
        'Assessment terminal will be booted in controlled secure proctored sandbox with dual-monitor screen capture.'
      ]
    }
  },
  {
    id: 'uvs-4',
    skillId: 'vsk-sql',
    skillName: 'SQL',
    iconEmoji: '🗄️',
    category: 'Databases',
    status: 'Verification-Registered',
    currentPhaseStep: 2,
    dateAdded: '2026-08-28',
    scheduledDate: 'November 2, 2026',
    reportingTime: '10:00 AM',
    testCenter: 'MUJ Central Computing Center, Cluster B'
  },
  {
    id: 'uvs-5',
    skillId: 'vsk-java',
    skillName: 'Java',
    iconEmoji: '☕',
    category: 'Programming Languages',
    status: 'Self-Declared',
    dateAdded: '2026-08-01'
  },
  {
    id: 'uvs-6',
    skillId: 'vsk-react',
    skillName: 'React',
    iconEmoji: '⚛️',
    category: 'Web Development',
    status: 'Self-Declared',
    dateAdded: '2026-08-05'
  }
];

export const UPCOMING_ASSESSMENTS: AssessmentOpportunity[] = [
  {
    id: 'assm-1',
    skillId: 'vsk-python',
    skillName: 'Python Skill Verification Assessment',
    iconEmoji: '🐍',
    category: 'Programming Languages',
    assessmentDate: 'October 5, 2026',
    registrationDeadline: 'October 1, 2026',
    reportingTime: '09:00 AM',
    duration: '2 Hours',
    availability: 'Registration Open',
    seatsRemaining: 42,
    totalSeats: 120,
    testCenterName: 'Authorized Institutional Center – MUJ Lab 1 & 2',
    testCenterLocation: 'Jaipur, Rajasthan',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  },
  {
    id: 'assm-2',
    skillId: 'vsk-cpp',
    skillName: 'C++ Systems Engineering Assessment',
    iconEmoji: '⚡',
    category: 'Programming Languages',
    assessmentDate: 'October 12, 2026',
    registrationDeadline: 'October 8, 2026',
    reportingTime: '09:00 AM',
    duration: '2 Hours',
    availability: 'Fast Filling',
    seatsRemaining: 14,
    totalSeats: 90,
    testCenterName: 'High-Performance Computing Lab 3',
    testCenterLocation: 'Jaipur, Rajasthan',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  },
  {
    id: 'assm-3',
    skillId: 'vsk-dsa',
    skillName: 'Data Structures & Algorithms Benchmarking Drive',
    iconEmoji: '🌳',
    category: 'Core Computer Science',
    assessmentDate: 'October 15, 2026',
    registrationDeadline: 'October 10, 2026',
    reportingTime: '01:30 PM',
    duration: '2.5 Hours',
    availability: 'Registration Open',
    seatsRemaining: 68,
    totalSeats: 150,
    testCenterName: 'National Examination Hub, Sector 62',
    testCenterLocation: 'Noida / NCR',
    structure: {
      fundamentalsPercent: 15,
      problemSolvingPercent: 35,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  },
  {
    id: 'assm-4',
    skillId: 'vsk-sql',
    skillName: 'Enterprise SQL & Query Optimization Evaluation',
    iconEmoji: '🗄️',
    category: 'Databases',
    assessmentDate: 'November 2, 2026',
    registrationDeadline: 'October 27, 2026',
    reportingTime: '10:00 AM',
    duration: '2 Hours',
    availability: 'Registration Open',
    seatsRemaining: 55,
    totalSeats: 100,
    testCenterName: 'MUJ Central Computing Center, Cluster B',
    testCenterLocation: 'Jaipur, Rajasthan',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  },
  {
    id: 'assm-5',
    skillId: 'vsk-react',
    skillName: 'Modern Frontend Architecture & React 19 Practical',
    iconEmoji: '⚛️',
    category: 'Web Development',
    assessmentDate: 'November 5, 2026',
    registrationDeadline: 'October 30, 2026',
    reportingTime: '02:00 PM',
    duration: '2 Hours',
    availability: 'Limited Seats',
    seatsRemaining: 8,
    totalSeats: 60,
    testCenterName: 'Software Engineering Innovation Lab',
    testCenterLocation: 'Bengaluru, Karnataka',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  },
  {
    id: 'assm-6',
    skillId: 'vsk-ml',
    skillName: 'Applied Machine Learning & Model Engineering Exam',
    iconEmoji: '🧠',
    category: 'Emerging Technologies',
    assessmentDate: 'November 12, 2026',
    registrationDeadline: 'November 6, 2026',
    reportingTime: '09:30 AM',
    duration: '2 Hours',
    availability: 'Registration Open',
    seatsRemaining: 40,
    totalSeats: 80,
    testCenterName: 'AI & Robotics Center of Excellence',
    testCenterLocation: 'Hyderabad, Telangana',
    structure: {
      fundamentalsPercent: 20,
      problemSolvingPercent: 30,
      practicalCodingPercent: 40,
      debuggingPercent: 10
    }
  }
];
