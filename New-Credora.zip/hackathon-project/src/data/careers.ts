import { CareerPath } from '../types';

export const CAREER_PATHS_DATA: CareerPath[] = [
  {
    id: 'car-swe',
    title: 'Software Engineer (Distributed Systems & Backend)',
    industry: 'Technology',
    summary: 'Design, implement, and maintain scalable, reliable, and fault-tolerant server-side systems and infrastructure.',
    averageStartingSalary: '₹18,00,000 - ₹32,00,000 / year ($130,000 - $175,000 in US)',
    growthOutlook: 'Very High',
    requiredCoreSkills: ['Data Structures & Algorithms', 'C++', 'Java', 'Python', 'SQL & Relational Databases', 'Distributed Systems'],
    recommendedSecondarySkills: ['Docker & Kubernetes', 'CI/CD & Git', 'Redis & In-Memory Caching', 'Linux Systems & Shell'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'Foundations (Year 1-2)',
        title: 'Algorithmic Mastery & Core Systems',
        description: 'Build profound fluency in asymptotic complexity, memory management, and clean object-oriented architecture.',
        keyDeliverables: ['300+ solved algorithmic challenges', '2 full-stack functional projects with unit tests']
      },
      {
        step: 2,
        phase: 'Systems Engineering (Year 2-3)',
        title: 'Distributed Storage & Concurrency',
        description: 'Implement distributed consensus algorithms (Raft), message queues (Kafka), and caching tiers.',
        keyDeliverables: ['Open-source contribution to an engineering library', 'University or enterprise-sponsored capstone']
      },
      {
        step: 3,
        phase: 'Industry Placement (Year 3-4)',
        title: 'High-Scale Internship & Production Delivery',
        description: 'Deliver features into live production services with automated telemetry, latency monitoring, and zero-downtime deploys.',
        keyDeliverables: ['Summer Software Engineering Internship', 'SkillOrbit Level 4 Verified Assessment']
      }
    ],
    industryDemandScore: 95
  },
  {
    id: 'car-ai-engineer',
    title: 'Machine Learning & AI Systems Engineer',
    industry: 'Technology',
    summary: 'Develop, optimize, and serve large neural architectures, foundation models, and real-time inference pipelines.',
    averageStartingSalary: '₹22,00,000 - ₹38,00,000 / year ($140,000 - $190,000 in US)',
    growthOutlook: 'Very High',
    requiredCoreSkills: ['Python', 'PyTorch & Deep Learning', 'Large Language Models & GenAI', 'Data Structures & Algorithms', 'SQL & Relational Databases'],
    recommendedSecondarySkills: ['C++', 'Docker & Kubernetes', 'ETL Pipelines & Spark', 'Computer Vision'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'Mathematical Foundations',
        title: 'Linear Algebra, Probability & Python Numerics',
        description: 'Master matrix decompositions, gradient descent mechanics, and vectorized NumPy/PyTorch operations.',
        keyDeliverables: ['Custom backpropagation engine implemented from scratch', 'Deep Learning Specialization certificate']
      },
      {
        step: 2,
        phase: 'Foundation Models & Fine-Tuning',
        title: 'Transformers, LoRA & RAG Architectures',
        description: 'Train and fine-tune domain-specific LLMs with quantization (bitsandbytes), vector databases, and evaluation metrics.',
        keyDeliverables: ['Production-grade RAG service evaluated with RAGAS', 'Research workshop publication']
      },
      {
        step: 3,
        phase: 'Scale & Inference Optimization',
        title: 'TensorRT, vLLM & Edge Deployment',
        description: 'Profile inference memory footprints, optimize CUDA kernels, and integrate model monitoring.',
        keyDeliverables: ['AI Research Lab Internship / Fellowship', 'Verified portfolio of benchmarked models']
      }
    ],
    industryDemandScore: 98
  },
  {
    id: 'car-quant',
    title: 'Quantitative Researcher & Trading Analyst',
    industry: 'Finance',
    summary: 'Apply mathematical rigor, statistical arbitrage, and machine learning to analyze markets and trade financial assets.',
    averageStartingSalary: '₹35,00,000 - ₹65,00,000 / year ($200,000 - $350,000 in US)',
    growthOutlook: 'High',
    requiredCoreSkills: ['Probability & Statistics', 'Python', 'C++', 'Data Structures & Algorithms', 'Quantitative Finance & Derivatives'],
    recommendedSecondarySkills: ['SQL & Relational Databases', 'Financial Modeling & Valuation', 'Linux Systems & Shell'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'Stochastic Modeling',
        title: 'Rigorous Probability & Statistics',
        description: 'Complete high-level coursework in stochastic calculus, linear regression, hypothesis testing, and statistical estimation.',
        keyDeliverables: ['Top 5% finish in national mathematical Olympiads or competitions', 'Tick data backtesting framework']
      },
      {
        step: 2,
        phase: 'Algorithmic Execution',
        title: 'Low-Latency C++ & Order Book Dynamics',
        description: 'Construct limit order book simulators in modern C++ with nanosecond measurement and lock-free data structures.',
        keyDeliverables: ['Live algorithmic backtest report with Sharpe > 2.0', 'Verified Quant Assessment']
      },
      {
        step: 3,
        phase: 'Desk Placement',
        title: 'Trading Desk Summer Analyst',
        description: 'Collaborate with desk heads and portfolio managers on live alpha generation and systematic execution strategies.',
        keyDeliverables: ['JPMorgan / Goldman Sachs Quantitative Analyst Internship']
      }
    ],
    industryDemandScore: 92
  },
  {
    id: 'car-consultant',
    title: 'Strategy & Management Consultant',
    industry: 'Consulting',
    summary: 'Advise C-suite executives and board members on corporate strategy, digital transformation, mergers & acquisitions, and performance.',
    averageStartingSalary: '₹20,00,000 - ₹34,00,000 / year ($120,000 - $160,000 in US)',
    growthOutlook: 'Steady',
    requiredCoreSkills: ['Business Strategy & Problem Solving', 'Executive Presentation & Storytelling', 'Financial Modeling & Valuation', 'SQL & Relational Databases'],
    recommendedSecondarySkills: ['Agile & Cross-Functional Leadership', 'Technical Writing & Architecture Docs', 'Product Management'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'Analytical Problem Formulation',
        title: 'Hypothesis-Driven Case Structuring',
        description: 'Master MECE frameworks, business case competitions, balance sheet modeling, and market sizing estimation.',
        keyDeliverables: ['Winner / Finalist in top tier inter-university case competitions', '100+ analyzed business cases']
      },
      {
        step: 2,
        phase: 'Industry Specialization',
        title: 'Digital Operations & Value Realization',
        description: 'Formulate technology roadmaps, unit economic turnarounds, and cross-functional change management plans.',
        keyDeliverables: ['Client project under university consulting club', 'Verified consulting case credentials']
      },
      {
        step: 3,
        phase: 'Client Engagement',
        title: 'McKinsey / BCG / Bain Case Team Member',
        description: 'Lead dedicated workstreams, synthesize executive interviews, and deliver decisive strategic recommendations.',
        keyDeliverables: ['Associate Consultant Internship at Tier-1 Management Consultancy']
      }
    ],
    industryDemandScore: 89
  },
  {
    id: 'car-pm',
    title: 'Associate Product Manager (APM)',
    industry: 'Technology',
    summary: 'Lead the intersection of engineering, design, and business to conceptualize and ship products users love.',
    averageStartingSalary: '₹18,00,000 - ₹28,00,000 / year ($110,000 - $150,000 in US)',
    growthOutlook: 'High',
    requiredCoreSkills: ['Product Management', 'Business Strategy & Problem Solving', 'Executive Presentation & Storytelling', 'SQL & Relational Databases'],
    recommendedSecondarySkills: ['Figma & Design Systems', 'User Research & WCAG', 'Agile & Cross-Functional Leadership', 'Python'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'User Empathy & Metrics',
        title: 'Product Teardowns & North Star Analytics',
        description: 'Analyze consumer behavior, evaluate UX frictions, and articulate quantitative product specifications.',
        keyDeliverables: ['3 published product teardowns of real apps', 'Verified SQL database data pull portfolio']
      },
      {
        step: 2,
        phase: '0-to-1 Shipping',
        title: 'Cross-Functional MVP Delivery',
        description: 'Manage engineering sprints, create interactive Figma wireframes, run user usability interviews, and iterate.',
        keyDeliverables: ['Launched side product with 1,000+ real users', 'End-to-end PRD documentation']
      },
      {
        step: 3,
        phase: 'APM Rotation',
        title: 'Enterprise or Consumer APM Cohort',
        description: 'Participate in structured APM cohort programs at leading tech companies driving roadmap bets.',
        keyDeliverables: ['APM Internship or Full-time placement']
      }
    ],
    industryDemandScore: 91
  },
  {
    id: 'car-data-engineer',
    title: 'Data & Analytics Systems Engineer',
    industry: 'Technology',
    summary: 'Architect distributed data warehouses, streaming pipelines, and automated transformations that fuel company-wide business intelligence.',
    averageStartingSalary: '₹16,00,000 - ₹26,00,000 / year',
    growthOutlook: 'Very High',
    requiredCoreSkills: ['SQL & Relational Databases', 'Python', 'ETL Pipelines & Spark', 'Data Structures & Algorithms'],
    recommendedSecondarySkills: ['Distributed Systems', 'Docker & Kubernetes', 'Redis & In-Memory Caching', 'Linux Systems & Shell'],
    typicalTrajectory: [
      {
        step: 1,
        phase: 'Data Modeling',
        title: 'Schema Design & Relational Mastery',
        description: 'Master star/snowflake schemas, query plan optimization, indexing strategies, and database ACID properties.',
        keyDeliverables: ['Complex relational warehouse migration project', 'Verified SQL Advanced score']
      },
      {
        step: 2,
        phase: 'Distributed Streaming',
        title: 'Apache Spark, Kafka & Lakehouse Architecture',
        description: 'Build real-time event streaming pipelines with deduplication, dead-letter queues, and delta lake tables.',
        keyDeliverables: ['Terabyte-scale streaming benchmark project on AWS/GCP']
      },
      {
        step: 3,
        phase: 'Enterprise Data Platform',
        title: 'Data Platform Engineer',
        description: 'Deploy dbt workflows, automated data quality anomaly detectors, and cross-team data contracts.',
        keyDeliverables: ['Enterprise Data Engineering Internship']
      }
    ],
    industryDemandScore: 93
  }
];
