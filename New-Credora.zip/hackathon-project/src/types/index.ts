export type UserRole = 'student' | 'university_admin' | 'recruiter' | 'platform_admin';

export type DegreeLevel = 'BTech' | 'MTech' | 'BSc' | 'MSc' | 'MBA' | 'PhD' | 'Dual Degree' | 'Other';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  institutionId?: string;
  institutionName?: string;
  companyId?: string;
  companyName?: string;
  isEmailVerified: boolean;
  verificationStatus: 'Not Started' | 'In Progress' | 'Verified' | 'Needs Review' | 'Expired';
  avatar?: string;
  createdAt: string;
}

export interface StudentProfile {
  userId: string;
  fullName: string;
  universityEmail: string;
  degreeLevel: DegreeLevel;
  courseLevel?: string;
  degreeName?: string;
  specialization?: string;
  currentYear?: string;
  previousDegree?: string;
  researchArea?: string;
  major: string;
  institutionId: string;
  institutionName: string;
  graduationYear: number;
  cgpa?: number;
  placementReadinessScore: number;
  profileCompletionPercentage: number;
  city: string;
  country: string;
  headline: string;
  bio: string;
  targetCareerId?: string;
  preferredIndustries: string[];
  workPreference: 'Remote' | 'Hybrid' | 'On-site' | 'Flexible';
  githubUrl?: string;
  linkedinUrl?: string;
  portfolioUrl?: string;
  avatarUrl?: string;
  verification: {
    status: 'Not Started' | 'In Progress' | 'Verified' | 'Needs Review' | 'Expired';
    provider: string;
    providerRef?: string;
    verifiedAt?: string;
    documentType?: 'Student ID Card' | 'National ID' | 'University Transcripts';
  };
  privacySettings?: {
    recruiterSearchable: boolean;
    allowDirectRecruiterContact: boolean;
    shareAcademicTranscriptVerification: boolean;
  };
}

export interface Institution {
  id: string;
  name: string;
  type: 'University' | 'Institute of Technology' | 'College' | 'Institute' | 'Campus';
  country: string;
  city: string;
  state?: string;
  website: string;
  officialEmailDomains: string[];
  parentInstitution?: string;
  verificationStatus: 'Verified' | 'Pending Verification';
  active: boolean;
  studentCount?: number;
  code?: string;
}

export type IndustryType = 'Technology' | 'Finance' | 'Consulting';

export interface Company {
  id: string;
  name: string;
  industry: IndustryType;
  headquarters: string;
  countries: string[];
  website: string;
  careersUrl: string;
  companySize: string;
  verificationStatus: 'Verified' | 'Pending';
  active: boolean;
  description: string;
  activeOpportunitiesCount: number;
  logoBg: string;
  logoText: string;
  tags: string[];
}

export type OpportunityType = 
  | 'Internship' 
  | 'Full-time Job' 
  | 'Research Project' 
  | 'Academic Project' 
  | 'Hackathon' 
  | 'Fellowship' 
  | 'Competition';

export type WorkMode = 'Remote' | 'Hybrid' | 'On-site';

export interface Opportunity {
  id: string;
  title: string;
  companyId: string;
  companyName: string;
  companyLogoBg: string;
  industry: IndustryType;
  type: OpportunityType;
  workMode: WorkMode;
  location: string;
  requiredSkills: string[];
  preferredSkills: string[];
  degreeRequirements: DegreeLevel[];
  eligibility: string;
  deadline: string;
  stipendOrSalary: string;
  description: string;
  responsibilities: string[];
  qualifications: string[];
  source: string;
  sourceType: 'Official Enterprise Feed' | 'University Career Feed' | 'Verified Partner';
  applicationUrl: string;
  dateDiscovered: string;
  lastUpdated: string;
  isDemoData: boolean;
}

export type SkillCategory = 
  | 'Programming'
  | 'Engineering'
  | 'Data'
  | 'AI/ML'
  | 'Design'
  | 'Business'
  | 'Communication'
  | 'Leadership'
  | 'Domain-specific';

export type SkillLevel = 'Beginner' | 'Developing' | 'Intermediate' | 'Advanced' | 'Expert';

export type EvidenceType = 
  | 'Project' 
  | 'Certification' 
  | 'Course' 
  | 'Internship' 
  | 'Assessment' 
  | 'Academic Subject';

export interface SkillEvidence {
  id: string;
  type: EvidenceType;
  title: string;
  organizationOrPlatform?: string;
  urlOrCredentialId?: string;
  dateCompleted: string;
  verified: boolean;
  gradeOrScore?: string;
}

export interface UserSkill {
  id: string;
  skillId: string;
  name: string;
  category: SkillCategory;
  level: SkillLevel;
  proficiencyScore: number; // 0-100
  evidence: SkillEvidence[];
  verified: boolean;
}

export interface CareerPath {
  id: string;
  title: string;
  industry: IndustryType;
  summary: string;
  averageStartingSalary: string;
  growthOutlook: 'Very High' | 'High' | 'Steady';
  requiredCoreSkills: string[];
  recommendedSecondarySkills: string[];
  typicalTrajectory: {
    step: number;
    phase: string;
    title: string;
    description: string;
    keyDeliverables: string[];
  }[];
  industryDemandScore: number; // 0-100
}

export type ApplicationStatus = 
  | 'Saved' 
  | 'Applied' 
  | 'Assessment' 
  | 'Interview' 
  | 'Selected' 
  | 'Rejected' 
  | 'Withdrawn';

export interface ApplicationRecord {
  id: string;
  opportunityId: string;
  opportunityTitle: string;
  companyName: string;
  companyLogoBg: string;
  status: ApplicationStatus;
  appliedDate: string;
  lastStatusUpdate: string;
  nextDeadline?: string;
  notes: string;
  interviewRounds?: {
    roundName: string;
    completed: boolean;
    date?: string;
  }[];
}

export interface UniversityIndustryProject {
  id: string;
  title: string;
  companyId: string;
  companyName: string;
  universityId: string;
  universityName: string;
  type: 'Capstone Project' | 'Industry Research' | 'Real-World Challenge' | 'Hackathon';
  durationWeeks: number;
  openSlots: number;
  enrolledStudentsCount: number;
  requiredSkills: string[];
  mentorName: string;
  mentorTitle: string;
  stipend?: string;
  status: 'Open for Applications' | 'In Progress' | 'Under Review' | 'Completed';
  description: string;
  deliverables: string[];
  deadline: string;
}

export interface IndustryPulseMetric {
  id: string;
  skillOrRole: string;
  category: 'Skill' | 'Role' | 'Specialization';
  industry: IndustryType;
  growthRatePercent: number;
  openPositionsEstimated: number;
  demandIndex: 'High Demand' | 'Surging Demand' | 'Critical Demand';
  topHiringCompanies: string[];
  source: string;
  dataPeriod: string;
  lastUpdated: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  userId: string;
  userEmail: string;
  userName: string;
  category: 'Account & Login' | 'Verification' | 'Opportunity Data' | 'Institution Access' | 'Privacy & Security' | 'General';
  subject: string;
  description: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High';
  createdAt: string;
  updatedAt: string;
}

export interface HelpArticle {
  id: string;
  category: string;
  title: string;
  slug: string;
  summary: string;
  content: string[];
  tags: string[];
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: string;
  userEmail: string;
  role: UserRole;
  ipMasked: string;
  details: string;
  status: 'Success' | 'Warning' | 'Blocked';
}

export interface OpportunityMatchBreakdown {
  overallScore: number;
  skillsScore: number;
  educationScore: number;
  experienceScore: number;
  locationScore: number;
  eligibilityScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  matchReasons: string[];
  improvementSuggestions: string[];
}
