export type VerificationStatus = 
  | 'Self-Declared'
  | 'Verification-Registered'
  | 'Assessment-Scheduled'
  | 'Assessment-Completed'
  | 'Results-Processing'
  | 'Professionally-Verified';

export type VerifiedSkillCategory = 
  | 'Programming Languages'
  | 'Web Development'
  | 'Databases'
  | 'Core Computer Science'
  | 'Emerging Technologies';

export type VerifiedProficiencyLevel = 'Foundation' | 'Intermediate' | 'Advanced' | 'Expert';

export interface AssessmentStructure {
  fundamentalsPercent: number; // e.g. 20%
  problemSolvingPercent: number; // e.g. 30%
  practicalCodingPercent: number; // e.g. 40%
  debuggingPercent: number; // e.g. 10%
}

export interface SkillVerificationCatalogueItem {
  id: string;
  name: string;
  iconEmoji: string;
  category: VerifiedSkillCategory;
  verificationStatus: 'Assessment Available' | 'Upcoming Cycle';
  assessmentDuration: string; // e.g. "Approximately 2 Hours"
  description: string;
  structure: AssessmentStructure;
  curriculum: string[];
  activeTestCentersCount: number;
  nextScheduledDate: string;
}

export interface VerificationAdmitCard {
  verificationId: string;
  candidateName: string;
  candidateEmail: string;
  institutionName: string;
  rollNumber: string;
  skillName: string;
  iconEmoji: string;
  assessmentDate: string;
  reportingTime: string;
  duration: string;
  assignedTestCenter: string;
  centerAddress: string;
  seatNumber: string;
  roomNumber: string;
  qrCodeToken: string;
  instructions: string[];
}

export interface UserVerifiedSkill {
  id: string;
  skillId: string;
  skillName: string;
  iconEmoji: string;
  category: VerifiedSkillCategory;
  status: VerificationStatus;
  dateAdded: string;
  
  // For Professionally-Verified skills
  proficiencyLevel?: VerifiedProficiencyLevel;
  score?: number; // e.g. 847
  maxScore?: number; // 1000
  percentileRank?: number; // e.g. 94.2%
  assessmentDate?: string;
  credentialId?: string; // e.g. "VS-PY-2026-98124"
  verificationExpiryDate?: string;

  // For In-Progress / Scheduled skills
  currentPhaseStep?: number; // 1 to 6
  scheduledDate?: string;
  reportingTime?: string;
  testCenter?: string;
  seatNumber?: string;
  admitCard?: VerificationAdmitCard;
  resultsExpectedDate?: string;
}

export interface AssessmentOpportunity {
  id: string;
  skillId: string;
  skillName: string;
  iconEmoji: string;
  category: VerifiedSkillCategory;
  assessmentDate: string;
  registrationDeadline: string;
  reportingTime: string;
  duration: string;
  availability: 'Registration Open' | 'Fast Filling' | 'Limited Seats';
  seatsRemaining: number;
  totalSeats: number;
  testCenterName: string;
  testCenterLocation: string;
  structure: AssessmentStructure;
}
