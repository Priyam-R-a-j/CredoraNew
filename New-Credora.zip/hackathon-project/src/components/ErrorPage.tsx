import React, { useState } from 'react';
import { Home, ArrowLeft, ShieldAlert, AlertTriangle, Lock, RefreshCw, Ban, ServerCrash } from 'lucide-react';
import { HOME_VIEW } from '../constants/routes';

export type ErrorStatusCode = 400 | 401 | 403 | 404 | 429 | 500;

interface ErrorConfig {
  code: ErrorStatusCode;
  badge: string;
  title: string;
  description: string;
  ctaText: string;
  icon: React.ComponentType<{ className?: string }>;
}

const ERROR_CONFIGS: Record<ErrorStatusCode, ErrorConfig> = {
  400: {
    code: 400,
    badge: 'Bad Request',
    title: 'The request could not be understood.',
    description: 'The parameter syntax or payload format was invalid or malformed. Please verify your query parameters or return to the main platform.',
    ctaText: 'Go Home',
    icon: AlertTriangle
  },
  401: {
    code: 401,
    badge: 'Authentication Required',
    title: 'Institutional login required.',
    description: 'You need an active authenticated session or university SSO verification token to access this career intelligence resource.',
    ctaText: 'Go Home',
    icon: Lock
  },
  403: {
    code: 403,
    badge: 'Access Forbidden',
    title: 'You do not have permission to view this resource.',
    description: 'This section is restricted to specific institutional roles (Dean of Academics, Placement Cell Directors, or Authorized Corporate Recruiters).',
    ctaText: 'Go Home',
    icon: Ban
  },
  404: {
    code: 404,
    badge: 'Resource Not Found',
    title: 'This trajectory does not exist in orbit.',
    description: 'The career pathway, opportunity listing, or skill constellation you are seeking could not be found or has moved to a new destination.',
    ctaText: 'Go Home',
    icon: ShieldAlert
  },
  429: {
    code: 429,
    badge: 'Rate Limit Exceeded',
    title: 'Too many requests.',
    description: 'Our matching engine received an unusually high volume of skill telemetry queries from your address. Please pause briefly before refreshing.',
    ctaText: 'Return Home',
    icon: RefreshCw
  },
  500: {
    code: 500,
    badge: 'Internal Server Issue',
    title: 'Orbit computation interrupted.',
    description: 'An unexpected condition was encountered on the server. Our engineering telemetry has logged this anomaly for immediate triage.',
    ctaText: 'Go Home',
    icon: ServerCrash
  }
};

interface ErrorPageProps {
  initialCode?: ErrorStatusCode;
  onNavigateHome: () => void;
  onRetry?: () => void;
}

export const ErrorPage: React.FC<ErrorPageProps> = ({
  initialCode = 404,
  onNavigateHome,
  onRetry
}) => {
  const [activeCode, setActiveCode] = useState<ErrorStatusCode>(initialCode);
  const config = ERROR_CONFIGS[activeCode] || ERROR_CONFIGS[404];
  const Icon = config.icon;

  return (
    <div className="min-h-[75vh] flex flex-col items-center justify-center px-4 py-16 sm:px-6 lg:px-8">
      <div className="w-full max-w-xl text-center space-y-6">
        {/* Status Code Pill */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
          <Icon className="w-3.5 h-3.5 text-indigo-600" />
          <span>Error {config.code} — {config.badge}</span>
        </div>

        {/* Large Code Display */}
        <div className="relative">
          <span className="text-7xl sm:text-9xl font-black text-slate-200/80 tracking-tighter select-none font-mono">
            {config.code}
          </span>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center text-indigo-600">
              <Icon className="w-8 h-8" />
            </div>
          </div>
        </div>

        {/* Headline & Description */}
        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {config.title}
          </h1>
          <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
            {config.description}
          </p>
        </div>

        {/* Action Buttons: Strict requirement for exact text */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={onNavigateHome}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold px-6 py-3 rounded-xl transition shadow-sm cursor-pointer"
            id="error-return-home-btn"
          >
            <Home className="w-4 h-4" />
            <span>{config.ctaText}</span>
          </button>

          {onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="inline-flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-bold px-5 py-3 rounded-xl border border-slate-200 transition cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Retry Request</span>
            </button>
          )}
        </div>

        {/* Simulation switcher for QA and inspection */}
        <div className="pt-10 border-t border-slate-200/80">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Inspect Error Codes &amp; Return-to-Home Actions
          </p>
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            {([400, 401, 403, 404, 429, 500] as ErrorStatusCode[]).map(code => (
              <button
                key={code}
                type="button"
                onClick={() => setActiveCode(code)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition ${
                  activeCode === code
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {code} ({ERROR_CONFIGS[code].ctaText})
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
