import React, { useState } from 'react';
import { 
  Building2, UserCheck, Briefcase, CheckCircle2, ArrowRight, ArrowLeft, 
  Search, Globe, MapPin, Sparkles, X, Plus, Edit3
} from 'lucide-react';
import { CANONICAL_SKILLS } from '../../data/skills';

export interface RecruiterOnboardingData {
  // Step 1: Organization
  companyName: string;
  orgType: string;
  industry: string;
  website: string;
  country: string;
  city: string;
  // Step 2: Recruiter Info
  fullName: string;
  jobTitle: string;
  workEmail: string;
  linkedinUrl?: string;
  // Step 3: Hiring Needs
  hiringTypes: string[];
  hiringDomains: string[];
  requiredSkills: string[];
  experienceLevel: string;
  workPreference: string;
}

interface RecruiterOnboardingProps {
  initialEmail: string;
  initialFullName?: string;
  onComplete: (data: RecruiterOnboardingData) => void;
  onBackToRoleSelection: () => void;
}

const ORG_TYPES = ['Startup (1-50)', 'Scale-up (50-250)', 'Mid-Market (250-1000)', 'Enterprise (1000+)', 'Government / Research Lab', 'Other'];
const INDUSTRIES = ['Technology', 'Finance & FinTech', 'Consulting & Strategy', 'Healthcare & BioTech', 'Automotive & Robotics', 'E-Commerce & Retail', 'Telecommunications', 'Other'];
const HIRING_TYPES = ['Internships (Summer/Winter)', 'Full-time Graduate Roles', 'Experienced Full-time', 'Part-time Roles', 'Contract & Apprenticeships'];
const HIRING_DOMAINS = ['Software Engineering', 'AI & Machine Learning', 'Data Science & Analytics', 'Embedded Systems & Hardware', 'Cybersecurity', 'Product Management', 'Quantitative Research', 'Cloud & DevOps'];
const EXPERIENCE_LEVELS = ['Freshers / Final Year Students', '0 - 1 Years Experience', '1 - 3 Years Experience', '3+ Years Experience'];
const WORK_PREFERENCES = ['Remote-Friendly', 'Hybrid Model', 'On-Site Office', 'Flexible'];

export const RecruiterOnboarding: React.FC<RecruiterOnboardingProps> = ({
  initialEmail,
  initialFullName = '',
  onComplete,
  onBackToRoleSelection,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 4;

  const [formData, setFormData] = useState<RecruiterOnboardingData>({
    companyName: 'Acme Technologies',
    orgType: 'Scale-up (50-250)',
    industry: 'Technology',
    website: 'https://acmetech.io',
    country: 'India',
    city: 'Bengaluru',
    fullName: initialFullName || 'Priya Nair',
    jobTitle: 'Lead University Talent Partner',
    workEmail: initialEmail,
    linkedinUrl: '',
    hiringTypes: ['Internships (Summer/Winter)', 'Full-time Graduate Roles'],
    hiringDomains: ['Software Engineering', 'AI & Machine Learning'],
    requiredSkills: ['Data Structures & Algorithms', 'Python', 'Distributed Systems'],
    experienceLevel: 'Freshers / Final Year Students',
    workPreference: 'Hybrid Model',
  });

  const [skillSearch, setSkillSearch] = useState('');

  const stepTitles = [
    'Organization Details',
    'Recruiter Profile',
    'Hiring Priorities',
    'Confirmation & Launch',
  ];

  const updateForm = (updates: Partial<RecruiterOnboardingData>) => {
    setFormData((prev) => ({ ...prev, ...updates }));
  };

  const toggleHiringType = (type: string) => {
    if (formData.hiringTypes.includes(type)) {
      updateForm({ hiringTypes: formData.hiringTypes.filter((t) => t !== type) });
    } else {
      updateForm({ hiringTypes: [...formData.hiringTypes, type] });
    }
  };

  const toggleDomain = (domain: string) => {
    if (formData.hiringDomains.includes(domain)) {
      updateForm({ hiringDomains: formData.hiringDomains.filter((d) => d !== domain) });
    } else {
      updateForm({ hiringDomains: [...formData.hiringDomains, domain] });
    }
  };

  const toggleSkill = (skill: string) => {
    if (formData.requiredSkills.includes(skill)) {
      updateForm({ requiredSkills: formData.requiredSkills.filter((s) => s !== skill) });
    } else {
      updateForm({ requiredSkills: [...formData.requiredSkills, skill] });
    }
  };

  const filteredSkills = CANONICAL_SKILLS.filter(s => 
    s.name.toLowerCase().includes(skillSearch.toLowerCase()) || 
    s.category.toLowerCase().includes(skillSearch.toLowerCase())
  );

  const canProceedStep1 = formData.companyName.trim().length > 0 && formData.website.trim().length > 0 && formData.city.trim().length > 0;
  const canProceedStep2 = formData.fullName.trim().length > 0 && formData.jobTitle.trim().length > 0 && formData.workEmail.trim().length > 0;
  const canProceedStep3 = formData.hiringTypes.length > 0 && formData.hiringDomains.length > 0;

  return (
    <div className="space-y-5">
      {/* Progress Header */}
      <div>
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="font-bold text-emerald-600 dark:text-emerald-400">
            Step {currentStep} of {totalSteps}: {stepTitles[currentStep - 1]}
          </span>
          <span className="text-slate-400 dark:text-slate-500 font-mono text-[11px]">
            {Math.round((currentStep / totalSteps) * 100)}% Complete
          </span>
        </div>
        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex gap-1">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-full flex-1 transition-all duration-300 rounded-full ${
                i < currentStep ? 'bg-emerald-600' : 'bg-transparent'
              }`}
            />
          ))}
        </div>
      </div>

      {/* STEP 1: ORGANIZATION DETAILS */}
      {currentStep === 1 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <span>Tell us about your organization</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Set up your employer profile to post opportunities and discover verified student cohorts.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Company / Organization Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Google, Microsoft, DeepMind, Razorpay"
              value={formData.companyName}
              onChange={(e) => updateForm({ companyName: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Organization Type <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.orgType}
                onChange={(e) => updateForm({ orgType: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {ORG_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Industry Sector <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.industry}
                onChange={(e) => updateForm({ industry: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {INDUSTRIES.map(ind => <option key={ind} value={ind}>{ind}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Company Website URL <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="url"
                required
                placeholder="https://company.com"
                value={formData.website}
                onChange={(e) => updateForm({ website: e.target.value })}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Headquarters Country <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => updateForm({ country: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Office City <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Bengaluru, San Francisco"
                  value={formData.city}
                  onChange={(e) => updateForm({ city: e.target.value })}
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: RECRUITER INFORMATION */}
      {currentStep === 2 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>Your Recruiter Contact Information</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              These details help university placement departments authenticate your talent partnership.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Your Full Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Priya Nair"
              value={formData.fullName}
              onChange={(e) => updateForm({ fullName: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Job Title / Designation <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Head of University Recruiting, Technical Talent Partner"
              value={formData.jobTitle}
              onChange={(e) => updateForm({ jobTitle: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Official Work Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              required
              value={formData.workEmail}
              onChange={(e) => updateForm({ workEmail: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              LinkedIn Profile URL <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="url"
              placeholder="https://linkedin.com/in/recruiter-profile"
              value={formData.linkedinUrl || ''}
              onChange={(e) => updateForm({ linkedinUrl: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
        </div>
      )}

      {/* STEP 3: HIRING NEEDS */}
      {currentStep === 3 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-emerald-600" />
              <span>What are your hiring priorities?</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select roles, domains, and core skills to calibrate candidate match algorithms.
            </p>
          </div>

          {/* Hiring Types */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              What are you hiring for? <span className="text-red-500">*</span>
            </label>
            <div className="flex flex-wrap gap-1.5">
              {HIRING_TYPES.map((type) => {
                const isSelected = formData.hiringTypes.includes(type);
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => toggleHiringType(type)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <span>{type}</span>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Hiring Domains */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Target Domains <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {HIRING_DOMAINS.map((domain) => {
                const isSelected = formData.hiringDomains.includes(domain);
                return (
                  <button
                    key={domain}
                    type="button"
                    onClick={() => toggleDomain(domain)}
                    className={`p-2 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span className="truncate">{domain}</span>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Required Skills */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Key Skills Desired ({formData.requiredSkills.length})
              </label>
              <div className="relative w-48">
                <Search className="w-3 h-3 text-slate-400 absolute left-2 top-2" />
                <input
                  type="text"
                  placeholder="Filter skills..."
                  value={skillSearch}
                  onChange={(e) => setSkillSearch(e.target.value)}
                  className="w-full text-[11px] pl-6 pr-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto p-1 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800/40">
              {filteredSkills.slice(0, 16).map((sk) => {
                const isSelected = formData.requiredSkills.includes(sk.name);
                return (
                  <button
                    key={sk.id}
                    type="button"
                    onClick={() => toggleSkill(sk.name)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer flex items-center gap-1 ${
                      isSelected
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600'
                    }`}
                  >
                    <span>{sk.name}</span>
                    {isSelected ? <CheckCircle2 className="w-3 h-3" /> : <Plus className="w-3 h-3 text-slate-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Experience level & work mode */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Candidate Experience Level
              </label>
              <select
                value={formData.experienceLevel}
                onChange={(e) => updateForm({ experienceLevel: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {EXPERIENCE_LEVELS.map(exp => <option key={exp} value={exp}>{exp}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Work Mode Preference
              </label>
              <select
                value={formData.workPreference}
                onChange={(e) => updateForm({ workPreference: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {WORK_PREFERENCES.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: SUMMARY & COMPLETE */}
      {currentStep === 4 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Review Employer Registration</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Confirm your company details. Your Recruiter Command Center is ready to launch.
            </p>
          </div>

          {/* Summary Card */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 space-y-3">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-bold text-sm flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {formData.companyName}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {formData.industry} · {formData.city}, {formData.country}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>Edit</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Recruiter Lead</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.fullName} ({formData.jobTitle})
                </p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Contact Email</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                  {formData.workEmail}
                </p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Work Mode</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.workPreference}
                </p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Target Cohort</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.experienceLevel}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Active Hiring Types
                </span>
                <div className="flex flex-wrap gap-1">
                  {formData.hiringTypes.map(t => (
                    <span key={t} className="bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded text-[10px] font-medium">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Target Domains &amp; Skills
                </span>
                <div className="flex flex-wrap gap-1">
                  {formData.hiringDomains.map(d => (
                    <span key={d} className="bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 px-2 py-0.5 rounded text-[10px] font-semibold">
                      {d}
                    </span>
                  ))}
                  {formData.requiredSkills.map(s => (
                    <span key={s} className="bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded text-[10px]">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM NAVIGATION */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
        {currentStep === 1 ? (
          <button
            type="button"
            onClick={onBackToRoleSelection}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Role Selection</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setCurrentStep(currentStep - 1)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        )}

        {currentStep < totalSteps ? (
          <button
            type="button"
            disabled={
              (currentStep === 1 && !canProceedStep1) ||
              (currentStep === 2 && !canProceedStep2) ||
              (currentStep === 3 && !canProceedStep3)
            }
            onClick={() => setCurrentStep(currentStep + 1)}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <span>Continue</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => onComplete(formData)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Sparkles className="w-4 h-4" />
            <span>Complete &amp; Launch Recruiter Hub</span>
          </button>
        )}
      </div>
    </div>
  );
};
