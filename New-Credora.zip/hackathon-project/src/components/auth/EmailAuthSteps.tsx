import React, { useState, useEffect } from 'react';
import { 
  Mail, Lock, Eye, EyeOff, ShieldCheck, ArrowRight, ArrowLeft, 
  CheckCircle2, AlertCircle, RefreshCw, KeyRound, Sparkles
} from 'lucide-react';
import { UserRole } from '../../types';

interface EmailAuthStepsProps {
  initialMode?: 'signin' | 'signup';
  onExistingUserLogin: (user: {
    fullName: string;
    email: string;
    institution: string;
    role: UserRole;
    avatar?: string;
  }) => void;
  onNewUserVerified: (email: string) => void;
  onBackToWelcome: () => void;
}

export const EmailAuthSteps: React.FC<EmailAuthStepsProps> = ({
  initialMode = 'signup',
  onExistingUserLogin,
  onNewUserVerified,
  onBackToWelcome,
}) => {
  const [mode, setMode] = useState<'signin' | 'signup' | 'verify' | 'forgot'>(initialMode);
  
  // Sign In / Sign Up Form
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  // Turnstile Bot Verification simulation
  const [turnstilePassed, setTurnstilePassed] = useState(false);
  const [isVerifyingBot, setIsVerifyingBot] = useState(false);
  
  // Email Verification Code
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [resendCooldown, setResendCooldown] = useState(30);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Password strength calculation
  const getPasswordStrength = (pass: string) => {
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;
    return score; // 0 to 4
  };

  const passwordStrength = getPasswordStrength(password);
  const strengthLabels = ['Very Weak', 'Weak', 'Fair', 'Strong', 'Enterprise-Grade'];
  const strengthColors = [
    'bg-red-500',
    'bg-amber-500',
    'bg-yellow-500',
    'bg-emerald-500',
    'bg-indigo-600',
  ];

  // Resend code countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (mode === 'verify' && resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [mode, resendCooldown]);

  // Handle Turnstile verification simulation
  const handleTurnstileClick = () => {
    if (turnstilePassed) return;
    setIsVerifyingBot(true);
    setTimeout(() => {
      setIsVerifyingBot(false);
      setTurnstilePassed(true);
    }, 600);
  };

  // Sign In submit
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!email.trim() || !password) {
      setErrorMessage('Please provide both your email and password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const normalizedEmail = email.toLowerCase().trim();

      // Check against known system users
      if (normalizedEmail.includes('recruiter') || normalizedEmail.includes('priya')) {
        onExistingUserLogin({
          fullName: 'Priya Nair',
          email: normalizedEmail,
          institution: 'Google Campus Talent Acquisition',
          role: 'recruiter',
          avatar: 'PN',
        });
      } else if (normalizedEmail.includes('admin') || normalizedEmail.includes('dean')) {
        onExistingUserLogin({
          fullName: 'Dr. Sandeep Sancheti',
          email: normalizedEmail,
          institution: 'Manipal University Jaipur',
          role: 'university_admin',
          avatar: 'SS',
        });
      } else {
        // Default to existing student account
        onExistingUserLogin({
          fullName: 'Aarav Sharma',
          email: normalizedEmail,
          institution: 'Manipal University Jaipur',
          role: 'student',
          avatar: 'AS',
        });
      }
    }, 450);
  };

  // Sign Up submit
  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!email.trim() || !password || !confirmPassword) {
      setErrorMessage('All fields are required.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    if (password.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    if (!turnstilePassed) {
      setErrorMessage('Please complete the verification check.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setMode('verify');
      setResendCooldown(30);
      setSuccessMessage(`A 6-digit verification code was dispatched to ${email}`);
    }, 600);
  };

  // Handle 6-digit code input
  const handleCodeChange = (index: number, val: string) => {
    if (val.length > 1) {
      // Pasted full code
      const pastedDigits = val.replace(/\D/g, '').slice(0, 6).split('');
      const newCode = [...verificationCode];
      pastedDigits.forEach((digit, i) => {
        if (i < 6) newCode[i] = digit;
      });
      setVerificationCode(newCode);
      return;
    }

    const newCode = [...verificationCode];
    newCode[index] = val.slice(-1);
    setVerificationCode(newCode);

    // Auto-advance focus to next digit
    if (val && index < 5) {
      const nextInput = document.getElementById(`digit-${index + 1}`);
      if (nextInput) (nextInput as HTMLInputElement).focus();
    }
  };

  const handleVerifyCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const entered = verificationCode.join('');

    if (entered.length < 6) {
      setErrorMessage('Please enter the complete 6-digit verification code.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      // Success! Proceed to role selection
      onNewUserVerified(email);
    }, 500);
  };

  // Quick auto-fill demo verification code
  const fillDemoCode = () => {
    setVerificationCode(['8', '4', '9', '2', '0', '1']);
  };

  return (
    <div className="space-y-4">
      {/* Top Back and Mode Switcher */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <button
          type="button"
          onClick={mode === 'verify' || mode === 'forgot' ? () => setMode('signin') : onBackToWelcome}
          className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1 cursor-pointer transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{mode === 'verify' || mode === 'forgot' ? 'Back' : 'All sign-in options'}</span>
        </button>

        {mode !== 'verify' && mode !== 'forgot' && (
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-xs font-semibold">
            <button
              type="button"
              onClick={() => { setMode('signin'); setErrorMessage(''); }}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                mode === 'signin'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setErrorMessage(''); }}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                mode === 'signup'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Create Account
            </button>
          </div>
        )}
      </div>

      {/* Error & Success Messages */}
      {errorMessage && (
        <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 rounded-xl text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 rounded-xl text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* MODE: SIGN IN */}
      {mode === 'signin' && (
        <form onSubmit={handleSignInSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="name@university.edu or name@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Password
              </label>
              <button
                type="button"
                onClick={() => setMode('forgot')}
                className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-xs pl-9 pr-10 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 text-slate-600 dark:text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <span>Remember this workstation</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>Sign In to Command Center</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}

      {/* MODE: CREATE ACCOUNT */}
      {mode === 'signup' && (
        <form onSubmit={handleSignUpSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Work / University or Personal Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="e.g. alex.chen@stanford.edu or alex@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Create Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="At least 8 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-xs pl-9 pr-10 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {/* Password strength meter */}
            {password.length > 0 && (
              <div className="mt-1.5 space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-500">Security strength:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    {strengthLabels[passwordStrength]}
                  </span>
                </div>
                <div className="h-1 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex gap-0.5">
                  {[0, 1, 2, 3].map((idx) => (
                    <div
                      key={idx}
                      className={`h-full flex-1 transition-all ${
                        idx < passwordStrength ? strengthColors[passwordStrength] : 'bg-transparent'
                      }`}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Confirm Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Confirm password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition"
              />
            </div>
          </div>

          {/* Cloudflare Turnstile Bot Verification Check */}
          <div className="pt-1">
            <button
              type="button"
              onClick={handleTurnstileClick}
              className={`w-full p-2.5 rounded-xl border text-xs flex items-center justify-between transition cursor-pointer ${
                turnstilePassed
                  ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2">
                {isVerifyingBot ? (
                  <RefreshCw className="w-4 h-4 text-indigo-600 animate-spin" />
                ) : turnstilePassed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <div className="w-4 h-4 rounded border-2 border-slate-400" />
                )}
                <span className="font-medium">
                  {turnstilePassed ? 'Human verification passed' : 'Verify you are human'}
                </span>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
                <span>Cloudflare Turnstile</span>
              </div>
            </button>
          </div>

          <button
            type="submit"
            disabled={isLoading || !turnstilePassed}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs mt-2"
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>Continue & Verify Email</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}

      {/* MODE: VERIFY EMAIL (6-DIGIT CODE) */}
      {mode === 'verify' && (
        <form onSubmit={handleVerifyCodeSubmit} className="space-y-4">
          <div className="text-center space-y-1">
            <div className="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center mx-auto mb-2">
              <Mail className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Verify Your Email
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-xs mx-auto">
              We sent a 6-digit verification code to <strong className="text-slate-800 dark:text-slate-200">{email}</strong>
            </p>
          </div>

          {/* 6-Digit input boxes */}
          <div className="flex justify-center gap-2 my-3">
            {verificationCode.map((digit, idx) => (
              <input
                key={idx}
                id={`digit-${idx}`}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleCodeChange(idx, e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Backspace' && !digit && idx > 0) {
                    const prevInput = document.getElementById(`digit-${idx - 1}`);
                    if (prevInput) (prevInput as HTMLInputElement).focus();
                  }
                }}
                className="w-10 h-11 text-center font-mono font-bold text-base rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            ))}
          </div>

          {/* Demo convenience shortcut */}
          <div className="text-center">
            <button
              type="button"
              onClick={fillDemoCode}
              className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1 cursor-pointer font-medium"
            >
              <Sparkles className="w-3 h-3" />
              <span>Auto-fill demo code (849201)</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-slate-500">Didn't receive code?</span>
            <button
              type="button"
              disabled={resendCooldown > 0}
              onClick={() => {
                setResendCooldown(30);
                setSuccessMessage('A fresh verification code was sent.');
              }}
              className="font-semibold text-indigo-600 dark:text-indigo-400 disabled:text-slate-400 cursor-pointer"
            >
              {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend Code'}
            </button>
          </div>

          <button
            type="submit"
            disabled={isLoading || verificationCode.join('').length < 6}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
          >
            {isLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>Confirm Verification & Select Role</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      )}

      {/* MODE: FORGOT PASSWORD */}
      {mode === 'forgot' && (
        <div className="space-y-3.5">
          <div className="text-center space-y-1">
            <div className="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mx-auto mb-2">
              <KeyRound className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Reset Your Password
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Enter your email address and we'll send you recovery instructions.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Registered Email
            </label>
            <input
              type="email"
              placeholder="e.g. aarav@jaipur.manipal.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              setSuccessMessage(`Password recovery link dispatched to ${email || 'your email'}`);
              setTimeout(() => setMode('signin'), 1500);
            }}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 rounded-xl transition cursor-pointer"
          >
            Send Recovery Instructions
          </button>
        </div>
      )}
    </div>
  );
};
