import React, { useState } from 'react';
import { 
  User, BookOpen, Layers, Target, Briefcase, CheckCircle2, 
  ArrowRight, ArrowLeft, Search, Plus, X, Globe, MapPin, 
  Calendar, Upload, Sparkles, Building2, Award, ExternalLink, Edit3
} from 'lucide-react';
import { CANONICAL_SKILLS, CanonicalSkill } from '../../data/skills';
import { INSTITUTIONS_DATA } from '../../data/institutions';
import { DegreeLevel, StudentProfile, UserSkill } from '../../types';

export type CourseLevelType = 'Diploma' | "Bachelor's" | "Master's" | 'PhD' | 'Postdoctoral' | 'Other';

export interface StudentOnboardingData {
  // Step 1: Basic Info
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  dob?: string;
  country: string;
  city: string;
  // Step 2: Education
  courseLevel: CourseLevelType;
  degreeName: string;
  customDegree?: string;
  institutionName: string;
  customInstitution?: string;
  major: string; // Branch / Specialization / Research Area
  currentYear: string;
  graduationYear: number;
  previousDegree?: string; // For Master's
  researchArea?: string; // For PhD
  // Step 3: Skills
  selectedSkills: string[]; // skill IDs or names
  // Step 4: Interests
  interests: string[];
  customInterest?: string;
  // Step 5: Experience (Optional)
  topProjectOrExperience?: string;
  portfolioUrl?: string;
  githubUrl?: string;
  linkedinUrl?: string;
}

interface StudentOnboardingProps {
  initialEmail: string;
  initialFullName?: string;
  initialAvatar?: string;
  onComplete: (data: StudentOnboardingData) => void;
  onBackToRoleSelection: () => void;
}

const COUNTRIES = [
  'India', 'United States', 'United Kingdom', 'Canada', 
  'Germany', 'Australia', 'Singapore', 'United Arab Emirates', 
  'Netherlands', 'France', 'Japan', 'Other'
];

const BACHELOR_DEGREES = ['B.Tech', 'B.E.', 'B.Sc.', 'BCA', 'B.Com', 'BBA', 'BA', 'Other'];
const MASTER_DEGREES = ['M.Tech', 'M.E.', 'M.Sc.', 'MCA', 'MBA', 'MS', 'MA', 'Other'];
const PHD_DEGREES = ['PhD', 'D.Sc.', 'Other'];
const DIPLOMA_DEGREES = ['Diploma in Engineering', 'Polytechnic Diploma', 'Postgraduate Diploma', 'Other'];
const POSTDOC_DEGREES = ['Postdoctoral Fellowship', 'Research Associate', 'Other'];

const BACHELOR_YEARS = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', 'Final Year'];
const MASTER_YEARS = ['1st Year', '2nd Year', 'Final Year'];
const PHD_YEARS = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th+ Year'];
const DIPLOMA_YEARS = ['1st Year', '2nd Year', '3rd Year', 'Final Year'];

const CAREER_INTEREST_OPTIONS = [
  'Software Development',
  'Electronics & Hardware',
  'Embedded Systems',
  'Data Science',
  'AI / Machine Learning',
  'Cybersecurity',
  'Product Management',
  'Finance & Quantitative Tech',
  'Marketing & Growth',
  'Design & UX',
  'Research & Academia',
  'Consulting & Strategy',
  'Entrepreneurship',
];

export const StudentOnboarding: React.FC<StudentOnboardingProps> = ({
  initialEmail,
  initialFullName = '',
  initialAvatar,
  onComplete,
  onBackToRoleSelection,
}) => {
  // Parse initial full name
  const nameParts = initialFullName.trim().split(' ');
  const defaultFirst = nameParts[0] || '';
  const defaultLast = nameParts.slice(1).join(' ') || '';

  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 6;

  // Form State
  const [formData, setFormData] = useState<StudentOnboardingData>({
    firstName: defaultFirst,
    lastName: defaultLast,
    avatarUrl: initialAvatar || '',
    dob: '',
    country: 'India',
    city: 'Jaipur',
    courseLevel: "Bachelor's",
    degreeName: 'B.Tech',
    customDegree: '',
    institutionName: 'Manipal University Jaipur (MUJ)',
    customInstitution: '',
    major: 'Computer Science & Engineering',
    currentYear: '3rd Year',
    graduationYear: 2027,
    previousDegree: '',
    researchArea: '',
    selectedSkills: ['Data Structures & Algorithms', 'Python', 'SQL & Relational Databases'],
    interests: ['Software Development', 'AI / Machine Learning'],
    topProjectOrExperience: '',
    portfolioUrl: '',
    githubUrl: '',
    linkedinUrl: '',
  });

  // Skills filter state
  const [skillSearchQuery, setSkillSearchQuery] = useState('');
  const [activeSkillCategory, setActiveSkillCategory] = useState<string>('All');
  const [customSkillInput, setCustomSkillInput] = useState('');

  // Institution search
  const [institutionQuery, setInstitutionQuery] = useState('');

  const stepTitles = [
    'Basic Information',
    'Education Details',
    'Skills Assessment',
    'Career Interests',
    'Experience & Portfolio',
    'Profile Summary',
  ];

  // Helper to update state
  const updateForm = (updates: Partial<StudentOnboardingData>) => {
    setFormData((prev) => ({ ...prev, ...updates }));
  };

  // Skill categories
  const categories = ['All', 'Programming', 'Engineering', 'Data', 'AI/ML', 'Design', 'Business', 'Communication'];

  const filteredSkills = CANONICAL_SKILLS.filter((skill) => {
    const matchesCategory = activeSkillCategory === 'All' || skill.category === activeSkillCategory;
    const matchesSearch = skill.name.toLowerCase().includes(skillSearchQuery.toLowerCase()) ||
                          skill.description.toLowerCase().includes(skillSearchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Toggle skill selection
  const toggleSkill = (skillName: string) => {
    if (formData.selectedSkills.includes(skillName)) {
      updateForm({ selectedSkills: formData.selectedSkills.filter((s) => s !== skillName) });
    } else {
      updateForm({ selectedSkills: [...formData.selectedSkills, skillName] });
    }
  };

  // Add custom skill
  const addCustomSkill = () => {
    if (!customSkillInput.trim()) return;
    if (!formData.selectedSkills.includes(customSkillInput.trim())) {
      updateForm({ selectedSkills: [...formData.selectedSkills, customSkillInput.trim()] });
    }
    setCustomSkillInput('');
  };

  // Toggle Interest
  const toggleInterest = (interest: string) => {
    if (formData.interests.includes(interest)) {
      updateForm({ interests: formData.interests.filter((i) => i !== interest) });
    } else {
      updateForm({ interests: [...formData.interests, interest] });
    }
  };

  // Dynamic Degree list based on Course Level
  const getDegreeOptions = () => {
    switch (formData.courseLevel) {
      case 'Diploma':
        return DIPLOMA_DEGREES;
      case "Bachelor's":
        return BACHELOR_DEGREES;
      case "Master's":
        return MASTER_DEGREES;
      case 'PhD':
        return PHD_DEGREES;
      case 'Postdoctoral':
        return POSTDOC_DEGREES;
      default:
        return ['Other'];
    }
  };

  // Dynamic Year list based on Course Level
  const getYearOptions = () => {
    switch (formData.courseLevel) {
      case 'Diploma':
        return DIPLOMA_YEARS;
      case "Bachelor's":
        return BACHELOR_YEARS;
      case "Master's":
        return MASTER_YEARS;
      case 'PhD':
        return PHD_YEARS;
      default:
        return ['1st Year', '2nd Year', '3rd Year', 'Final Year'];
    }
  };

  // Step validation
  const canProceedStep1 = formData.firstName.trim().length > 0 && formData.lastName.trim().length > 0 && formData.city.trim().length > 0;
  const canProceedStep2 = formData.institutionName.trim().length > 0 && formData.major.trim().length > 0;
  const canProceedStep3 = formData.selectedSkills.length > 0;
  const canProceedStep4 = formData.interests.length > 0;

  return (
    <div className="space-y-5">
      {/* Progress Bar & Step Tracker */}
      <div>
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="font-bold text-indigo-600 dark:text-indigo-400">
            Step {currentStep} of {totalSteps}: {stepTitles[currentStep - 1]}
          </span>
          <span className="text-slate-400 dark:text-slate-500 font-mono text-[11px]">
            {Math.round((currentStep / totalSteps) * 100)}% Complete
          </span>
        </div>
        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex gap-1">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-full flex-1 transition-all duration-300 rounded-full ${
                i < currentStep
                  ? 'bg-indigo-600'
                  : 'bg-transparent'
              }`}
            />
          ))}
        </div>
      </div>

      {/* ========================================================
          STEP 1: BASIC INFORMATION
         ======================================================== */}
      {currentStep === 1 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <User className="w-4 h-4 text-indigo-600" />
              <span>Let's start with your basic profile</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              This information will be displayed on your verified academic profile.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                First Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Aarav"
                value={formData.firstName}
                onChange={(e) => updateForm({ firstName: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Last Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Sharma"
                value={formData.lastName}
                onChange={(e) => updateForm({ lastName: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Profile Photo Avatar Initials or Upload */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center shrink-0 shadow-xs">
              {formData.firstName ? formData.firstName.charAt(0).toUpperCase() : 'S'}
              {formData.lastName ? formData.lastName.charAt(0).toUpperCase() : ''}
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Profile Avatar
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Generated from your verified initials. You can customize your photo later in Settings.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Date of Birth <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="date"
                  value={formData.dob}
                  onChange={(e) => updateForm({ dob: e.target.value })}
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Country <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <select
                  value={formData.country}
                  onChange={(e) => updateForm({ country: e.target.value })}
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              City / Location <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                required
                placeholder="e.g. Jaipur, Bengaluru, Delhi, Mumbai"
                value={formData.city}
                onChange={(e) => updateForm({ city: e.target.value })}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          STEP 2: EDUCATION DETAILS (CRUCIAL & DYNAMIC)
         ======================================================== */}
      {currentStep === 2 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>What are you studying?</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select your course level and academic trajectory. SkillOrbit dynamically adapts verification based on your study level.
            </p>
          </div>

          {/* 1. Course Level Selection (Mandatory 6 options) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Course Level <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(['Diploma', "Bachelor's", "Master's", 'PhD', 'Postdoctoral', 'Other'] as CourseLevelType[]).map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => {
                    const nextDegree = level === "Bachelor's" ? 'B.Tech' : level === "Master's" ? 'M.Tech' : level === 'PhD' ? 'PhD' : level === 'Diploma' ? 'Diploma in Engineering' : 'Other';
                    updateForm({ courseLevel: level, degreeName: nextDegree });
                  }}
                  className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    formData.courseLevel === level
                      ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <span>{level}</span>
                  {formData.courseLevel === level && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Course / Degree Choice */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Degree / Course <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.degreeName}
                onChange={(e) => updateForm({ degreeName: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {getDegreeOptions().map((deg) => (
                  <option key={deg} value={deg}>{deg}</option>
                ))}
              </select>
            </div>

            {formData.degreeName === 'Other' || formData.courseLevel === 'Other' ? (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Specify Custom Degree / Course <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Integrated BS-MS, Dual Degree"
                  value={formData.customDegree}
                  onChange={(e) => updateForm({ customDegree: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Branch / Major / Specialization <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Computer Science, Mechanical, VLSI, AI"
                  value={formData.major}
                  onChange={(e) => updateForm({ major: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            )}
          </div>

          {/* 3. University / Institution */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              University / College / Institution <span className="text-red-500">*</span>
            </label>
            <div className="space-y-1.5">
              <select
                value={formData.institutionName}
                onChange={(e) => updateForm({ institutionName: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {INSTITUTIONS_DATA.map((inst) => (
                  <option key={inst.id} value={inst.name}>{inst.name}</option>
                ))}
                <option value="Other">Other / Not Listed</option>
              </select>

              {formData.institutionName === 'Other' && (
                <input
                  type="text"
                  required
                  placeholder="Enter your institution's official full name"
                  value={formData.customInstitution}
                  onChange={(e) => updateForm({ customInstitution: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-indigo-300 dark:border-indigo-700 bg-indigo-50/20 text-slate-900 dark:text-white"
                />
              )}
            </div>
          </div>

          {/* Dynamic details specific to Course Level */}
          {formData.courseLevel === "Master's" && (
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Previous Bachelor's Degree <span className="text-slate-400 font-normal">(e.g. B.Tech CSE, BCA, B.Sc)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. B.Tech in Information Technology"
                value={formData.previousDegree}
                onChange={(e) => updateForm({ previousDegree: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          )}

          {formData.courseLevel === 'PhD' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Doctoral Research Area / Dissertation Focus <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Large-Scale Distributed Graph Analytics & Fault Tolerance"
                value={formData.researchArea}
                onChange={(e) => updateForm({ researchArea: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          )}

          {/* Current Year & Expected Graduation Year */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Current Year <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.currentYear}
                onChange={(e) => updateForm({ currentYear: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {getYearOptions().map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Expected Completion / Graduation Year <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.graduationYear}
                onChange={(e) => updateForm({ graduationYear: parseInt(e.target.value, 10) })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white cursor-pointer"
              >
                {[2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031].map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          STEP 3: SKILLS
         ======================================================== */}
      {currentStep === 3 && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>What skills do you currently have?</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select the skills in your orbit. These will populate your Skill Map and unlock verified evaluations.
            </p>
          </div>

          {/* Selected Skills Pills */}
          <div className="min-h-12 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1.5 flex items-center justify-between">
              <span>Selected Skills ({formData.selectedSkills.length})</span>
              {formData.selectedSkills.length > 0 && (
                <button
                  type="button"
                  onClick={() => updateForm({ selectedSkills: [] })}
                  className="text-red-600 dark:text-red-400 hover:underline cursor-pointer"
                >
                  Clear all
                </button>
              )}
            </div>
            {formData.selectedSkills.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No skills selected yet. Click skills below to add them.</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {formData.selectedSkills.map((sk) => (
                  <span
                    key={sk}
                    className="inline-flex items-center gap-1 bg-indigo-100 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 px-2.5 py-1 rounded-lg text-xs font-semibold"
                  >
                    <span>{sk}</span>
                    <button
                      type="button"
                      onClick={() => toggleSkill(sk)}
                      className="hover:text-red-500 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Search & Category Tabs */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search canonical skills (e.g. Python, Docker, SQL, PyTorch)..."
                value={skillSearchQuery}
                onChange={(e) => setSkillSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            {/* Category tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px] scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveSkillCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition cursor-pointer font-medium ${
                    activeSkillCategory === cat
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Skill Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
            {filteredSkills.map((sk) => {
              const isSelected = formData.selectedSkills.includes(sk.name);
              return (
                <button
                  key={sk.id}
                  type="button"
                  onClick={() => toggleSkill(sk.name)}
                  className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex items-start justify-between gap-2 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-slate-300'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {sk.name}
                      </span>
                      {sk.inDemand && (
                        <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-1 rounded">
                          Hot
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {sk.description}
                    </p>
                  </div>
                  <div className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 mt-0.5 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-600 text-white'
                      : 'border-slate-300 dark:border-slate-600'
                  }`}>
                    {isSelected && <CheckCircle2 className="w-3 h-3" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Custom Skill Input */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="text"
              placeholder="Skill not found? Type custom skill..."
              value={customSkillInput}
              onChange={(e) => setCustomSkillInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addCustomSkill();
                }
              }}
              className="flex-1 text-xs px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
            <button
              type="button"
              onClick={addCustomSkill}
              className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================
          STEP 4: CAREER INTERESTS
         ======================================================== */}
      {currentStep === 4 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Target className="w-4 h-4 text-indigo-600" />
              <span>What are you interested in?</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select one or more career domains that excite you. SkillOrbit uses these to recommend verified internship opportunities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-72 overflow-y-auto pr-1">
            {CAREER_INTEREST_OPTIONS.map((interest) => {
              const isSelected = formData.interests.includes(interest);
              return (
                <button
                  key={interest}
                  type="button"
                  onClick={() => toggleInterest(interest)}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-slate-300'
                  }`}
                >
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    {interest}
                  </span>
                  <div className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-600 text-white'
                      : 'border-slate-300 dark:border-slate-600'
                  }`}>
                    {isSelected && <CheckCircle2 className="w-3 h-3" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Custom Interest */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="text"
              placeholder="Other domain or specialization interest..."
              value={formData.customInterest || ''}
              onChange={(e) => updateForm({ customInterest: e.target.value })}
              className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
            {formData.customInterest && (
              <button
                type="button"
                onClick={() => {
                  if (formData.customInterest && !formData.interests.includes(formData.customInterest)) {
                    updateForm({
                      interests: [...formData.interests, formData.customInterest],
                      customInterest: '',
                    });
                  }
                }}
                className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Add
              </button>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          STEP 5: EXPERIENCE & PROJECTS (OPTIONAL WITH SKIP)
         ======================================================== */}
      {currentStep === 5 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-indigo-600" />
                <span>Projects & Experience</span>
              </h3>
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Optional
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Highlight your top project or public profiles. You can skip this step and add them anytime.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Top Project or Work Highlight <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Built a distributed key-value cache in Go with Raft consensus, or AI vision model for campus navigation."
              value={formData.topProjectOrExperience}
              onChange={(e) => updateForm({ topProjectOrExperience: e.target.value })}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Portfolio or Personal Website URL
              </label>
              <input
                type="url"
                placeholder="https://yourname.dev"
                value={formData.portfolioUrl}
                onChange={(e) => updateForm({ portfolioUrl: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                GitHub Profile URL
              </label>
              <input
                type="url"
                placeholder="https://github.com/username"
                value={formData.githubUrl}
                onChange={(e) => updateForm({ githubUrl: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                LinkedIn Profile URL
              </label>
              <input
                type="url"
                placeholder="https://linkedin.com/in/username"
                value={formData.linkedinUrl}
                onChange={(e) => updateForm({ linkedinUrl: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          STEP 6: SUMMARY & FINISH
         ======================================================== */}
      {currentStep === 6 && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="text-left">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Review Your Verified Orbit Profile</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Everything looks primed. Click finish to initialize your Student Command Center.
            </p>
          </div>

          {/* Profile Summary Card */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/60 space-y-3.5">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center">
                  {formData.firstName.charAt(0).toUpperCase()}
                  {formData.lastName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {formData.firstName} {formData.lastName}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {initialEmail} · {formData.city}, {formData.country}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>Edit</span>
              </button>
            </div>

            {/* Academic Info */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Course Level</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">{formData.courseLevel}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Degree &amp; Branch</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.degreeName === 'Other' ? formData.customDegree : formData.degreeName} ({formData.major})
                </p>
              </div>
              <div className="col-span-2">
                <span className="text-[10px] text-slate-400 uppercase font-bold">Institution</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {formData.institutionName === 'Other' ? formData.customInstitution : formData.institutionName} · {formData.currentYear} (Class of {formData.graduationYear})
                </p>
              </div>
            </div>

            {/* Skills & Interests */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Skills ({formData.selectedSkills.length})
                </span>
                <div className="flex flex-wrap gap-1">
                  {formData.selectedSkills.slice(0, 6).map((sk) => (
                    <span key={sk} className="bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded text-[10px] font-medium">
                      {sk}
                    </span>
                  ))}
                  {formData.selectedSkills.length > 6 && (
                    <span className="text-[10px] text-slate-400 self-center">
                      +{formData.selectedSkills.length - 6} more
                    </span>
                  )}
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Target Interests
                </span>
                <div className="flex flex-wrap gap-1">
                  {formData.interests.map((it) => (
                    <span key={it} className="bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded text-[10px] font-medium">
                      {it}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          BOTTOM NAVIGATION BAR (BACK, SKIP, CONTINUE)
         ======================================================== */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
        {currentStep === 1 ? (
          <button
            type="button"
            onClick={onBackToRoleSelection}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Role Selection</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setCurrentStep(currentStep - 1)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        )}

        <div className="flex items-center gap-2">
          {/* Skip button for Step 5 (Optional) */}
          {currentStep === 5 && (
            <button
              type="button"
              onClick={() => setCurrentStep(6)}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition cursor-pointer"
            >
              Skip for now
            </button>
          )}

          {currentStep < totalSteps ? (
            <button
              type="button"
              disabled={
                (currentStep === 1 && !canProceedStep1) ||
                (currentStep === 2 && !canProceedStep2) ||
                (currentStep === 3 && !canProceedStep3) ||
                (currentStep === 4 && !canProceedStep4)
              }
              onClick={() => setCurrentStep(currentStep + 1)}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <span>Continue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onComplete(formData)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Sparkles className="w-4 h-4" />
              <span>Complete Profile &amp; Launch Orbit</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
