import React, { useState } from 'react';
import { X, CheckCircle2, User, PlusCircle, ArrowRight } from 'lucide-react';
import { GoogleIcon, LinkedInIcon, GitHubIcon, FacebookIcon } from './BrandIcons';
import { UserRole } from '../../types';

export type OAuthProvider = 'google' | 'linkedin' | 'github' | 'facebook';

interface OAuthSimModalProps {
  provider: OAuthProvider;
  isOpen: boolean;
  onClose: () => void;
  onSelectExistingUser: (user: {
    fullName: string;
    email: string;
    institution: string;
    role: UserRole;
    avatar?: string;
  }) => void;
  onContinueAsNewUser: (user: {
    fullName: string;
    email: string;
    avatar?: string;
    provider: OAuthProvider;
  }) => void;
}

export const OAuthSimModal: React.FC<OAuthSimModalProps> = ({
  provider,
  isOpen,
  onClose,
  onSelectExistingUser,
  onContinueAsNewUser,
}) => {
  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [showCustomForm, setShowCustomForm] = useState(false);

  if (!isOpen) return null;

  const providerDetails = {
    google: {
      name: 'Google',
      icon: <GoogleIcon className="w-5 h-5" />,
      domain: 'google.com',
      color: 'text-blue-600',
      bgColor: 'bg-white',
    },
    linkedin: {
      name: 'LinkedIn',
      icon: <LinkedInIcon className="w-5 h-5" />,
      domain: 'linkedin.com',
      color: 'text-[#0A66C2]',
      bgColor: 'bg-white',
    },
    github: {
      name: 'GitHub',
      icon: <GitHubIcon className="w-5 h-5" />,
      domain: 'github.com',
      color: 'text-slate-900 dark:text-white',
      bgColor: 'bg-white dark:bg-slate-900',
    },
    facebook: {
      name: 'Facebook',
      icon: <FacebookIcon className="w-5 h-5" />,
      domain: 'facebook.com',
      color: 'text-[#1877F2]',
      bgColor: 'bg-white',
    },
  }[provider];

  const existingAccounts = [
    {
      fullName: 'Aarav Sharma',
      email: provider === 'google' ? 'aarav.sharma@gmail.com' : `aarav.${provider}@example.com`,
      institution: 'Manipal University Jaipur',
      role: 'student' as UserRole,
      badge: 'Existing Student Account',
      avatarText: 'AS',
      avatarBg: 'bg-indigo-600',
    },
    {
      fullName: 'Priya Nair',
      email: provider === 'google' ? 'priya.nair@google.com' : `priya.${provider}@talent.com`,
      institution: 'Google Talent Acquisition',
      role: 'recruiter' as UserRole,
      badge: 'Existing Corporate Recruiter',
      avatarText: 'PN',
      avatarBg: 'bg-emerald-600',
    },
  ];

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail.trim() || !customName.trim()) return;
    onContinueAsNewUser({
      fullName: customName.trim(),
      email: customEmail.trim(),
      avatar: customName.trim().charAt(0).toUpperCase(),
      provider,
    });
  };

  const handleQuickNew = (sampleName: string, sampleEmailPrefix: string) => {
    onContinueAsNewUser({
      fullName: sampleName,
      email: `${sampleEmailPrefix}@${provider === 'github' ? 'users.noreply.github.com' : `${provider}.com`}`,
      avatar: sampleName.charAt(0).toUpperCase(),
      provider,
    });
  };

  return (
    <div className="fixed inset-0 z-60 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Provider Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {providerDetails.icon}
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                Sign in with {providerDetails.name}
              </h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                skillorbit.app wants to access your public profile and email
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {!showCustomForm ? (
            <>
              <div>
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Choose an account:
                </p>

                {/* Existing registered demo accounts */}
                <div className="space-y-2">
                  {existingAccounts.map((acc, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => onSelectExistingUser(acc)}
                      className="w-full text-left p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/20 transition flex items-center gap-3 cursor-pointer group"
                    >
                      <div className={`w-9 h-9 rounded-full ${acc.avatarBg} text-white font-bold text-xs flex items-center justify-center shrink-0`}>
                        {acc.avatarText}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {acc.fullName}
                          </span>
                          <span className="text-[10px] font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-1.5 py-0.2 rounded">
                            {acc.role === 'student' ? 'Student' : 'Recruiter'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {acc.email}
                        </p>
                      </div>
                      <CheckCircle2 className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-indigo-600 transition shrink-0" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Create New Account with this OAuth provider */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80">
                <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                  New to SkillOrbit?
                </p>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => handleQuickNew('Rohan Verma', 'rohan.verma')}
                    className="p-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-left transition cursor-pointer"
                  >
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Rohan Verma
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      New Student Profile
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickNew('Sarah Jenkins', 'sarah.jenkins')}
                    className="p-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-left transition cursor-pointer"
                  >
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Sarah Jenkins
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      New Recruiter Profile
                    </div>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setShowCustomForm(true)}
                  className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Enter another {providerDetails.name} identity</span>
                </button>
              </div>
            </>
          ) : (
            /* Custom OAuth Identity Form */
            <form onSubmit={handleCustomSubmit} className="space-y-3">
              <div className="text-xs text-slate-600 dark:text-slate-300">
                Enter your name and email to simulate signing up with <strong>{providerDetails.name}</strong>:
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maya Chen"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder={`e.g. maya@${providerDetails.domain}`}
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCustomForm(false)}
                  className="w-1/3 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={!customName.trim() || !customEmail.trim()}
                  className="w-2/3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>Continue to Onboarding</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          )}

          {/* Privacy footer */}
          <div className="text-[10px] text-center text-slate-400 dark:text-slate-500">
            By continuing, {providerDetails.name} will share your verified name, email address, and avatar preference with SkillOrbit.
          </div>
        </div>
      </div>
    </div>
  );
};
