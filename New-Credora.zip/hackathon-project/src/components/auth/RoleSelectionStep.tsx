import React from 'react';
import { GraduationCap, Briefcase, ArrowRight, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { UserRole } from '../../types';

interface RoleSelectionStepProps {
  selectedRole: 'student' | 'recruiter';
  onSelectRole: (role: 'student' | 'recruiter') => void;
  onContinue: () => void;
  onBack?: () => void;
  userEmail?: string;
  userName?: string;
}

export const RoleSelectionStep: React.FC<RoleSelectionStepProps> = ({
  selectedRole,
  onSelectRole,
  onContinue,
  onBack,
  userEmail,
  userName,
}) => {
  return (
    <div className="space-y-6">
      {/* Title & Introduction */}
      <div className="text-center space-y-1">
        <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
          How will you use SkillOrbit?
        </h2>
        <p className="text-xs text-slate-600 dark:text-slate-400 max-w-sm mx-auto">
          {userName ? `Welcome, ${userName}! ` : ''}
          Choose the pathway that best describes your primary objective.
        </p>
      </div>

      {/* Two Large Selectable Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* Option 1: Student */}
        <button
          type="button"
          onClick={() => onSelectRole('student')}
          className={`p-5 rounded-2xl border-2 text-left transition relative cursor-pointer flex flex-col justify-between ${
            selectedRole === 'student'
              ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/25 shadow-sm'
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-start justify-between w-full mb-3">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 ${
              selectedRole === 'student'
                ? 'bg-indigo-600 text-white'
                : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300'
            }`}>
              <GraduationCap className="w-5 h-5" />
            </div>

            <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
              selectedRole === 'student'
                ? 'border-indigo-600 bg-indigo-600 text-white'
                : 'border-slate-300 dark:border-slate-600'
            }`}>
              {selectedRole === 'student' && <CheckCircle2 className="w-4 h-4" />}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>🎓</span>
              <span>I'm a Student</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
              Build my skills, discover opportunities, and prepare for my career.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] font-medium text-indigo-600 dark:text-indigo-400">
            Includes Verified Skill Graph & Matches →
          </div>
        </button>

        {/* Option 2: Company / Recruiter */}
        <button
          type="button"
          onClick={() => onSelectRole('recruiter')}
          className={`p-5 rounded-2xl border-2 text-left transition relative cursor-pointer flex flex-col justify-between ${
            selectedRole === 'recruiter'
              ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/25 shadow-sm'
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-start justify-between w-full mb-3">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 ${
              selectedRole === 'recruiter'
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300'
            }`}>
              <Briefcase className="w-5 h-5" />
            </div>

            <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
              selectedRole === 'recruiter'
                ? 'border-emerald-600 bg-emerald-600 text-white'
                : 'border-slate-300 dark:border-slate-600'
            }`}>
              {selectedRole === 'recruiter' && <CheckCircle2 className="w-4 h-4" />}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>💼</span>
              <span>We Are Hiring</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
              Find skilled candidates, discover talent, and hire for opportunities.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
            Access Candidate Pipelines & Campus Drives →
          </div>
        </button>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        {onBack ? (
          <button
            type="button"
            onClick={onBack}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        ) : <div />}

        <button
          type="button"
          onClick={onContinue}
          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
        >
          <span>Continue as {selectedRole === 'student' ? 'Student' : 'Recruiter'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
