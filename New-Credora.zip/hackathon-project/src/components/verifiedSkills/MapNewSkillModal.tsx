import React, { useState, useMemo } from 'react';
import { 
  X, 
  Search, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  AlertCircle,
  Code2,
  Database,
  Cpu,
  Globe,
  Sparkles,
  Info
} from 'lucide-react';
import { 
  SkillVerificationCatalogueItem, 
  UserVerifiedSkill, 
  VerifiedSkillCategory 
} from '../../types/verifiedSkills';

interface MapNewSkillModalProps {
  isOpen: boolean;
  onClose: () => void;
  catalogue: SkillVerificationCatalogueItem[];
  userSkills: UserVerifiedSkill[];
  onAddSkill: (catalogueItem: SkillVerificationCatalogueItem) => void;
  onOpenAssessmentRegistration: (skillName: string) => void;
}

export const MapNewSkillModal: React.FC<MapNewSkillModalProps> = ({
  isOpen,
  onClose,
  catalogue,
  userSkills,
  onAddSkill,
  onOpenAssessmentRegistration
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Categories');
  const [selectedSkill, setSelectedSkill] = useState<SkillVerificationCatalogueItem | null>(null);

  const categories = [
    'All Categories',
    'Programming Languages',
    'Web Development',
    'Databases',
    'Core Computer Science',
    'Emerging Technologies'
  ];

  // Filter skills
  const filteredSkills = useMemo(() => {
    return catalogue.filter(item => {
      const matchesCat = selectedCategory === 'All Categories' || item.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q || 
        item.name.toLowerCase().includes(q) || 
        item.description.toLowerCase().includes(q) ||
        item.curriculum.some(c => c.toLowerCase().includes(q));
      return matchesCat && matchesQuery;
    });
  }, [catalogue, selectedCategory, searchQuery]);

  // If selected skill is not set or not in filtered, default to first or keep
  const activeSkill = selectedSkill || filteredSkills[0] || null;

  // Check if active skill is already in userSkills
  const existingUserSkill = useMemo(() => {
    if (!activeSkill) return null;
    return userSkills.find(
      us => us.skillId === activeSkill.id || us.skillName.toLowerCase() === activeSkill.name.toLowerCase()
    );
  }, [activeSkill, userSkills]);

  if (!isOpen) return null;

  const getCategoryIcon = (cat: VerifiedSkillCategory) => {
    switch (cat) {
      case 'Programming Languages': return <Code2 className="w-3.5 h-3.5" />;
      case 'Web Development': return <Globe className="w-3.5 h-3.5" />;
      case 'Databases': return <Database className="w-3.5 h-3.5" />;
      case 'Core Computer Science': return <Cpu className="w-3.5 h-3.5" />;
      case 'Emerging Technologies': return <Sparkles className="w-3.5 h-3.5" />;
      default: return <Code2 className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-200 bg-white flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-6 h-6 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
                +
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Official Verification Catalogue
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              What skill would you like to add?
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Select a skill from our official verification catalogue and add it to your profile.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50/70 space-y-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by skill name, topic, or keyword (e.g. Python, SQL, React, Algorithms)..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-xs"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition border ${
                  selectedCategory === cat
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Body: Skills list (left) & Detailed preview (right) */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 min-h-0 overflow-hidden">
          {/* Left Column: List of Skills */}
          <div className="md:col-span-5 border-b md:border-b-0 md:border-r border-slate-200 overflow-y-auto p-3 sm:p-4 space-y-2 max-h-60 md:max-h-full">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
              Available Skills ({filteredSkills.length})
            </div>

            {filteredSkills.length === 0 ? (
              <div className="text-center py-8 px-4 text-slate-400 text-xs">
                No matching skills found in the catalogue. Try a different search term.
              </div>
            ) : (
              filteredSkills.map((item) => {
                const isSelected = activeSkill?.id === item.id;
                const isAlreadyMapped = userSkills.some(
                  us => us.skillId === item.id || us.skillName.toLowerCase() === item.name.toLowerCase()
                );
                const userSkillEntry = userSkills.find(
                  us => us.skillId === item.id || us.skillName.toLowerCase() === item.name.toLowerCase()
                );

                return (
                  <button
                    key={item.id}
                    onClick={() => setSelectedSkill(item)}
                    className={`w-full text-left p-3 rounded-2xl transition border flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-300 ring-1 ring-indigo-200'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-2xl shrink-0 p-1.5 bg-slate-100 rounded-xl">{item.iconEmoji}</span>
                      <div className="truncate">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {item.name}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          {getCategoryIcon(item.category)}
                          {item.category}
                        </span>
                      </div>
                    </div>

                    {isAlreadyMapped ? (
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                        userSkillEntry?.status === 'Professionally-Verified'
                          ? 'bg-emerald-100 text-emerald-800'
                          : userSkillEntry?.status === 'Assessment-Scheduled'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {userSkillEntry?.status === 'Professionally-Verified' ? '🛡️ Verified' : 'Mapped'}
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full shrink-0">
                        Available
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>

          {/* Right Column: Skill Detail Preview */}
          <div className="md:col-span-7 overflow-y-auto p-5 sm:p-6 bg-slate-50/40 flex flex-col justify-between">
            {activeSkill ? (
              <div className="space-y-5">
                {/* Header Information */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="text-4xl p-3 bg-white rounded-2xl shadow-xs border border-slate-200">
                      {activeSkill.iconEmoji}
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                        {activeSkill.name}
                      </h3>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        <span className="inline-flex items-center gap-1 text-xs font-semibold bg-white border border-slate-200 text-slate-700 px-2.5 py-0.5 rounded-lg">
                          {getCategoryIcon(activeSkill.category)}
                          {activeSkill.category}
                        </span>
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-lg">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {activeSkill.verificationStatus}
                        </span>
                        <span className="inline-flex items-center gap-1 text-xs text-slate-500 bg-white border border-slate-200 px-2.5 py-0.5 rounded-lg">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          {activeSkill.assessmentDuration}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                    Skill & Assessment Overview
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {activeSkill.description}
                  </p>
                </div>

                {/* Standardized Assessment Structure */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-indigo-600" />
                      Standardized Evaluation Matrix (100%)
                    </h4>
                    <span className="text-[11px] font-semibold text-slate-500">Controlled Offline Center</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <div className="text-base font-black text-slate-900 font-mono">
                        {activeSkill.structure.fundamentalsPercent}%
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 mt-0.5">🧠 Fundamentals</div>
                      <div className="text-[9px] text-slate-400">Conceptual & Theory</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <div className="text-base font-black text-indigo-600 font-mono">
                        {activeSkill.structure.problemSolvingPercent}%
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 mt-0.5">🧩 Problem Solving</div>
                      <div className="text-[9px] text-slate-400">Logic & Complexity</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <div className="text-base font-black text-emerald-600 font-mono">
                        {activeSkill.structure.practicalCodingPercent}%
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 mt-0.5">💻 Practical Coding</div>
                      <div className="text-[9px] text-slate-400">Real Challenges</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <div className="text-base font-black text-amber-600 font-mono">
                        {activeSkill.structure.debuggingPercent}%
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 mt-0.5">🐛 Debugging</div>
                      <div className="text-[9px] text-slate-400">Error Correction</div>
                    </div>
                  </div>
                </div>

                {/* Key Syllabus Modules */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Syllabus & Core Assessment Domains
                  </h4>
                  <div className="space-y-1.5">
                    {activeSkill.curriculum.map((topic, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-700 bg-white p-2 rounded-xl border border-slate-100">
                        <span className="w-4 h-4 rounded-full bg-indigo-50 text-indigo-700 font-mono font-bold text-[10px] flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="font-medium">{topic}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Duplicate Check Warning Banner */}
                {existingUserSkill && (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3">
                    <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-xs space-y-1">
                      <p className="font-bold">
                        {activeSkill.name} is already mapped to your profile.
                      </p>
                      <p className="text-amber-800">
                        {existingUserSkill.status === 'Professionally-Verified' ? (
                          <span>This skill is already <strong>Professionally Verified</strong> (Score: {existingUserSkill.score}/1000).</span>
                        ) : existingUserSkill.status === 'Assessment-Scheduled' ? (
                          <span>An assessment is already scheduled on {existingUserSkill.scheduledDate}.</span>
                        ) : (
                          <span>Current Status: <strong>○ Self-Declared</strong>. You can proceed directly to book an assessment slot.</span>
                        )}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400 text-xs">
                Select a skill from the list to view assessment details.
              </div>
            )}

            {/* Action Bar */}
            {activeSkill && (
              <div className="mt-6 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-slate-500 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  Next offline exam cycle: <strong>{activeSkill.nextScheduledDate}</strong>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={onClose}
                    className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition w-full sm:w-auto"
                  >
                    Cancel
                  </button>

                  {existingUserSkill ? (
                    existingUserSkill.status === 'Self-Declared' ? (
                      <button
                        onClick={() => {
                          onClose();
                          onOpenAssessmentRegistration(activeSkill.name);
                        }}
                        className="px-5 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 w-full sm:w-auto"
                      >
                        <span>Get {activeSkill.name} Verified</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-4 py-2.5 rounded-xl text-center w-full sm:w-auto">
                        Already in verification pipeline
                      </span>
                    )
                  ) : (
                    <button
                      onClick={() => {
                        onAddSkill(activeSkill);
                        onClose();
                      }}
                      className="px-6 py-2.5 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 w-full sm:w-auto"
                    >
                      <span>Add to My Skills</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
