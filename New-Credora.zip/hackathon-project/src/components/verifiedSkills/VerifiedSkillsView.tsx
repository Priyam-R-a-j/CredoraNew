import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  Plus, 
  Search, 
  Compass, 
  Award, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  ArrowRight, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  Info,
  MapPin,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Cpu,
  Layers,
  FileCheck2,
  Users,
  Eye
} from 'lucide-react';
import { 
  UserVerifiedSkill, 
  SkillVerificationCatalogueItem, 
  VerificationAdmitCard,
  AssessmentOpportunity,
  VerificationStatus
} from '../../types/verifiedSkills';
import { StudentProfile } from '../../types';
import { SKILL_VERIFICATION_CATALOGUE, UPCOMING_ASSESSMENTS } from '../../data/verifiedSkillsCatalogue';
import { MapNewSkillModal } from './MapNewSkillModal';
import { AdmitCardModal } from './AdmitCardModal';
import { CredentialModal } from './CredentialModal';
import { AssessmentRegistrationModal } from './AssessmentRegistrationModal';

interface VerifiedSkillsViewProps {
  profile: StudentProfile;
  userVerifiedSkills: UserVerifiedSkill[];
  onAddUserSkill: (skill: UserVerifiedSkill) => void;
  onUpdateUserSkill: (updatedSkill: UserVerifiedSkill) => void;
  onNavigateToView?: (view: string) => void;
}

export const VerifiedSkillsView: React.FC<VerifiedSkillsViewProps> = ({
  profile,
  userVerifiedSkills,
  onAddUserSkill,
  onUpdateUserSkill,
  onNavigateToView
}) => {
  // Active category tab inside dashboard
  const [activeTab, setActiveTab] = useState<'all' | 'verified' | 'in_progress' | 'self_declared' | 'explore_assessments'>('all');
  const [searchFilter, setSearchFilter] = useState('');

  // Modals state
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [isAdmitCardOpen, setIsAdmitCardOpen] = useState(false);
  const [selectedAdmitCard, setSelectedAdmitCard] = useState<VerificationAdmitCard | null>(null);

  const [isCredentialOpen, setIsCredentialOpen] = useState(false);
  const [selectedCredentialSkill, setSelectedCredentialSkill] = useState<UserVerifiedSkill | null>(null);

  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);
  const [registrationSkillName, setRegistrationSkillName] = useState<string>('Python');

  // Categories counts
  const verifiedSkills = useMemo(() => {
    return userVerifiedSkills.filter(s => s.status === 'Professionally-Verified');
  }, [userVerifiedSkills]);

  const inProgressSkills = useMemo(() => {
    return userVerifiedSkills.filter(s => 
      s.status === 'Verification-Registered' || 
      s.status === 'Assessment-Scheduled' || 
      s.status === 'Assessment-Completed' || 
      s.status === 'Results-Processing'
    );
  }, [userVerifiedSkills]);

  const selfDeclaredSkills = useMemo(() => {
    return userVerifiedSkills.filter(s => s.status === 'Self-Declared');
  }, [userVerifiedSkills]);

  // Filtered skills based on activeTab and search
  const displayedSkills = useMemo(() => {
    let list = userVerifiedSkills;
    if (activeTab === 'verified') {
      list = verifiedSkills;
    } else if (activeTab === 'in_progress') {
      list = inProgressSkills;
    } else if (activeTab === 'self_declared') {
      list = selfDeclaredSkills;
    }

    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase().trim();
      list = list.filter(s => 
        s.skillName.toLowerCase().includes(q) || 
        s.category.toLowerCase().includes(q)
      );
    }
    return list;
  }, [userVerifiedSkills, activeTab, verifiedSkills, inProgressSkills, selfDeclaredSkills, searchFilter]);

  // Handlers
  const handleAddNewCatalogueSkill = (item: SkillVerificationCatalogueItem) => {
    const newSkill: UserVerifiedSkill = {
      id: `uvs-${Date.now()}`,
      skillId: item.id,
      skillName: item.name,
      iconEmoji: item.iconEmoji,
      category: item.category,
      status: 'Self-Declared',
      dateAdded: new Date().toISOString().split('T')[0]
    };
    onAddUserSkill(newSkill);
  };

  const handleOpenAdmitCard = (admitCard: VerificationAdmitCard) => {
    setSelectedAdmitCard(admitCard);
    setIsAdmitCardOpen(true);
  };

  const handleOpenCredential = (skill: UserVerifiedSkill) => {
    setSelectedCredentialSkill(skill);
    setIsCredentialOpen(true);
  };

  const handleStartRegistrationFor = (skillName: string) => {
    setRegistrationSkillName(skillName);
    setIsRegistrationOpen(true);
  };

  // Quick action: simulate completing assessment for demonstration
  const handleSimulateCompletion = (skill: UserVerifiedSkill) => {
    const updated: UserVerifiedSkill = {
      ...skill,
      status: 'Professionally-Verified',
      proficiencyLevel: 'Advanced',
      score: 875,
      maxScore: 1000,
      percentileRank: 95.2,
      assessmentDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      credentialId: `VS-${skill.skillName.slice(0, 3).toUpperCase()}-2026-${Math.floor(10000 + Math.random() * 90000)}`
    };
    onUpdateUserSkill(updated);
    setSelectedCredentialSkill(updated);
    setIsCredentialOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* FLAGSHIP HERO SECTION */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-950 text-white border border-slate-800 shadow-2xl p-6 sm:p-10">
        {/* Subtle decorative radial gradients */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-emerald-600/15 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          {/* Flagship Badge */}
          <div className="inline-flex items-center gap-2 bg-indigo-500/10 border border-indigo-400/30 px-3.5 py-1.5 rounded-full text-indigo-300 text-xs font-bold tracking-wide">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>STANDARDIZED TECHNICAL PROOF PLATFORM</span>
            <span className="text-slate-500">•</span>
            <span className="text-emerald-400 uppercase text-[10px] font-black tracking-wider">
              Flagship Feature
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight">
            Your Skills Deserve More Than a Claim.
          </h1>

          {/* Core Philosophy Banner */}
          <div className="text-sm sm:text-base font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-indigo-200 to-sky-300 tracking-wide uppercase">
            🛡️ Don't Just Claim Your Skills. Prove Them.
          </div>

          {/* Supporting Text */}
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl font-normal">
            Add your skills, demonstrate your knowledge through standardized assessments, and earn professional verification that recruiters can trust.
          </p>

          {/* Primary Action Buttons */}
          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsMapModalOpen(true)}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold rounded-2xl shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 group cursor-pointer"
            >
              <Plus className="w-4 h-4 text-white group-hover:rotate-90 transition-transform duration-200" />
              <span>+ Map New Skill</span>
            </button>

            <button
              onClick={() => setActiveTab('explore_assessments')}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-bold rounded-2xl border border-slate-700 transition flex items-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Explore Assessments</span>
            </button>
          </div>
        </div>

        {/* Quick Summary Metrics Grid */}
        <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-8 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-black text-white font-mono">
              {userVerifiedSkills.length}
            </div>
            <div className="text-[11px] font-bold text-slate-400 mt-1 uppercase tracking-wider">
              Total Mapped Skills
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-800/50">
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono flex items-center gap-1.5">
              <span>{verifiedSkills.length}</span>
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-[11px] font-bold text-emerald-300 mt-1 uppercase tracking-wider">
              🛡️ Professionally Verified
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-800/50">
            <div className="text-2xl sm:text-3xl font-black text-indigo-400 font-mono">
              {inProgressSkills.length}
            </div>
            <div className="text-[11px] font-bold text-indigo-300 mt-1 uppercase tracking-wider">
              📅 In Verification Pipeline
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-black text-slate-300 font-mono">
              {selfDeclaredSkills.length}
            </div>
            <div className="text-[11px] font-bold text-slate-400 mt-1 uppercase tracking-wider">
              ○ Self-Declared Only
            </div>
          </div>
        </div>
      </div>

      {/* RECRUITER PERSPECTIVE BANNER: THE CORE DISTINCTION */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-indigo-600">
            <Info className="w-4 h-4" />
            The SkillOrbit Verification Paradigm
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900">
            What recruiters see on your profile
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Most job portals allow candidates to claim any skill without evidence. On SkillOrbit, recruiters filter specifically for candidates with standardized offline examination credentials.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
            <div className="flex items-center gap-1.5 text-emerald-900 font-black text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>🛡️ PROFESSIONALLY VERIFIED</span>
            </div>
            <p className="text-[11px] text-emerald-800 mt-1.5 leading-normal">
              Independently demonstrated in an authorized testing center with sandbox compilers. Displays official score & level.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="flex items-center gap-1.5 text-slate-800 font-bold text-xs">
              <span className="w-3.5 h-3.5 rounded-full border-2 border-slate-400 inline-block" />
              <span>○ SELF-DECLARED SKILL</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5 leading-normal">
              Claimed by candidate; not yet independently assessed or verified by the platform. No platform score or badge.
            </p>
          </div>
        </div>
      </div>

      {/* SKILL VERIFICATION JOURNEY (INTERACTIVE TIMELINE) */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              The Standardized Verification Journey
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Every verified competency follows a transparent, invigilated 6-stage lifecycle.
            </p>
          </div>
          <span className="text-[11px] font-semibold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 self-start sm:self-auto">
            Authorized Examination Centers
          </span>
        </div>

        {/* 6-Phase Interactive Progress Tracker */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-2">
          {[
            {
              step: '1',
              title: 'Self-Declared',
              icon: '○',
              desc: 'Candidate maps skill to profile',
              color: 'border-slate-200 bg-slate-50 text-slate-700'
            },
            {
              step: '2',
              title: 'Verification Registered',
              icon: '📝',
              desc: 'Selects assessment cycle',
              color: 'border-blue-200 bg-blue-50/70 text-blue-900'
            },
            {
              step: '3',
              title: 'Assessment Scheduled',
              icon: '📅',
              desc: 'Admit card & seat assigned',
              color: 'border-indigo-200 bg-indigo-50/70 text-indigo-900'
            },
            {
              step: '4',
              title: 'Assessment Completed',
              icon: '⏳',
              desc: '2-hour offline terminal exam',
              color: 'border-amber-200 bg-amber-50/70 text-amber-900'
            },
            {
              step: '5',
              title: 'Results Processing',
              icon: '📊',
              desc: 'Automated test suite review',
              color: 'border-purple-200 bg-purple-50/70 text-purple-900'
            },
            {
              step: '6',
              title: 'Professionally Verified',
              icon: '🛡️',
              desc: 'Digital credential issued',
              color: 'border-emerald-300 bg-emerald-50 text-emerald-950 font-bold'
            }
          ].map((phase, idx) => (
            <div key={idx} className={`p-3 rounded-2xl border ${phase.color} flex flex-col justify-between text-xs space-y-1 relative`}>
              <div className="flex items-center justify-between">
                <span className="text-sm">{phase.icon}</span>
                <span className="text-[9px] font-mono font-bold uppercase opacity-60">
                  Step {phase.step}
                </span>
              </div>
              <div>
                <div className="font-bold tracking-tight text-xs leading-snug">{phase.title}</div>
                <div className="text-[10px] opacity-75 mt-0.5 leading-tight">{phase.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DASHBOARD TABS & SEARCH BAR */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold no-scrollbar">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-2 rounded-xl transition whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              All Skills ({userVerifiedSkills.length})
            </button>

            <button
              onClick={() => setActiveTab('verified')}
              className={`px-3.5 py-2 rounded-xl transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'verified'
                  ? 'bg-emerald-600 text-white shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span>🛡️ Verified</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeTab === 'verified' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>
                {verifiedSkills.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('in_progress')}
              className={`px-3.5 py-2 rounded-xl transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'in_progress'
                  ? 'bg-indigo-600 text-white shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span>📅 In Progress</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeTab === 'in_progress' ? 'bg-indigo-700 text-white' : 'bg-slate-100 text-slate-700'}`}>
                {inProgressSkills.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('self_declared')}
              className={`px-3.5 py-2 rounded-xl transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'self_declared'
                  ? 'bg-slate-800 text-white shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span>○ Self-Declared</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${activeTab === 'self_declared' ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-700'}`}>
                {selfDeclaredSkills.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('explore_assessments')}
              className={`px-3.5 py-2 rounded-xl transition whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'explore_assessments'
                  ? 'bg-indigo-900 text-white shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Explore Assessments</span>
            </button>
          </div>

          {/* Search Box */}
          {activeTab !== 'explore_assessments' && (
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Filter my mapped skills..."
                className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}
        </div>

        {/* TAB CONTENT: EXPLORE ASSESSMENTS */}
        {activeTab === 'explore_assessments' ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  Standardized Skill Verification Examination Drives
                </h3>
                <p className="text-xs text-slate-500">
                  Attend invigilated offline assessment sessions held in authorized university and regional centers.
                </p>
              </div>

              <span className="text-xs text-slate-500 bg-slate-100 px-3 py-1 rounded-xl font-semibold">
                Controlled Terminal Environment (2 Hours)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {UPCOMING_ASSESSMENTS.map((opp) => (
                <div
                  key={opp.id}
                  className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <span className="text-3xl p-2 bg-slate-50 rounded-2xl border border-slate-100">
                        {opp.iconEmoji}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        opp.availability === 'Limited Seats'
                          ? 'bg-rose-100 text-rose-800'
                          : opp.availability === 'Fast Filling'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {opp.availability} ({opp.seatsRemaining} seats left)
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{opp.skillName}</h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">{opp.category}</p>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs">
                      <div className="flex items-center justify-between text-slate-600">
                        <span>Assessment Date:</span>
                        <strong className="text-slate-900">{opp.assessmentDate}</strong>
                      </div>
                      <div className="flex items-center justify-between text-slate-600">
                        <span>Reporting Time:</span>
                        <span className="font-medium text-slate-800">{opp.reportingTime}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-600">
                        <span>Duration:</span>
                        <span className="font-medium text-slate-800">{opp.duration}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-600 pt-1 border-t border-slate-200">
                        <span>Test Center:</span>
                        <span className="font-medium text-slate-800 truncate max-w-[150px]">{opp.testCenterName}</span>
                      </div>
                    </div>

                    {/* Weightage Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase">
                        <span>Evaluation Structure</span>
                        <span>100% Comprehensive</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex">
                        <div className="bg-slate-400 h-full" style={{ width: `${opp.structure.fundamentalsPercent}%` }} title="Fundamentals 20%" />
                        <div className="bg-indigo-600 h-full" style={{ width: `${opp.structure.problemSolvingPercent}%` }} title="Problem Solving 30%" />
                        <div className="bg-emerald-600 h-full" style={{ width: `${opp.structure.practicalCodingPercent}%` }} title="Practical Coding 40%" />
                        <div className="bg-amber-500 h-full" style={{ width: `${opp.structure.debuggingPercent}%` }} title="Debugging 10%" />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleStartRegistrationFor(opp.skillName)}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <span>Register for Assessment</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* TAB CONTENT: SKILLS LIST */
          <div className="space-y-4">
            {displayedSkills.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-3xl border border-dashed border-slate-300 space-y-3">
                <ShieldCheck className="w-12 h-12 text-slate-300 mx-auto" />
                <h4 className="text-base font-bold text-slate-800">No skills in this category yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Click "+ Map New Skill" to select a skill from our official catalogue and begin your verification journey.
                </p>
                <button
                  onClick={() => setIsMapModalOpen(true)}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Map New Skill</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {displayedSkills.map((skill) => {
                  const isVerified = skill.status === 'Professionally-Verified';
                  const isInProgress = skill.status === 'Verification-Registered' || skill.status === 'Assessment-Scheduled';
                  const isSelfDeclared = skill.status === 'Self-Declared';

                  return (
                    <div
                      key={skill.id}
                      className={`p-5 rounded-3xl transition flex flex-col justify-between space-y-4 ${
                        isVerified
                          ? 'bg-white border-2 border-emerald-300 shadow-md ring-1 ring-emerald-100'
                          : isInProgress
                          ? 'bg-white border-2 border-indigo-200 shadow-xs'
                          : 'bg-white border border-slate-200 shadow-xs'
                      }`}
                    >
                      {/* Card Header */}
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <span className="text-3xl p-2 bg-slate-50 rounded-2xl border border-slate-100">
                              {skill.iconEmoji}
                            </span>
                            <div>
                              <h3 className="font-black text-slate-900 text-base flex items-center gap-1.5">
                                {skill.skillName}
                              </h3>
                              <span className="text-[11px] text-slate-500">
                                {skill.category}
                              </span>
                            </div>
                          </div>

                          {/* Status Badge */}
                          <div>
                            {isVerified && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-1 rounded-full">
                                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                                <span>Verified</span>
                              </span>
                            )}
                            {isInProgress && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-300 px-2.5 py-1 rounded-full">
                                <Calendar className="w-3.5 h-3.5 text-blue-700" />
                                <span>Scheduled</span>
                              </span>
                            )}
                            {isSelfDeclared && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 px-2.5 py-1 rounded-full">
                                <span className="w-2 h-2 rounded-full border border-slate-400" />
                                <span>Self-Declared</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Card Body by Status */}
                        {isVerified && (
                          <div className="p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-2 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-600">Demonstrated Level:</span>
                              <strong className="text-indigo-900 font-bold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                                {skill.proficiencyLevel || 'Advanced'}
                              </strong>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-slate-600">Assessment Score:</span>
                              <strong className="text-emerald-900 font-mono font-bold text-sm">
                                {skill.score}/1000
                              </strong>
                            </div>
                            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-emerald-200/60">
                              <span>Assessment Date:</span>
                              <span>{skill.assessmentDate}</span>
                            </div>
                          </div>
                        )}

                        {isInProgress && (
                          <div className="p-3.5 rounded-2xl bg-indigo-50/50 border border-indigo-200 space-y-2 text-xs">
                            <div className="flex items-center gap-1.5 text-indigo-950 font-bold">
                              <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                              <span>{skill.status.replace('-', ' ')}</span>
                            </div>
                            <div className="text-[11px] text-slate-600 space-y-1">
                              <div>Exam Date: <strong>{skill.scheduledDate}</strong></div>
                              {skill.testCenter && (
                                <div className="truncate">Center: <strong>{skill.testCenter}</strong></div>
                              )}
                              {skill.seatNumber && (
                                <div>Assigned Seat: <strong className="font-mono text-indigo-700">{skill.seatNumber}</strong></div>
                              )}
                            </div>
                          </div>
                        )}

                        {isSelfDeclared && (
                          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                            <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                              <Info className="w-3.5 h-3.5 text-slate-400" />
                              <span>Not independently assessed yet.</span>
                            </div>
                            <p className="text-[11px] text-slate-500 leading-normal">
                              This skill has been added by the candidate but has not yet been independently assessed or verified by the platform.
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Card Action Footer */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                        {isVerified && (
                          <button
                            onClick={() => handleOpenCredential(skill)}
                            className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            <span>View Credential</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {isInProgress && (
                          <div className="flex items-center gap-1.5 w-full">
                            {skill.admitCard ? (
                              <button
                                onClick={() => handleOpenAdmitCard(skill.admitCard!)}
                                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span>Admit Card</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => handleStartRegistrationFor(skill.skillName)}
                                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                              >
                                <span>View Details</span>
                              </button>
                            )}

                            {/* Simulation button for demo test-drive */}
                            <button
                              onClick={() => handleSimulateCompletion(skill)}
                              title="Simulate passing official evaluation for prototype demo"
                              className="px-2.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[10px] font-bold rounded-xl transition shrink-0"
                            >
                              Verify
                            </button>
                          </div>
                        )}

                        {isSelfDeclared && (
                          <button
                            onClick={() => handleStartRegistrationFor(skill.skillName)}
                            className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <span>Get Verified</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* MODALS */}
      {/* 1. Map New Skill Searchable Dropdown Modal */}
      <MapNewSkillModal
        isOpen={isMapModalOpen}
        onClose={() => setIsMapModalOpen(false)}
        catalogue={SKILL_VERIFICATION_CATALOGUE}
        userSkills={userVerifiedSkills}
        onAddSkill={handleAddNewCatalogueSkill}
        onOpenAssessmentRegistration={handleStartRegistrationFor}
      />

      {/* 2. Admit Card Hall Ticket Modal */}
      <AdmitCardModal
        isOpen={isAdmitCardOpen}
        onClose={() => setIsAdmitCardOpen(false)}
        admitCard={selectedAdmitCard}
      />

      {/* 3. High-Resolution Digital Credential Modal */}
      <CredentialModal
        isOpen={isCredentialOpen}
        onClose={() => setIsCredentialOpen(false)}
        skill={selectedCredentialSkill}
        candidateName={profile.fullName}
        institutionName={profile.institutionName}
      />

      {/* 4. Assessment Registration & Slot Booking Modal */}
      <AssessmentRegistrationModal
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
        skillName={registrationSkillName}
        catalogue={SKILL_VERIFICATION_CATALOGUE}
        userSkills={userVerifiedSkills}
        candidateName={profile.fullName}
        candidateEmail={profile.universityEmail}
        institutionName={profile.institutionName}
        onConfirmRegistration={(updated) => {
          onUpdateUserSkill(updated);
          if (updated.admitCard) {
            setSelectedAdmitCard(updated.admitCard);
            setIsAdmitCardOpen(true);
          }
        }}
      />
    </div>
  );
};
