import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  ArrowRight, 
  AlertCircle,
  Building2
} from 'lucide-react';
import { 
  SkillVerificationCatalogueItem, 
  UserVerifiedSkill, 
  VerificationAdmitCard 
} from '../../types/verifiedSkills';

interface AssessmentRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  skillName?: string;
  catalogue: SkillVerificationCatalogueItem[];
  userSkills: UserVerifiedSkill[];
  candidateName: string;
  candidateEmail: string;
  institutionName: string;
  onConfirmRegistration: (updatedSkill: UserVerifiedSkill) => void;
}

export const AssessmentRegistrationModal: React.FC<AssessmentRegistrationModalProps> = ({
  isOpen,
  onClose,
  skillName,
  catalogue,
  userSkills,
  candidateName,
  candidateEmail,
  institutionName,
  onConfirmRegistration
}) => {
  const [selectedSkillName, setSelectedSkillName] = useState(skillName || catalogue[0]?.name || 'Python');
  const [selectedCenter, setSelectedCenter] = useState('Manipal University Jaipur - High-Performance Computing Lab 3');
  const [selectedDate, setSelectedDate] = useState('October 12, 2026');
  const [selectedSlot, setSelectedSlot] = useState('09:00 AM (Slot 1)');
  const [agreedToGuidelines, setAgreedToGuidelines] = useState(true);

  if (!isOpen) return null;

  // Catalogue item
  const catalogueItem = catalogue.find(c => c.name.toLowerCase() === selectedSkillName.toLowerCase()) || catalogue[0];

  const testCenters = [
    {
      name: 'Manipal University Jaipur - High-Performance Computing Lab 3',
      address: 'Dehmi Kalan, Jaipur-Ajmer Expressway, Academic Block 2, Lab 003',
      city: 'Jaipur, Rajasthan',
      type: 'On-Campus Authorized Hub'
    },
    {
      name: 'National Standardized Testing Center, Sector 62',
      address: 'Plot 14, Institutional Area, Electronic City',
      city: 'Noida / NCR',
      type: 'Regional Examination Center'
    },
    {
      name: 'Innovation & Computing Center of Excellence',
      address: 'Whitefield Main Road, Silicon Corridor',
      city: 'Bengaluru, Karnataka',
      type: 'Industry Partner Lab'
    }
  ];

  const availableDates = [
    { date: 'October 12, 2026', seats: '14 seats remaining' },
    { date: 'October 19, 2026', seats: '28 seats remaining' },
    { date: 'November 2, 2026', seats: '45 seats remaining' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreedToGuidelines) return;

    const verificationId = `VS-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    const seatNumber = `A-${Math.floor(100 + Math.random() * 899)}`;
    const roomNumber = 'AB2-G03';

    const admitCard: VerificationAdmitCard = {
      verificationId,
      candidateName,
      candidateEmail,
      institutionName,
      rollNumber: '239103049',
      skillName: catalogueItem.name,
      iconEmoji: catalogueItem.iconEmoji,
      assessmentDate: selectedDate,
      reportingTime: selectedSlot.split(' ')[0],
      duration: catalogueItem.assessmentDuration,
      assignedTestCenter: selectedCenter,
      centerAddress: testCenters.find(c => c.name === selectedCenter)?.address || 'Campus Examination Hall',
      seatNumber,
      roomNumber,
      qrCodeToken: `${institutionName.slice(0, 3).toUpperCase()}-${verificationId}-${catalogueItem.id}`,
      instructions: [
        'Mandatory physical reporting time is 30 minutes prior to exam start. Terminal locked at scheduled time.',
        'Carry your institutional Student ID Card and a printed or digital copy of this Admit Card.',
        'Assessment terminal operates in an air-gapped sandboxed runtime with automated unit test harnesses.',
        'Calculators and electronic devices are strictly prohibited.'
      ]
    };

    // Find if user already has this skill as self-declared
    const existing = userSkills.find(
      us => us.skillName.toLowerCase() === catalogueItem.name.toLowerCase()
    );

    const updatedSkill: UserVerifiedSkill = {
      id: existing?.id || `uvs-${Date.now()}`,
      skillId: catalogueItem.id,
      skillName: catalogueItem.name,
      iconEmoji: catalogueItem.iconEmoji,
      category: catalogueItem.category,
      status: 'Assessment-Scheduled',
      currentPhaseStep: 3,
      dateAdded: existing?.dateAdded || new Date().toISOString().split('T')[0],
      scheduledDate: selectedDate,
      reportingTime: selectedSlot.split(' ')[0],
      testCenter: selectedCenter,
      seatNumber,
      admitCard
    };

    onConfirmRegistration(updatedSkill);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-200 bg-white flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Examination Registration
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Schedule Skill Verification Assessment
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Book a seat at an authorized proctored testing center to verify your technical competency.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-xs sm:text-sm">
          {/* Skill Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              Skill to Verify
            </label>
            <select
              value={selectedSkillName}
              onChange={(e) => setSelectedSkillName(e.target.value)}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            >
              {catalogue.map(item => (
                <option key={item.id} value={item.name}>
                  {item.iconEmoji} {item.name} ({item.category})
                </option>
              ))}
            </select>
          </div>

          {/* Test Center Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              Select Authorized Offline Examination Center
            </label>
            <div className="space-y-2">
              {testCenters.map((center) => (
                <label
                  key={center.name}
                  onClick={() => setSelectedCenter(center.name)}
                  className={`p-3.5 rounded-2xl border flex items-start justify-between gap-3 cursor-pointer transition ${
                    selectedCenter === center.name
                      ? 'bg-indigo-50/80 border-indigo-400 ring-1 ring-indigo-300'
                      : 'bg-white hover:bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="radio"
                      name="testCenter"
                      checked={selectedCenter === center.name}
                      onChange={() => setSelectedCenter(center.name)}
                      className="mt-1 text-indigo-600 focus:ring-indigo-500"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm">{center.name}</span>
                        <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {center.type}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{center.address} · {center.city}</p>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Date & Slot Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Examination Date
              </label>
              <div className="space-y-1.5">
                {availableDates.map(item => (
                  <button
                    type="button"
                    key={item.date}
                    onClick={() => setSelectedDate(item.date)}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between text-xs transition ${
                      selectedDate === item.date
                        ? 'bg-slate-900 text-white border-slate-900 font-bold'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span>{item.date}</span>
                    <span className={`text-[10px] ${selectedDate === item.date ? 'text-emerald-300' : 'text-slate-400'}`}>
                      {item.seats}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Reporting Slot
              </label>
              <div className="space-y-1.5">
                {['09:00 AM (Slot 1)', '01:30 PM (Slot 2)'].map(slot => (
                  <button
                    type="button"
                    key={slot}
                    onClick={() => setSelectedSlot(slot)}
                    className={`w-full p-2.5 rounded-xl border text-left text-xs transition ${
                      selectedSlot === slot
                        ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {slot}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Assessment Structure Preview */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              Standardized Assessment Weightage ({catalogueItem.assessmentDuration})
            </h4>
            <div className="grid grid-cols-4 gap-2 text-center pt-1">
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="font-mono font-bold text-slate-900 text-xs">20%</span>
                <span className="block text-[9px] text-slate-500 font-medium mt-0.5">Fundamentals</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="font-mono font-bold text-indigo-600 text-xs">30%</span>
                <span className="block text-[9px] text-slate-500 font-medium mt-0.5">Problem Solving</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="font-mono font-bold text-emerald-600 text-xs">40%</span>
                <span className="block text-[9px] text-slate-500 font-medium mt-0.5">Practical Code</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="font-mono font-bold text-amber-600 text-xs">10%</span>
                <span className="block text-[9px] text-slate-500 font-medium mt-0.5">Debugging</span>
              </div>
            </div>
          </div>

          {/* Confirmation Terms */}
          <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
            <input
              type="checkbox"
              checked={agreedToGuidelines}
              onChange={(e) => setAgreedToGuidelines(e.target.checked)}
              className="mt-0.5 text-indigo-600 focus:ring-indigo-500 rounded"
            />
            <span className="text-xs text-slate-600 leading-normal">
              I acknowledge that this is an in-person, proctored examination. I will report at the assigned center with my original Student ID card at least 30 minutes before the scheduled time.
            </span>
          </label>

          {/* Submit Action */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={!agreedToGuidelines}
              className="px-6 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <span>Confirm & Generate Admit Card</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
