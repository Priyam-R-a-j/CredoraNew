import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Award, 
  CheckCircle2, 
  Share2, 
  Copy, 
  Download, 
  ExternalLink, 
  QrCode,
  Lock,
  Sparkles
} from 'lucide-react';
import { UserVerifiedSkill } from '../../types/verifiedSkills';

interface CredentialModalProps {
  isOpen: boolean;
  onClose: () => void;
  skill: UserVerifiedSkill | null;
  candidateName: string;
  institutionName: string;
}

export const CredentialModal: React.FC<CredentialModalProps> = ({
  isOpen,
  onClose,
  skill,
  candidateName,
  institutionName
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !skill || skill.status !== 'Professionally-Verified') return null;

  const credentialId = skill.credentialId || `VS-${skill.skillName.slice(0, 3).toUpperCase()}-2026-${Math.floor(10000 + Math.random() * 90000)}`;
  const score = skill.score || 847;
  const maxScore = skill.maxScore || 1000;
  const level = skill.proficiencyLevel || 'Advanced';
  const assessmentDate = skill.assessmentDate || 'October 5, 2026';

  const verificationUrl = `https://verify.skillorbit.org/credentials/${credentialId}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(verificationUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Top Control Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Verified Digital Credential
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition shadow-2xs"
            >
              <Copy className="w-3.5 h-3.5 text-slate-500" />
              <span>{copied ? 'Copied Link!' : 'Copy Verification URL'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-xl transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Canvas */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 bg-slate-100/60">
          <div className="bg-white rounded-2xl border-4 border-slate-900 p-6 sm:p-8 relative shadow-lg overflow-hidden">
            {/* Background Seal Watermark */}
            <div className="absolute right-4 bottom-4 opacity-5 pointer-events-none">
              <ShieldCheck className="w-64 h-64 text-slate-900" />
            </div>

            {/* Corner Decorative Borders */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-indigo-600" />
            <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-indigo-600" />
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-indigo-600" />
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-indigo-600" />

            {/* Header */}
            <div className="text-center space-y-2 pb-6 border-b border-slate-200">
              <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full text-emerald-800 text-xs font-bold tracking-wide">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>OFFICIAL VERIFIED SKILL CREDENTIAL</span>
              </div>
              <h2 className="text-xs font-bold tracking-widest text-slate-400 uppercase mt-2">
                SKILLORBIT STANDARDIZED TECHNICAL EXAMINATION BOARD
              </h2>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight font-serif">
                Certificate of Demonstrated Competency
              </div>
            </div>

            {/* Certification Body */}
            <div className="py-6 text-center space-y-4">
              <p className="text-xs sm:text-sm text-slate-500 font-medium">
                This is to certify that
              </p>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight underline decoration-indigo-300 decoration-2 underline-offset-8">
                {candidateName}
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Candidate of <span className="font-semibold text-slate-800">{institutionName}</span>
              </p>

              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto pt-2">
                has successfully appeared for the standardized proctored offline examination and demonstrated independent professional proficiency in
              </p>

              {/* Verified Skill Subject Pill */}
              <div className="inline-flex items-center gap-2.5 bg-slate-900 text-white px-5 py-2.5 rounded-2xl shadow-md">
                <span className="text-2xl">{skill.iconEmoji}</span>
                <span className="text-lg sm:text-xl font-black tracking-tight uppercase">
                  {skill.skillName}
                </span>
              </div>

              {/* Assessment Stats Banner */}
              <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto pt-4 text-center">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Skill Level</div>
                  <div className="text-sm sm:text-base font-black text-indigo-700 mt-0.5">
                    {level}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Assessment Score</div>
                  <div className="text-sm sm:text-base font-black text-emerald-700 font-mono mt-0.5">
                    {score} / {maxScore}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Examination Date</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-800 mt-0.5">
                    {assessmentDate}
                  </div>
                </div>
              </div>
            </div>

            {/* Credential ID, Verification QR & Signature */}
            <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-slate-900 rounded-xl p-1 flex items-center justify-center shrink-0">
                  <QrCode className="w-11 h-11 text-white" />
                </div>
                <div className="text-left">
                  <div className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                    Verification ID
                  </div>
                  <div className="font-mono font-bold text-indigo-700 text-xs">
                    {credentialId}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-600" />
                    Cryptographically Tamper-Evident
                  </div>
                </div>
              </div>

              <div className="text-center sm:text-right">
                <div className="font-serif italic font-bold text-slate-900 text-sm">
                  Dr. Vikramaditya Sen
                </div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                  Director, Central Examination Board
                </div>
                <div className="text-[9px] text-slate-400">
                  SkillOrbit National Verification Network
                </div>
              </div>
            </div>
          </div>

          {/* Recruiter Trust Explainer */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Verified Authenticity Guarantee
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Unlike self-declared tags on traditional job portals, this credential confirms that <strong>{candidateName}</strong> solved practical algorithmic and implementation challenges in an invigilated testing center with sandbox compilers.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-mono">
            {verificationUrl}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleCopyLink}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl transition"
            >
              {copied ? 'Copied URL' : 'Copy Public Link'}
            </button>
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-5 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
