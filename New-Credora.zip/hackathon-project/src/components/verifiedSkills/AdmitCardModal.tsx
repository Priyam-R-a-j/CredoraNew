import React, { useRef } from 'react';
import { 
  X, 
  Printer, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  Building2, 
  QrCode, 
  AlertTriangle,
  FileCheck2,
  Download
} from 'lucide-react';
import { VerificationAdmitCard } from '../../types/verifiedSkills';

interface AdmitCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  admitCard: VerificationAdmitCard | null;
}

export const AdmitCardModal: React.FC<AdmitCardModalProps> = ({
  isOpen,
  onClose,
  admitCard
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !admitCard) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Official Examination Hall Ticket
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-xl transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Container */}
        <div ref={printRef} className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-900 bg-white">
          {/* Institutional Watermark & Header */}
          <div className="border-2 border-slate-900 rounded-2xl p-5 sm:p-6 relative bg-gradient-to-b from-slate-50/70 to-white">
            {/* Header branding */}
            <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4 mb-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-xl shadow-xs">
                  <ShieldCheck className="w-7 h-7 text-emerald-400" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-black tracking-tight uppercase text-slate-900">
                      SkillOrbit Assessment Board
                    </span>
                    <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                      Authorized Center
                    </span>
                  </div>
                  <h1 className="text-lg sm:text-xl font-black text-slate-950 tracking-tight mt-0.5">
                    SKILL VERIFICATION ADMIT CARD
                  </h1>
                  <p className="text-[11px] text-slate-500 font-medium">
                    National Standardized Technical Examination Hall Ticket
                  </p>
                </div>
              </div>

              <div className="text-right hidden sm:block">
                <div className="text-[10px] font-bold uppercase text-slate-400">Verification ID</div>
                <div className="text-sm font-mono font-black text-indigo-700 tracking-wide">
                  {admitCard.verificationId}
                </div>
                <div className="text-[10px] text-slate-400 mt-1">Status: Confirmed</div>
              </div>
            </div>

            {/* Candidate & Exam Metadata Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              {/* Candidate Info Box */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Candidate Information
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Full Legal Name</span>
                  <span className="text-sm font-bold text-slate-900">{admitCard.candidateName}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Institutional Roll No</span>
                    <span className="font-mono font-bold text-slate-800">{admitCard.rollNumber}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">University / Institution</span>
                    <span className="font-medium text-slate-800 truncate block">{admitCard.institutionName}</span>
                  </div>
                </div>
                <div className="pt-1">
                  <span className="text-slate-500 block text-[10px]">Official Email</span>
                  <span className="font-mono text-slate-700 text-[11px]">{admitCard.candidateEmail}</span>
                </div>
              </div>

              {/* Assessment & Slot Box */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Assessment Schedule
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Target Competency</span>
                  <span className="text-sm font-bold text-indigo-700 flex items-center gap-1.5">
                    <span>{admitCard.iconEmoji}</span>
                    <span>{admitCard.skillName}</span>
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Assessment Date</span>
                    <span className="font-bold text-slate-900">{admitCard.assessmentDate}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Reporting Time</span>
                    <span className="font-bold text-amber-700">{admitCard.reportingTime}</span>
                  </div>
                </div>
                <div className="pt-1">
                  <span className="text-slate-500 block text-[10px]">Assessment Duration</span>
                  <span className="font-medium text-slate-800">{admitCard.duration}</span>
                </div>
              </div>
            </div>

            {/* Test Center & Seat Allocation Box */}
            <div className="mt-4 p-4 rounded-xl bg-indigo-50/60 border border-indigo-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-indigo-900">
                    <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                    Assigned Offline Examination Center
                  </div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {admitCard.assignedTestCenter}
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {admitCard.centerAddress}
                  </div>
                </div>

                {/* Seat & Room Badges */}
                <div className="flex items-center gap-2 shrink-0">
                  <div className="px-3 py-2 bg-white rounded-xl border border-indigo-200 text-center shadow-2xs">
                    <span className="block text-[9px] font-bold text-slate-400 uppercase">Room</span>
                    <span className="font-mono font-bold text-xs text-slate-800">{admitCard.roomNumber}</span>
                  </div>
                  <div className="px-4 py-2 bg-indigo-600 text-white rounded-xl shadow-xs text-center">
                    <span className="block text-[9px] font-bold text-indigo-200 uppercase tracking-wide">Assigned Seat</span>
                    <span className="font-mono font-black text-sm">{admitCard.seatNumber}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* QR Barcode & Digital Verification Security Stripe */}
            <div className="mt-4 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {/* Simulated QR Code */}
                <div className="w-16 h-16 bg-slate-900 rounded-xl p-1.5 flex items-center justify-center shrink-0">
                  <QrCode className="w-13 h-13 text-white" />
                </div>
                <div className="text-[11px] text-slate-600">
                  <span className="font-mono font-bold text-slate-900 block text-xs">
                    TOKEN: {admitCard.qrCodeToken}
                  </span>
                  <span>Proctor biometric scan required at entrance gate.</span>
                  <span className="text-slate-400 block text-[10px]">Tamper-evident verification token encoded.</span>
                </div>
              </div>

              <div className="text-right sm:text-right w-full sm:w-auto text-[10px] text-slate-400">
                Authorized Signature
                <div className="font-serif italic font-bold text-slate-800 text-sm mt-0.5">
                  Dr. Rajesh V. Raman
                </div>
                <span>Dean of Examinations & Compliance</span>
              </div>
            </div>
          </div>

          {/* Mandatory Instructions */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-wider">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              Controlled Examination Instructions & Protocol
            </h4>
            <ul className="space-y-1.5 text-slate-600 list-disc list-inside text-[11px] leading-relaxed">
              {admitCard.instructions.map((inst, idx) => (
                <li key={idx}>{inst}</li>
              ))}
              <li>The test terminal will run a locked-down browser environment with sandbox compilers and automated unit test harnesses.</li>
              <li>Candidates are scored across 4 dimensions: Conceptual Fundamentals (20%), Problem Solving (30%), Practical Coding (40%), and Debugging (10%).</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Official SkillOrbit Examination Credential Document
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-xl transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
