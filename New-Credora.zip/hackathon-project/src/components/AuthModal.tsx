import React, { useState, useEffect } from 'react';
import { 
  X, ShieldCheck, Mail, Sparkles, User, Briefcase, GraduationCap, 
  ChevronRight, ArrowRight, ArrowLeft, CheckCircle2 
} from 'lucide-react';
import { GoogleIcon, LinkedInIcon, GitHubIcon, FacebookIcon } from './auth/BrandIcons';
import { OAuthSimModal, OAuthProvider } from './auth/OAuthSimModal';
import { RoleSelectionStep } from './auth/RoleSelectionStep';
import { StudentOnboarding, StudentOnboardingData } from './auth/StudentOnboarding';
import { RecruiterOnboarding, RecruiterOnboardingData } from './auth/RecruiterOnboarding';
import { EmailAuthSteps } from './auth/EmailAuthSteps';
import { UserRole, DegreeLevel, UserSkill } from '../types';
import { CANONICAL_SKILLS } from '../data/skills';

export interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  targetRole?: UserRole;
  targetView?: string;
  onLoginSuccess: (user: any, role?: UserRole, targetView?: string) => void;
}

type AuthFlowView = 
  | 'welcome' 
  | 'email_auth' 
  | 'role_selection' 
  | 'student_onboarding' 
  | 'recruiter_onboarding';

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  targetRole = 'student',
  targetView,
  onLoginSuccess,
}) => {
  // Main view state
  const [currentView, setCurrentView] = useState<AuthFlowView>('welcome');
  
  // Selected role for onboarding
  const [selectedRole, setSelectedRole] = useState<'student' | 'recruiter'>('student');
  
  // Authenticated user credentials buffer
  const [authUser, setAuthUser] = useState<{
    fullName: string;
    email: string;
    avatar?: string;
    provider?: string;
  }>({
    fullName: '',
    email: '',
  });

  // OAuth Simulation modal state
  const [activeOAuthProvider, setActiveOAuthProvider] = useState<OAuthProvider | null>(null);

  // Synchronize target role when prop changes
  useEffect(() => {
    if (targetRole === 'recruiter') {
      setSelectedRole('recruiter');
    } else {
      setSelectedRole('student');
    }
  }, [targetRole]);

  // Reset or initialize on open
  useEffect(() => {
    if (isOpen) {
      // If user specifically requested 'login' or 'register', we start at the simple welcome screen as required:
      // "When the user clicks Get Started / Sign Up / Log In from the homepage, open a centered authentication modal.
      // The first screen should be extremely simple: Heading: Welcome to SkillOrbit, Supporting text: Sign in or create your account to continue."
      setCurrentView('welcome');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle direct login from existing account (OAuth or Email)
  const handleDirectLogin = (user: {
    fullName: string;
    email: string;
    institution?: string;
    role: UserRole;
    avatar?: string;
  }) => {
    onLoginSuccess(
      {
        fullName: user.fullName,
        email: user.email,
        institution: user.institution || (user.role === 'student' ? 'Manipal University Jaipur' : 'Google'),
        role: user.role,
        avatar: user.avatar,
      },
      user.role,
      targetView
    );
    onClose();
  };

  // Handle OAuth provider click
  const handleOpenOAuth = (provider: OAuthProvider) => {
    setActiveOAuthProvider(provider);
  };

  // Handle OAuth new user continuous progression
  const handleOAuthNewUser = (user: {
    fullName: string;
    email: string;
    avatar?: string;
    provider: OAuthProvider;
  }) => {
    setAuthUser({
      fullName: user.fullName,
      email: user.email,
      avatar: user.avatar,
      provider: user.provider,
    });
    setActiveOAuthProvider(null);
    setCurrentView('role_selection');
  };

  // Handle email verified for new user
  const handleEmailVerified = (verifiedEmail: string) => {
    setAuthUser(prev => ({
      ...prev,
      email: verifiedEmail,
      fullName: prev.fullName || verifiedEmail.split('@')[0],
      provider: 'email',
    }));
    setCurrentView('role_selection');
  };

  // Handle Student Onboarding Completion
  const handleStudentOnboardingComplete = (data: StudentOnboardingData) => {
    // Map chosen degree to system DegreeLevel
    let sysDegreeLevel: DegreeLevel = 'BTech';
    if (data.degreeName.includes('M.Tech') || data.degreeName.includes('MS') || data.degreeName.includes('M.Sc')) {
      sysDegreeLevel = 'MTech';
    } else if (data.degreeName.includes('B.Sc') || data.degreeName.includes('BCA')) {
      sysDegreeLevel = 'BSc';
    } else if (data.degreeName.includes('MBA') || data.degreeName.includes('BBA')) {
      sysDegreeLevel = 'MBA';
    } else if (data.courseLevel === 'PhD' || data.degreeName.includes('PhD')) {
      sysDegreeLevel = 'PhD';
    } else if (data.courseLevel === 'Diploma') {
      sysDegreeLevel = 'Other';
    }

    // Convert selected skills to UserSkill objects
    const newSkills: UserSkill[] = data.selectedSkills.map((skName, i) => {
      const canonical = CANONICAL_SKILLS.find(c => c.name.toLowerCase() === skName.toLowerCase());
      return {
        id: `us-new-${Date.now()}-${i}`,
        skillId: canonical ? canonical.id : `sk-custom-${i}`,
        name: skName,
        category: canonical ? canonical.category : 'Programming',
        level: 'Intermediate',
        proficiencyScore: 75,
        verified: false,
        evidence: [
          {
            id: `ev-${i}-1`,
            type: 'Course',
            title: `Academic Coursework in ${skName} at ${data.institutionName === 'Other' ? data.customInstitution : data.institutionName}`,
            organizationOrPlatform: data.institutionName === 'Other' ? (data.customInstitution || 'University') : data.institutionName,
            verified: true,
            dateCompleted: new Date().toISOString().split('T')[0],
          }
        ],
      };
    });

    const studentUser = {
      fullName: `${data.firstName} ${data.lastName}`,
      email: authUser.email || `${data.firstName.toLowerCase()}.${data.lastName.toLowerCase()}@university.edu`,
      institution: data.institutionName === 'Other' ? (data.customInstitution || 'Custom Institution') : data.institutionName,
      role: 'student' as UserRole,
      degreeLevel: sysDegreeLevel,
      courseLevel: data.courseLevel,
      degreeName: data.degreeName === 'Other' ? data.customDegree : data.degreeName,
      major: data.major,
      currentYear: data.currentYear,
      graduationYear: data.graduationYear,
      city: data.city,
      country: data.country,
      githubUrl: data.githubUrl,
      linkedinUrl: data.linkedinUrl,
      portfolioUrl: data.portfolioUrl,
      skills: newSkills,
      interests: data.interests,
    };

    onLoginSuccess(studentUser, 'student', targetView);
    onClose();
  };

  // Handle Recruiter Onboarding Completion
  const handleRecruiterOnboardingComplete = (data: RecruiterOnboardingData) => {
    const recruiterUser = {
      fullName: data.fullName,
      email: data.workEmail,
      institution: data.companyName,
      role: 'recruiter' as UserRole,
      companyName: data.companyName,
      companyWebsite: data.website,
      industry: data.industry,
      city: data.city,
      country: data.country,
      hiringNeeds: {
        types: data.hiringTypes,
        domains: data.hiringDomains,
        skills: data.requiredSkills,
        experienceLevel: data.experienceLevel,
        workPreference: data.workPreference,
      }
    };

    onLoginSuccess(recruiterUser, 'recruiter', targetView);
    onClose();
  };

  return (
    <>
      <div 
        className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
        role="dialog"
        aria-modal="true"
      >
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-xl max-h-[92vh] overflow-hidden flex flex-col transition-all duration-200">
          
          {/* Modal Header */}
          <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                ⬡
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                  <span>SkillOrbit</span>
                  <span className="text-[10px] font-mono font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-1.5 py-0.2 rounded">
                    Verified Ecosystem
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">
                  Universal Skill Verification &amp; Career Trajectory
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Modal Body Container with Scroll */}
          <div className="p-5 sm:p-6 overflow-y-auto flex-1">

            {/* =========================================================
                SCREEN 1: AUTHENTICATION ENTRY POPUP (WELCOME)
               ========================================================= */}
            {currentView === 'welcome' && (
              <div className="space-y-6 text-center animate-in fade-in duration-150">
                {/* Heading & Supporting Text */}
                <div className="space-y-1.5">
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                    Welcome to SkillOrbit
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-sm mx-auto">
                    Sign in or create your account to continue.
                  </p>
                </div>

                {/* Social Login Options */}
                <div className="space-y-2.5 max-w-md mx-auto">
                  {/* Google */}
                  <button
                    type="button"
                    onClick={() => handleOpenOAuth('google')}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-bold transition shadow-2xs hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer"
                  >
                    <GoogleIcon className="w-4 h-4 shrink-0" />
                    <span>Continue with Google</span>
                  </button>

                  {/* LinkedIn */}
                  <button
                    type="button"
                    onClick={() => handleOpenOAuth('linkedin')}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-bold transition shadow-2xs hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer"
                  >
                    <LinkedInIcon className="w-4 h-4 shrink-0" />
                    <span>Continue with LinkedIn</span>
                  </button>

                  {/* GitHub */}
                  <button
                    type="button"
                    onClick={() => handleOpenOAuth('github')}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-bold transition shadow-2xs hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer"
                  >
                    <GitHubIcon className="w-4 h-4 shrink-0" />
                    <span>Continue with GitHub</span>
                  </button>

                  {/* Facebook */}
                  <button
                    type="button"
                    onClick={() => handleOpenOAuth('facebook')}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-bold transition shadow-2xs hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer"
                  >
                    <FacebookIcon className="w-4 h-4 shrink-0" />
                    <span>Continue with Facebook</span>
                  </button>
                </div>

                {/* Divider: OR */}
                <div className="relative flex py-1 items-center max-w-md mx-auto">
                  <div className="grow border-t border-slate-200 dark:border-slate-800" />
                  <span className="shrink mx-3 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                    OR
                  </span>
                  <div className="grow border-t border-slate-200 dark:border-slate-800" />
                </div>

                {/* Continue with Email */}
                <div className="max-w-md mx-auto">
                  <button
                    type="button"
                    onClick={() => setCurrentView('email_auth')}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                  >
                    <Mail className="w-4 h-4 shrink-0" />
                    <span>Continue with Email</span>
                  </button>
                </div>

                {/* Quick Instant Demo Access */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 max-w-md mx-auto">
                  <div className="text-[11px] text-slate-400 dark:text-slate-500 mb-2 flex items-center justify-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>Quick Preview &amp; Demo Personas:</span>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 text-left">
                    {/* Demo Student */}
                    <button
                      type="button"
                      onClick={() => handleDirectLogin({
                        fullName: 'Aarav Sharma',
                        email: 'student@jaipur.manipal.edu',
                        institution: 'Manipal University Jaipur',
                        role: 'student',
                        avatar: 'AS',
                      })}
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 bg-slate-50/70 dark:bg-slate-800/50 transition cursor-pointer"
                    >
                      <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                        <GraduationCap className="w-3 h-3 text-indigo-600 shrink-0" />
                        <span>Student</span>
                      </div>
                      <div className="text-[9px] text-slate-500 truncate">Aarav (MUJ)</div>
                    </button>

                    {/* Demo Recruiter */}
                    <button
                      type="button"
                      onClick={() => handleDirectLogin({
                        fullName: 'Priya Nair',
                        email: 'priya.nair@google.com',
                        institution: 'Google Campus Talent',
                        role: 'recruiter',
                        avatar: 'PN',
                      })}
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-400 bg-slate-50/70 dark:bg-slate-800/50 transition cursor-pointer"
                    >
                      <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                        <Briefcase className="w-3 h-3 text-emerald-600 shrink-0" />
                        <span>Recruiter</span>
                      </div>
                      <div className="text-[9px] text-slate-500 truncate">Priya (Google)</div>
                    </button>

                    {/* Demo University Admin */}
                    <button
                      type="button"
                      onClick={() => handleDirectLogin({
                        fullName: 'Dr. Sandeep Sancheti',
                        email: 'dean.academics@jaipur.manipal.edu',
                        institution: 'Manipal University Jaipur',
                        role: 'university_admin',
                        avatar: 'SS',
                      })}
                      className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-400 bg-slate-50/70 dark:bg-slate-800/50 transition cursor-pointer"
                    >
                      <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-blue-600 shrink-0" />
                        <span>University</span>
                      </div>
                      <div className="text-[9px] text-slate-500 truncate">Academic Dean</div>
                    </button>
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 dark:text-slate-500 pt-1">
                  By signing in, you agree to SkillOrbit's Academic Data Privacy Charter, Digilocker Verification Policy, and Terms of Service.
                </p>
              </div>
            )}

            {/* =========================================================
                SCREEN 2: EMAIL AUTH (SIGN IN / SIGN UP / VERIFICATION)
               ========================================================= */}
            {currentView === 'email_auth' && (
              <EmailAuthSteps
                initialMode={initialMode === 'register' ? 'signup' : 'signin'}
                onExistingUserLogin={handleDirectLogin}
                onNewUserVerified={handleEmailVerified}
                onBackToWelcome={() => setCurrentView('welcome')}
              />
            )}

            {/* =========================================================
                SCREEN 3: ROLE SELECTION (STUDENT vs WE ARE HIRING)
               ========================================================= */}
            {currentView === 'role_selection' && (
              <RoleSelectionStep
                selectedRole={selectedRole}
                onSelectRole={setSelectedRole}
                onContinue={() => {
                  if (selectedRole === 'student') {
                    setCurrentView('student_onboarding');
                  } else {
                    setCurrentView('recruiter_onboarding');
                  }
                }}
                onBack={() => setCurrentView('welcome')}
                userEmail={authUser.email}
                userName={authUser.fullName}
              />
            )}

            {/* =========================================================
                SCREEN 4: STUDENT ONBOARDING (6 PROGRESSIVE STEPS)
               ========================================================= */}
            {currentView === 'student_onboarding' && (
              <StudentOnboarding
                initialEmail={authUser.email}
                initialFullName={authUser.fullName}
                initialAvatar={authUser.avatar}
                onComplete={handleStudentOnboardingComplete}
                onBackToRoleSelection={() => setCurrentView('role_selection')}
              />
            )}

            {/* =========================================================
                SCREEN 5: RECRUITER / HIRING ONBOARDING
               ========================================================= */}
            {currentView === 'recruiter_onboarding' && (
              <RecruiterOnboarding
                initialEmail={authUser.email}
                initialFullName={authUser.fullName}
                onComplete={handleRecruiterOnboardingComplete}
                onBackToRoleSelection={() => setCurrentView('role_selection')}
              />
            )}

          </div>
        </div>
      </div>

      {/* OAuth simulation modal for Google, LinkedIn, GitHub, Facebook */}
      {activeOAuthProvider && (
        <OAuthSimModal
          provider={activeOAuthProvider}
          isOpen={!!activeOAuthProvider}
          onClose={() => setActiveOAuthProvider(null)}
          onSelectExistingUser={handleDirectLogin}
          onContinueAsNewUser={handleOAuthNewUser}
        />
      )}
    </>
  );
};
