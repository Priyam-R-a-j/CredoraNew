import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  FileCheck2, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  X,
  FileText,
  KeyRound,
  DatabaseZap
} from 'lucide-react';
import { StudentProfile } from '../types';

interface VerificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  profile: StudentProfile;
  onUpdateVisibility: (recruiterSearchable: boolean) => void;
}

export const VerificationCenter: React.FC<VerificationCenterProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateVisibility
}) => {
  const [recruiterSearchable, setRecruiterSearchable] = useState(profile.privacySettings?.recruiterSearchable ?? true);
  const [directMessaging, setDirectMessaging] = useState(profile.privacySettings?.allowDirectRecruiterContact ?? true);
  const [showSaveAlert, setShowSaveAlert] = useState(false);

  if (!isOpen) return null;

  const handleToggleRecruiter = (val: boolean) => {
    setRecruiterSearchable(val);
    onUpdateVisibility(val);
    setShowSaveAlert(true);
    setTimeout(() => setShowSaveAlert(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Institutional Verification & Privacy Center
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Cryptographic verification status, data minimization safeguards & recruiter visibility
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-md">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-xs">
          {showSaveAlert && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Privacy settings synchronized securely across enterprise search indexes.</span>
            </div>
          )}

          {/* Current Verification Status Box */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 text-sm">
                Current Verification Status
              </span>
              <span className="font-extrabold text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified Candidate
              </span>
            </div>

            <div className="grid sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Method</span>
                <strong className="text-slate-800 text-xs">University Domain SSO</strong>
              </div>
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Institution</span>
                <strong className="text-slate-800 text-xs truncate block">{profile.institutionName}</strong>
              </div>
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Verified Date</span>
                <strong className="text-slate-800 text-xs font-mono">{profile.verification.verifiedAt || '2026-08-15'}</strong>
              </div>
            </div>
          </div>

          {/* Data Minimization Architecture Explainer */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-indigo-600" />
              <span>Zero Raw Storage Architecture & Privacy Controls</span>
            </h3>
            <p className="text-slate-600 leading-relaxed">
              SkillOrbit enforces strict data minimization principles. We do not store raw government identification numbers or sensitive student identity documents on cloud databases. Verification is executed using zero-knowledge cryptographic status tokens, keeping your personal records safe.
            </p>

            <div className="grid sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3 rounded-xl border border-slate-200 bg-white">
                <div className="flex items-center gap-2 font-bold text-slate-800 mb-1">
                  <KeyRound className="w-4 h-4 text-emerald-600" />
                  <span>Tokenized Attestations</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Transcripts and student records are signed via institutional SHA-256 tokens.
                </p>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 bg-white">
                <div className="flex items-center gap-2 font-bold text-slate-800 mb-1">
                  <DatabaseZap className="w-4 h-4 text-indigo-600" />
                  <span>Audit Trail Immutability</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Every recruiter inspection or verification action is permanently logged with IP masking.
                </p>
              </div>
            </div>
          </div>

          {/* Granular Recruiter Visibility Controls */}
          <div className="pt-4 border-t border-slate-200 space-y-3">
            <h3 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
              Recruiter Discovery & Privacy Permissions
            </h3>

            <div className="p-4 rounded-xl border border-slate-200 bg-white flex items-center justify-between gap-4">
              <div>
                <span className="font-bold text-slate-900 block">
                  Allow Verified Corporate Recruiters to Discover Your Profile
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  When enabled, talent acquisition leads at Google, NVIDIA, JPMorgan, etc. can match you to unlisted opportunities.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={recruiterSearchable}
                  onChange={(e) => handleToggleRecruiter(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
              </label>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-white flex items-center justify-between gap-4">
              <div>
                <span className="font-bold text-slate-900 block">
                  Direct Recruiter Contact & Interview Invitations
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Receive direct campus interview invitations from verified talent acquisition leads.
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={directMessaging}
                  onChange={(e) => setDirectMessaging(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
