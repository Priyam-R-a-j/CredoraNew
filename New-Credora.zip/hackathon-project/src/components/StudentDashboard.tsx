import React, { useState } from 'react';
import { 
  Sparkles, 
  Briefcase, 
  Layers, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Compass, 
  ShieldCheck, 
  Clock, 
  BookOpen, 
  ExternalLink,
  Target,
  FileCheck,
  Zap,
  TrendingUp,
  Bookmark,
  ChevronRight
} from 'lucide-react';
import { 
  StudentProfile, 
  UserSkill, 
  Opportunity, 
  CareerPath, 
  ApplicationRecord 
} from '../types';
import { calculateOpportunityMatch, calculatePlacementReadiness } from '../utils/matching';

interface StudentDashboardProps {
  profile: StudentProfile;
  skills: UserSkill[];
  opportunities: Opportunity[];
  targetCareer: CareerPath;
  applications: ApplicationRecord[];
  onSelectOpportunity: (opp: Opportunity) => void;
  onNavigate: (view: string) => void;
  onOpenVerification: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  profile,
  skills,
  opportunities,
  targetCareer,
  applications,
  onSelectOpportunity,
  onNavigate,
  onOpenVerification
}) => {
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiSource, setAiSource] = useState<string | null>(null);

  const readiness = calculatePlacementReadiness(profile, skills);

  // Top recommended opportunities computed in real time
  const scoredOpportunities = opportunities
    .map(opp => ({
      opp,
      match: calculateOpportunityMatch(opp, profile, skills)
    }))
    .sort((a, b) => b.match.overallScore - a.match.overallScore)
    .slice(0, 3);

  const handleRunAiAssessment = async () => {
    setLoadingAi(true);
    try {
      const res = await fetch('/api/ai/career-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRole: targetCareer.title,
          currentSkills: skills.map(s => s.name),
          major: profile.major,
          graduationYear: profile.graduationYear
        })
      });
      const data = await res.json();
      if (data.success) {
        setAiAdvice(data.advice);
        setAiSource(data.source);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAi(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Student Profile & Career Command Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-600 text-white font-extrabold text-2xl flex items-center justify-center shrink-0 shadow-sm">
            AS
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                {profile.fullName}
              </h1>
              <span className="inline-flex items-center gap-1 text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">
                <ShieldCheck className="w-3.5 h-3.5" /> Institutional Verified
              </span>
              <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                Class of {profile.graduationYear}
              </span>
            </div>
            <p className="text-sm font-semibold text-slate-600 mt-1">
              {profile.degreeLevel} in {profile.major} · <span className="text-indigo-600 font-bold">{profile.institutionName}</span>
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 mt-2">
              <span>Target Role: <strong className="text-slate-800">{targetCareer.title}</strong></span>
              <span>•</span>
              <span>CGPA: <strong className="text-slate-800">{profile.cgpa} / 10.0</strong></span>
              <span>•</span>
              <span>Profile Completion: <strong className="text-indigo-600">{profile.profileCompletionPercentage}%</strong></span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <button
            onClick={() => onNavigate('skillmap')}
            className="flex-1 md:flex-none flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-xs"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Manage Skill Map</span>
          </button>
          <button
            onClick={() => onNavigate('opportunities')}
            className="flex-1 md:flex-none flex items-center justify-center gap-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-4 py-2.5 rounded-xl text-xs font-bold transition"
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Find Opportunities</span>
          </button>
        </div>
      </div>

      {/* Grid: Placement Readiness Gauge & Career Trajectory */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Placement Readiness Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Target className="w-4 h-4 text-indigo-600" /> Career Readiness Index
              </span>
              <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                Placement Ready
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-4">
              <span className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
                {readiness.overallScore}%
              </span>
              <span className="text-xs text-slate-400 font-medium">overall placement benchmark</span>
            </div>

            {/* Progress Breakdown Bars */}
            <div className="space-y-3 mt-6">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Technical Competencies</span>
                  <span>{readiness.technicalReadiness}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${readiness.technicalReadiness}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Evidence & Credentials</span>
                  <span>{readiness.evidenceStrength}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${readiness.evidenceStrength}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Profile & Academic Verification</span>
                  <span>{readiness.profileCompleteness}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-sky-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${readiness.profileCompleteness}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Strengths & Immediate Action Items */}
            <div className="mt-6 pt-4 border-t border-slate-100 space-y-2">
              <span className="text-xs font-bold text-slate-800 block">Identified Strengths</span>
              {readiness.strengths.slice(0, 2).map((str, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{str}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100">
            <button
              onClick={() => onNavigate('skillmap')}
              className="w-full flex items-center justify-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800 transition"
            >
              <span>Add project evidence to increase score</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Career Trajectory Roadmap (2 Columns) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-indigo-600" /> Career Trajectory Map
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  Current Profile → Target: {targetCareer.title}
                </h3>
              </div>
              <button
                onClick={() => onNavigate('careercompass')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <span>Change Target</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Horizontal Timeline Steps */}
            <div className="grid md:grid-cols-3 gap-4 mt-6">
              {targetCareer.typicalTrajectory.map((step, idx) => {
                const isCurrent = step.step === 2;
                const isCompleted = step.step === 1;
                return (
                  <div 
                    key={idx}
                    className={`p-4 rounded-xl border transition ${
                      isCurrent 
                        ? 'border-indigo-500 bg-indigo-50/40 shadow-xs ring-1 ring-indigo-500/20' 
                        : isCompleted
                        ? 'border-emerald-200 bg-emerald-50/20'
                        : 'border-slate-200 bg-slate-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className={`font-mono font-bold px-2 py-0.5 rounded ${
                        isCurrent 
                          ? 'bg-indigo-600 text-white' 
                          : isCompleted 
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        Phase {step.step}
                      </span>
                      <span className="text-[11px] font-semibold text-slate-500">
                        {isCompleted ? 'Completed' : isCurrent ? 'Active Focus' : 'Target'}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mb-1">{step.title}</h4>
                    <p className="text-[11px] text-slate-600 line-clamp-2">{step.description}</p>
                    <div className="mt-3 pt-2 border-t border-slate-200/60 space-y-1">
                      {step.keyDeliverables.slice(0, 1).map((d, dIdx) => (
                        <div key={dIdx} className="text-[10px] text-slate-700 font-medium flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                          <span className="truncate">{d}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Skill Gap Analysis Box */}
            <div className="mt-6 p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-amber-900">
                    Active Skill Gap for Tier-1 Opportunities
                  </h4>
                  <p className="text-xs text-amber-800 mt-0.5">
                    Target roles expect verified evidence in <strong>Distributed Systems</strong> and <strong>Redis/Caching</strong>.
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('skillmap')}
                className="shrink-0 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold px-3 py-2 rounded-lg transition"
              >
                Learn & Attach Evidence
              </button>
            </div>
          </div>

          {/* AI Advisor Trigger & Display */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            {!aiAdvice ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs text-slate-700 font-medium">
                    Analyze your current skill graph against 2026 hiring standards
                  </span>
                </div>
                <button
                  onClick={handleRunAiAssessment}
                  disabled={loadingAi}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-2 rounded-lg transition flex items-center justify-center gap-1.5 shrink-0"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{loadingAi ? 'Analyzing Skills...' : 'Run Career AI Analysis'}</span>
                </button>
              </div>
            ) : (
              <div className="bg-indigo-50/70 border border-indigo-200 rounded-xl p-4 text-xs text-slate-800 space-y-2">
                <div className="flex items-center justify-between border-b border-indigo-200/60 pb-2">
                  <div className="flex items-center gap-1.5 font-bold text-indigo-900">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>SkillOrbit Career Intelligence Assessment</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-600">{aiSource}</span>
                </div>
                <p className="whitespace-pre-line leading-relaxed text-slate-700 font-medium">
                  {aiAdvice}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recommended Opportunities Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-indigo-600" />
              <span>Personalized High-Match Opportunities</span>
            </h2>
            <p className="text-xs text-slate-500">
              Ranked by verified skills, degree level, and academic cohort requirements
            </p>
          </div>
          <button
            onClick={() => onNavigate('opportunities')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>View All ({opportunities.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {scoredOpportunities.map(({ opp, match }) => (
            <div
              key={opp.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${opp.companyLogoBg} text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs`}>
                      {opp.companyName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-600 transition">
                        {opp.title}
                      </h3>
                      <p className="text-[11px] text-slate-500 font-medium">{opp.companyName} · {opp.workMode}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full inline-block">
                      {match.overallScore}% Match
                    </span>
                  </div>
                </div>

                {/* Match Breakdown pills */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Skills Fit: <strong className="text-slate-800">{match.skillsScore}%</strong></span>
                  <span>Education: <strong className="text-slate-800">{match.educationScore}%</strong></span>
                  <span>Location: <strong className="text-slate-800">{match.locationScore}%</strong></span>
                </div>

                {/* Transparent Match Reason */}
                <div className="mt-3 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-[11px] text-slate-600 space-y-1">
                  <div className="font-semibold text-slate-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Why it matches you:
                  </div>
                  <p className="line-clamp-2">{match.matchReasons[0]}</p>
                </div>

                {/* Missing Skills Indicator */}
                {match.missingSkills.length > 0 && (
                  <div className="mt-2 text-[10px] text-amber-700 flex items-center gap-1">
                    <span className="font-semibold">Missing:</span>
                    <span className="truncate">{match.missingSkills.slice(0, 2).join(', ')}</span>
                  </div>
                )}
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-extrabold text-slate-900 block">{opp.stipendOrSalary.split('+')[0]}</span>
                  <span className="text-[10px] text-slate-400">Deadline: {opp.deadline}</span>
                </div>
                <button
                  onClick={() => onSelectOpportunity(opp)}
                  className="bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold px-3 py-2 rounded-lg transition flex items-center gap-1"
                >
                  <span>Inspect</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Applications & Recent Activities row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Application Tracker mini-preview */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-indigo-600" />
                <span>Active Applications & Saved Drives</span>
              </h3>
              <p className="text-xs text-slate-500">Track interview rounds and assessment deadlines</p>
            </div>
            <button
              onClick={() => onNavigate('applications')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              Open Full Tracker
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {applications.map((app) => (
              <div key={app.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <div className="font-bold text-slate-900">{app.opportunityTitle}</div>
                  <div className="text-slate-500 text-[11px] mt-0.5">{app.companyName} · Applied {app.appliedDate}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`font-semibold px-2 py-0.5 rounded-full text-[11px] ${
                    app.status === 'Interview' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                    app.status === 'Assessment' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {app.status}
                  </span>
                  {app.nextDeadline && (
                    <span className="text-[11px] text-slate-400 font-mono">
                      Due: {app.nextDeadline}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Institutional Verification Status Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" /> Institutional Verification
            </span>
            <h4 className="text-base font-bold text-slate-900 mt-2">
              Identity & Student Status
            </h4>
            <p className="text-xs text-slate-600 mt-1">
              Verified through Manipal University Jaipur official domain (<code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[10px]">@jaipur.manipal.edu</code>).
            </p>

            <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Verification State:</span>
                <strong className="text-emerald-700">Verified</strong>
              </div>
              <div className="flex justify-between">
                <span>Identity Provider:</span>
                <span>Institution SSO Token</span>
              </div>
              <div className="flex justify-between">
                <span>Document Storage:</span>
                <span className="text-slate-500">Zero Raw Storage</span>
              </div>
            </div>
          </div>

          <button
            onClick={onOpenVerification}
            className="w-full mt-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold py-2 rounded-lg transition"
          >
            Review Security & Verification
          </button>
        </div>
      </div>
    </div>
  );
};
