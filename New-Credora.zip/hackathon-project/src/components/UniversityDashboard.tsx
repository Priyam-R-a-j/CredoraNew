import React, { useState } from 'react';
import { 
  GraduationCap, 
  Users, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  FileCheck, 
  Building2, 
  ArrowUpRight, 
  Download,
  Check,
  X
} from 'lucide-react';
import { INSTITUTIONS_DATA } from '../data/institutions';
import { COLLABORATION_PROJECTS } from '../data/collaborations';

export const UniversityDashboard: React.FC = () => {
  const mujInstitution = INSTITUTIONS_DATA[0]; // Manipal University Jaipur
  const [capstones, setCapstones] = useState(COLLABORATION_PROJECTS);
  const [approvedIds, setApprovedIds] = useState<string[]>(['collab-1']);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  const handleToggleApproval = (id: string, name: string) => {
    if (approvedIds.includes(id)) {
      setApprovedIds(approvedIds.filter(x => x !== id));
      setAlertMessage(`Approval revoked for "${name}".`);
    } else {
      setApprovedIds([...approvedIds, id]);
      setAlertMessage(`Academic Dean approval granted for "${name}". Students can now register.`);
    }
    setTimeout(() => setAlertMessage(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-900 text-white font-black text-2xl flex items-center justify-center shrink-0 shadow-sm">
            MUJ
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {mujInstitution.name}
              </h1>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                Accredited Campus
              </span>
            </div>
            <p className="text-sm text-slate-600 font-medium mt-1">
              Directorate of Training & Placements · Dean of Academics
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 mt-2">
              <span>Domain: <code className="font-mono text-indigo-700 bg-indigo-50 px-1 py-0.5 rounded">@{mujInstitution.officialEmailDomains[0]}</code></span>
              <span>•</span>
              <span>Location: <strong>{mujInstitution.city}, {mujInstitution.country}</strong></span>
              <span>•</span>
              <span>Institution Code: <strong className="font-mono">{mujInstitution.code}</strong></span>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            setAlertMessage("Accreditation skill audit report compiled and exported successfully.");
            setTimeout(() => setAlertMessage(null), 4000);
          }}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Accreditation Audit</span>
        </button>
      </div>

      {alertMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{alertMessage}</span>
          </div>
          <button onClick={() => setAlertMessage(null)} className="text-emerald-600 hover:text-emerald-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Cohort Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Enrolled Candidates</span>
            <Users className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-2">14,520</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">
            +18% verified profiles YoY
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Avg Placement Readiness</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-700 mt-2">76.4%</div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            Across BTech, MTech, MBA cohorts
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Verified Skills Mapped</span>
            <Award className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-2">48,290</div>
          <div className="text-[11px] text-slate-500 font-medium mt-1">
            Backed by Git repositories & certificates
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Active Enterprise Drives</span>
            <Building2 className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-2">48</div>
          <div className="text-[11px] text-purple-600 font-semibold mt-1">
            Google, NVIDIA, JPMorgan, Deloitte
          </div>
        </div>
      </div>

      {/* Cohort Skill Trends vs Gaps */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Emerging Strengths */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Cohort Core Competencies (High Supply)</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Top competencies demonstrated with verified artifacts across the student body
          </p>

          <div className="space-y-3 mt-4">
            {[
              { skill: 'Python & Algorithmic Problem Solving', percent: 86, count: '12,480 students' },
              { skill: 'Relational Database Design (SQL & PostgreSQL)', percent: 79, count: '11,470 students' },
              { skill: 'Cloud Fundamentals (AWS & GCP Foundations)', percent: 71, count: '10,310 students' },
              { skill: 'React & Full-Stack TypeScript Engineering', percent: 68, count: '9,870 students' }
            ].map((item, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>{item.skill}</span>
                  <span className="text-slate-400 font-mono text-[11px]">{item.count}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${item.percent}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Critical Curriculum Gaps */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <span>Priority Curriculum Gaps (High Enterprise Demand)</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Areas where recruiters report shortages during campus interviews
          </p>

          <div className="space-y-3 mt-4">
            {[
              { skill: 'Distributed Systems & High-Throughput Caching', deficit: 'High Deficit', action: 'Introduce 6th-sem elective in distributed consensus' },
              { skill: 'Production Kubernetes & Cloud Observability', deficit: 'Moderate Deficit', action: 'Host 3-day bootcamp with industry architects' },
              { skill: 'Financial Econometrics & Quantitative Risk Modeling', deficit: 'High Deficit', action: 'Bridge course for engineering & math students' }
            ].map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-amber-50/60 border border-amber-200/80 text-xs">
                <div className="flex items-center justify-between font-bold text-amber-900">
                  <span>{item.skill}</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">{item.deficit}</span>
                </div>
                <p className="text-[11px] text-amber-800 mt-1">Recommended Action: {item.action}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* University-Industry Capstone Approvals */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Industry Sponsored Capstone Approvals
            </h3>
            <p className="text-xs text-slate-500">
              Approve enterprise challenges for formal semester academic credit
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {approvedIds.length} of {capstones.length} Approved
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {capstones.map((cap) => {
            const isApproved = approvedIds.includes(cap.id);
            return (
              <div key={cap.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{cap.title}</span>
                    <span className="text-[10px] font-semibold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded">
                      {cap.companyName}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">{cap.description}</p>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Mentor: {cap.mentorName} ({cap.mentorTitle}) · Grant: {cap.stipend || 'Semester Grant'} · Open Slots: {cap.openSlots}
                  </div>
                </div>

                <button
                  onClick={() => handleToggleApproval(cap.id, cap.title)}
                  className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    isApproved 
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {isApproved ? <Check className="w-3.5 h-3.5" /> : null}
                  <span>{isApproved ? 'Accredited (Approved)' : 'Approve for Credit'}</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
