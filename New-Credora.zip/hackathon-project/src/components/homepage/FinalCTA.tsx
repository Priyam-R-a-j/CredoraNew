import React from 'react';
import { ArrowRight, Compass, ShieldCheck } from 'lucide-react';

interface FinalCTAProps {
  onGetStarted: () => void;
  onExploreOpportunities: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({
  onGetStarted,
  onExploreOpportunities
}) => {
  return (
    <section className="py-20 sm:py-28 bg-slate-900 text-white relative overflow-hidden">
      {/* Background Architectural Grid */}
      <div 
        className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        
        {/* Pill */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 border border-indigo-500/30 text-indigo-300">
          <Compass className="w-3.5 h-3.5" />
          <span>Launch Your Career Trajectory</span>
        </div>

        {/* Required Heading */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight max-w-3xl mx-auto">
          Your next opportunity starts with understanding your skills.
        </h2>

        {/* Required Supporting Text */}
        <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
          Join students, universities, and companies using SkillOrbit to navigate careers, bridge skill gaps, and discover opportunities.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <button
            type="button"
            onClick={onGetStarted}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm px-7 py-3.5 rounded-xl transition shadow-md flex items-center gap-2 cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            <span>Get Started</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onExploreOpportunities}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-sm px-6 py-3.5 rounded-xl transition cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-400"
          >
            <span>Explore Opportunities</span>
          </button>
        </div>

        {/* Supporting micro-indicators */}
        <div className="pt-6 flex items-center justify-center gap-6 text-xs text-slate-400 font-medium">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            No credit card required
          </span>
          <span>•</span>
          <span>Institutional SSO enabled</span>
        </div>

      </div>
    </section>
  );
};
