import React from 'react';
import { 
  Compass, 
  CheckCircle2, 
  AlertTriangle, 
  ListChecks, 
  ArrowRight, 
  Sparkles,
  TrendingUp,
  Award
} from 'lucide-react';

interface CareerReadinessProps {
  onGoToDashboard: () => void;
}

export const CareerReadiness: React.FC<CareerReadinessProps> = ({ onGoToDashboard }) => {
  return (
    <section id="career-readiness" className="py-20 sm:py-28 bg-slate-50 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200 text-indigo-700">
            <Compass className="w-3.5 h-3.5 text-indigo-600" />
            <span>Actionable Placement Command Center</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            From passive profiles to placement readiness.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            SkillOrbit doesn&apos;t simply show where you stand. Our Career Command Center computes an indexed readiness score, pinpoints your concrete strengths, flags your critical gaps, and issues step-by-step guidance to unlock your next career tier.
          </p>
        </div>

        {/* Career Command Center Realistic Dashboard Visual */}
        <div className="mt-14 max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          
          {/* Top Bar */}
          <div className="p-5 sm:p-6 border-b border-slate-200 bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-white shadow-xs">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                    Candidate Command Center
                  </span>
                  <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded">
                    LIVE DASHBOARD PREVIEW
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                  Aarav Sharma · Target: Software Systems Engineer
                </h3>
              </div>
            </div>

            <button
              type="button"
              onClick={onGoToDashboard}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>Open Full Command Center</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-6 sm:p-7 space-y-6">
            
            {/* Main Placement Readiness 72% Gauge */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/70 to-slate-50 border border-indigo-100 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-1.5 text-center sm:text-left">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                  Comprehensive Placement Readiness Index
                </span>
                <p className="text-xs text-slate-600 max-w-md">
                  Synthesized across verified technical competencies, verified semester GPA, industry capstone contributions, and institutional interview screenings.
                </p>
              </div>

              <div className="flex items-center gap-4 shrink-0">
                <div className="text-right">
                  <div className="text-4xl font-black text-indigo-600 font-mono tracking-tight">
                    72%
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Placement Index
                  </span>
                </div>
                <div className="w-20 bg-slate-200 h-3 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full rounded-full w-[72%]" />
                </div>
              </div>
            </div>

            {/* Strengths vs Skill Gaps */}
            <div className="grid sm:grid-cols-2 gap-5">
              
              {/* Strengths */}
              <div className="p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-950 text-xs sm:text-sm flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Verified Strengths
                  </span>
                  <span className="text-[10px] font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded font-bold">
                    3 Core Pillars
                  </span>
                </div>

                <ul className="space-y-2 text-xs text-slate-700">
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-emerald-100">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">Python</strong>: Advanced object-oriented design &amp; AsyncIO mastery verified.
                    </div>
                  </li>
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-emerald-100">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">Communication</strong>: Institutional technical seminar endorsement (9.0/10).
                    </div>
                  </li>
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-emerald-100">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">Projects</strong>: 2 production repositories deployed with live URLs and GitHub commits.
                    </div>
                  </li>
                </ul>
              </div>

              {/* Skill Gaps */}
              <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-100 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-950 text-xs sm:text-sm flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Identified Skill Gaps
                  </span>
                  <span className="text-[10px] font-mono text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-bold">
                    Target Next
                  </span>
                </div>

                <ul className="space-y-2 text-xs text-slate-700">
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-amber-100">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">SQL &amp; Relational Modeling</strong>: Query optimization and schema indexing gap.
                    </div>
                  </li>
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-amber-100">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">Data Structures</strong>: Graph search (Dijkstra, Topological sort) assessment score pending.
                    </div>
                  </li>
                  <li className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-amber-100">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mt-1 shrink-0" />
                    <div>
                      <strong className="text-slate-900">Git &amp; CI/CD</strong>: Automated GitHub Actions branch protection workflows missing.
                    </div>
                  </li>
                </ul>
              </div>

            </div>

            {/* Recommended Next Steps Sequence */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <ListChecks className="w-4 h-4 text-indigo-600" />
                  Recommended Next Steps
                </span>
                <span className="text-[11px] text-slate-500">
                  Target: Increase Readiness from 72% → 85%
                </span>
              </div>

              <div className="grid sm:grid-cols-4 gap-2.5">
                {[
                  { step: '1', title: 'Complete SQL fundamentals', time: 'Est. 4 days', type: 'Coursework' },
                  { step: '2', title: 'Build one data project', time: 'Est. 1 week', type: 'Portfolio' },
                  { step: '3', title: 'Take assessment', time: '60 mins', type: 'Assessment' },
                  { step: '4', title: 'Apply to matched internships', time: 'Direct SSO', type: 'Opportunity' }
                ].map((item) => (
                  <div key={item.step} className="bg-white p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-mono font-bold text-[10px] flex items-center justify-center">
                        {item.step}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400">{item.time}</span>
                    </div>
                    <p className="font-bold text-slate-800 text-xs mt-1 leading-snug">
                      {item.title}
                    </p>
                    <span className="text-[10px] text-indigo-600 font-medium block">
                      {item.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
