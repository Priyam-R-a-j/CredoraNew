import React from 'react';
import { 
  Sparkles, 
  Layers, 
  Search, 
  Hammer, 
  Briefcase, 
  GraduationCap, 
  ArrowRight,
  Compass
} from 'lucide-react';

interface ProductJourneyProps {
  onNavigateToView: (view: string) => void;
}

export const ProductJourney: React.FC<ProductJourneyProps> = ({ onNavigateToView }) => {
  const steps = [
    {
      num: '01',
      action: 'Understand',
      title: 'Discover and organize your skills.',
      description: 'Audit your foundational knowledge, programming toolchains, coursework, and technical capabilities in a structured repository.',
      icon: Sparkles,
      targetView: 'skillmap'
    },
    {
      num: '02',
      action: 'Map',
      title: 'See how your skills connect to careers.',
      description: 'Visualize your competencies mapped directly against realistic industry career tracks, from Quantitative Tech to Robotics.',
      icon: Layers,
      targetView: 'careercompass'
    },
    {
      num: '03',
      action: 'Identify',
      title: 'Find the skills you are missing.',
      description: 'Get an automated, transparent breakdown of prerequisite gaps and target technologies required for your dream roles.',
      icon: Search,
      targetView: 'careercompass'
    },
    {
      num: '04',
      action: 'Build',
      title: 'Learn, practice, and create projects.',
      description: 'Bridge gaps through verified academic coursework, production GitHub repositories, and industry-sponsored capstones.',
      icon: Hammer,
      targetView: 'collaborations'
    },
    {
      num: '05',
      action: 'Discover',
      title: 'Find internships, jobs, projects, and opportunities.',
      description: 'Access curated campus placement drives and enterprise opportunities with exact match rationale and eligibility criteria.',
      icon: Briefcase,
      targetView: 'opportunities'
    },
    {
      num: '06',
      action: 'Prepare',
      title: 'Track your placement readiness.',
      description: 'Monitor your comprehensive Placement Readiness Index and interview pipeline in an actionable Career Command Center.',
      icon: GraduationCap,
      targetView: 'dashboard'
    }
  ];

  return (
    <section id="product-journey" className="py-20 sm:py-28 bg-slate-100/60 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-white border border-slate-200 text-indigo-700 shadow-2xs">
            <Compass className="w-3.5 h-3.5 text-indigo-600" />
            <span>Structured Career Progression</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight">
            Your career journey, connected.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed">
            From your first day on campus to final placement, SkillOrbit provides an uninterrupted, telemetry-driven career navigation system.
          </p>
        </div>

        {/* Desktop Layout: Horizontal Journey Grid (6 Columns) */}
        <div className="hidden lg:grid lg:grid-cols-6 gap-3.5 mt-14">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div 
                key={step.num}
                className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between hover:border-indigo-300 hover:shadow-md transition-all duration-200 group relative"
              >
                {/* Step Connector Line */}
                {idx < steps.length - 1 && (
                  <div className="absolute -right-2 top-8 w-4 h-0.5 bg-slate-200 z-10 hidden" />
                )}

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                      {step.num}
                    </span>
                    <Icon className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                      {step.action}
                    </span>
                    <h3 className="text-xs font-bold text-slate-900 leading-snug">
                      {step.title}
                    </h3>
                  </div>

                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => onNavigateToView(step.targetView)}
                    className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 group-hover:gap-1.5 transition-all cursor-pointer"
                  >
                    <span>Inspect</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile & Tablet Layout: Vertical Timeline */}
        <div className="lg:hidden mt-10 space-y-4">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div 
                key={step.num}
                className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex items-start gap-4 shadow-2xs"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-mono font-bold text-sm shrink-0">
                  {step.num}
                </div>

                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                      {step.action}
                    </span>
                    <Icon className="w-4 h-4 text-slate-400" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {step.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {step.description}
                  </p>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => onNavigateToView(step.targetView)}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-1"
                    >
                      <span>Explore this stage</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
