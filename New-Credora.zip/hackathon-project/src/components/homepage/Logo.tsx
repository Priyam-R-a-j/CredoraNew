import React from 'react';

interface LogoProps {
  className?: string;
  showWordmark?: boolean;
  size?: 'sm' | 'md' | 'lg';
  monochrome?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  showWordmark = true,
  size = 'md',
  monochrome = false
}) => {
  const sizeClasses = {
    sm: { icon: 'w-7 h-7', text: 'text-base', sub: 'text-[9px]' },
    md: { icon: 'w-9 h-9', text: 'text-lg', sub: 'text-[10px]' },
    lg: { icon: 'w-11 h-11', text: 'text-xl', sub: 'text-xs' }
  }[size];

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Precision Orbital Glyph forming subtle S and O paths around a nucleus node */}
      <div 
        className={`${sizeClasses.icon} rounded-xl ${
          monochrome 
            ? 'bg-slate-900 text-white' 
            : 'bg-gradient-to-br from-indigo-600 to-indigo-700 text-white shadow-xs ring-1 ring-indigo-500/20'
        } flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-[1.02]`}
      >
        <svg 
          viewBox="0 0 28 28" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-5/6 h-5/6"
          aria-hidden="true"
        >
          {/* Central skill node */}
          <circle cx="14" cy="14" r="2.75" fill="currentColor" />
          
          {/* Outer elliptical orbit path 1 (skills -> opportunities) */}
          <ellipse 
            cx="14" 
            cy="14" 
            rx="10.5" 
            ry="4.5" 
            transform="rotate(-28 14 14)" 
            stroke="currentColor" 
            strokeWidth="1.75" 
            strokeLinecap="round"
            strokeDasharray="1.5 3.5"
            opacity="0.85"
          />
          
          {/* Inner continuous orbit path 2 (experience -> career) */}
          <ellipse 
            cx="14" 
            cy="14" 
            rx="9" 
            ry="4" 
            transform="rotate(38 14 14)" 
            stroke="currentColor" 
            strokeWidth="1.75" 
            strokeLinecap="round"
          />

          {/* Connected satellite node */}
          <circle cx="21" cy="9.5" r="1.5" fill="currentColor" />
          <circle cx="7" cy="18.5" r="1.25" fill="currentColor" opacity="0.7" />
        </svg>
      </div>

      {showWordmark && (
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5">
            <span className={`font-black tracking-tight ${sizeClasses.text} ${monochrome ? 'text-slate-900' : 'text-slate-950'} font-sans`}>
              Skill<span className={monochrome ? 'text-slate-700' : 'text-indigo-600'}>Orbit</span>
            </span>
          </div>
          <span className={`${sizeClasses.sub} text-slate-500 font-medium tracking-tight -mt-0.5 hidden sm:block`}>
            Career Intelligence Platform
          </span>
        </div>
      )}
    </div>
  );
};
