import React from 'react';
import { 
  GraduationCap, 
  Building2, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  Handshake, 
  Layers, 
  Compass,
  FileCode2
} from 'lucide-react';

interface UniversityIndustrySectionProps {
  onNavigateToCollaborations: () => void;
  onNavigateToUniversity: () => void;
  onNavigateToRecruiter: () => void;
}

export const UniversityIndustrySection: React.FC<UniversityIndustrySectionProps> = ({
  onNavigateToCollaborations,
  onNavigateToUniversity,
  onNavigateToRecruiter
}) => {
  return (
    <section id="university-industry" className="py-20 sm:py-28 bg-slate-50 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200 text-indigo-700">
            <Handshake className="w-3.5 h-3.5 text-indigo-600" />
            <span>Tri-Party Collaborative Ecosystem</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Connect education with industry.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            Universities gain real-time visibility into industry skill demands. Employers discover pre-vetted campus talent. Students graduate with accredited capstone experience.
          </p>
        </div>

        {/* Three-Sided Ecosystem Visualization Diagram */}
        <div className="mt-12 max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm text-center">
          <div className="inline-block px-3 py-1 bg-slate-100 rounded-full text-[11px] font-mono font-bold text-slate-700 mb-6">
            ECOSYSTEM NEXUS: STUDENTS ↔️ UNIVERSITIES ↔️ INDUSTRY
          </div>

          <div className="grid md:grid-cols-3 gap-6 text-left">
            
            {/* Pillar 1: Universities */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">For Universities</h3>
                  <p className="text-[11px] text-slate-500">Deans, Faculty &amp; Placement Cells</p>
                </div>

                <ul className="space-y-2 text-xs text-slate-600">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                    <span><strong>Identify skill gaps</strong> across engineering cohorts before placement season begins.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                    <span><strong>Monitor placement readiness</strong> in real time with batch-level analytics.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                    <span><strong>Understand industry demand</strong> to adapt curriculum and elective modules.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                    <span><strong>Manage projects</strong> and accredited capstones with corporate sponsors.</span>
                  </li>
                </ul>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onNavigateToUniversity}
                  className="text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1 cursor-pointer"
                >
                  <span>University Analytics Demo →</span>
                </button>
              </div>
            </div>

            {/* Pillar 2: Companies / Industry */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">For Companies</h3>
                  <p className="text-[11px] text-slate-500">Talent Leads &amp; Engineering Directors</p>
                </div>

                <ul className="space-y-2 text-xs text-slate-600">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                    <span><strong>Discover talent</strong> with auditable GitHub proofs and invigilated scores.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                    <span><strong>Publish opportunities</strong> with automated 5-pillar candidate screening.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                    <span><strong>Collaborate with universities</strong> to build proprietary campus hiring pipelines.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                    <span><strong>Propose capstone projects</strong> that solve authentic technical challenges.</span>
                  </li>
                </ul>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onNavigateToRecruiter}
                  className="text-xs font-bold text-indigo-700 hover:text-indigo-900 flex items-center gap-1 cursor-pointer"
                >
                  <span>Employer Hub Demo →</span>
                </button>
              </div>
            </div>

            {/* Pillar 3: Students */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">For Students</h3>
                  <p className="text-[11px] text-slate-500">Undergraduate &amp; Masters Candidates</p>
                </div>

                <ul className="space-y-2 text-xs text-slate-600">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Join projects</strong> mentored by Fortune 500 engineering leaders.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Build experience</strong> with verifiable evidence attached to your profile.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Apply for opportunities</strong> with transparent fit scores and reasons.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Develop relevant skills</strong> aligned directly with verified market demand.</span>
                  </li>
                </ul>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onNavigateToCollaborations}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                >
                  <span>Explore Capstone Projects →</span>
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
