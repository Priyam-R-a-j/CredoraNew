import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0); // First item open by default

  const faqs = [
    {
      q: 'How is SkillOrbit different from LinkedIn or job boards?',
      a: 'Conventional job boards rely on self-declared keywords and unverified bullet points. SkillOrbit is an evidence-first career intelligence platform where every declared skill connects to verifiable artifacts: proctored assessments, production GitHub repositories, university course grades, and authenticated capstones. Furthermore, our 5-pillar matching algorithm transparently explains why an opportunity matches you and what skill gaps remain.'
    },
    {
      q: 'How does SkillOrbit verify skills?',
      a: 'Skill verification occurs across multiple rigorous layers: (1) Proctored, invigilated assessments with percentile benchmarking; (2) Verified GitHub repository audits with commit inspection; (3) University SSO academic grade synchronization; and (4) Corporate mentor reviews during real-world capstone projects. Verified skills receive an immutable verification badge in your profile.'
    },
    {
      q: 'Can I use SkillOrbit if my university is not partnered?',
      a: 'Yes. Any student or job seeker can register individually, take proctored assessments, connect their GitHub and project repositories, map their degree trajectory, and apply directly for open industry placement drives. When your university activates institutional partnership, your existing profile connects seamlessly.'
    },
    {
      q: 'How does opportunity matching work?',
      a: 'Instead of shallow keyword searches, SkillOrbit uses a multi-vector 5-pillar matching engine: Skills (technical competency alignment), Education (degree, major, and graduation year eligibility), Experience (projects and internships), Location (remote, hybrid, or city preference), and Institutional Eligibility (GPA cutoffs and batch rules). You receive an auditable score and explicit gap guidance.'
    },
    {
      q: 'What is the difference between students, universities, and companies on SkillOrbit?',
      a: 'Students use SkillOrbit to map skills, identify gaps, complete verified projects, and get matched to jobs. Universities (Deans, Placement Cells, and Faculty) use it to audit cohort-wide skill gaps, monitor placement readiness, and manage campus recruitment drives. Companies use it to publish verified drives, screen candidates using auditable technical evidence, and sponsor university capstone challenges.'
    },
    {
      q: 'Are opportunities verified?',
      a: 'Yes. Every campus drive, internship, and full-time role published on SkillOrbit goes through recruiter identity verification, institutional domain checks, and salary/stipend clarity validation before appearing on the candidate feed.'
    },
    {
      q: 'How is my career readiness score calculated?',
      a: 'Your Placement Readiness Index (0–100%) is calculated across four core dimensions: verified technical competence in your target role, completed project evidence with live repositories, academic standing against benchmark requirements, and institutional mock interview performance.'
    },
    {
      q: 'Does SkillOrbit help with internships or full-time jobs?',
      a: 'SkillOrbit supports both. Opportunities are categorized into Summer Internships, 6-Month Semester Co-ops, Research Fellowships, and Full-Time Graduate Roles across engineering, quantitative analytics, product design, and robotics.'
    },
    {
      q: 'Is SkillOrbit free for students?',
      a: 'Yes. Core platform features—including skill mapping, career trajectory exploration, basic assessments, project tracking, and opportunity applications—are completely free for students. Institutional analytics and enterprise recruitment suites are funded by participating universities and employers.'
    },
    {
      q: 'How do universities use SkillOrbit?',
      a: 'University placement directors and faculty use the University Analytics Dashboard to view cohort-wide placement preparedness, identify curriculum gaps against real-time industry demand, orchestrate campus recruitment drives, and invite corporate sponsors to co-develop capstone projects.'
    }
  ];

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-20 sm:py-28 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 border border-slate-200 text-slate-700">
            <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
            <span>Frequently Asked Questions</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Everything you need to know.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl mx-auto font-normal">
            Common questions regarding skill verification, opportunity matching, university integrations, and candidate privacy.
          </p>
        </div>

        {/* Clean Accordion */}
        <div className="divide-y divide-slate-200 border-y border-slate-200">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div key={idx} className="py-4 sm:py-5">
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full flex items-center justify-between text-left gap-4 cursor-pointer focus:outline-hidden group"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {faq.q}
                  </span>
                  <div className={`w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180 bg-indigo-50 text-indigo-600' : 'text-slate-500'}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="pt-3 pr-8 text-xs sm:text-sm text-slate-600 leading-relaxed animate-in fade-in duration-150">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
