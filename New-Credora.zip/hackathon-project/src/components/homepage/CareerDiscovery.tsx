import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Bot, 
  Cpu, 
  Car, 
  Factory, 
  Wrench, 
  Info,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface CareerDiscoveryProps {
  onExploreCareers: () => void;
}

export const CareerDiscovery: React.FC<CareerDiscoveryProps> = ({ onExploreCareers }) => {
  const [selectedPath, setSelectedPath] = useState<string>('robotics');

  const paths = [
    {
      id: 'robotics',
      title: 'Robotics Engineer',
      fitScore: 82,
      skillsMatch: 88,
      educationMatch: 100,
      interestMatch: 76,
      experienceMatch: 65,
      icon: Bot,
      rationale: 'High alignment with ROS2, kinematic control math, and C++ coursework. Bridging ROS simulation project recommended.',
      prerequisitesMet: ['C++ Systems Programming', 'Classical Mechanics & Kinematics', 'Microcontroller Interfacing'],
      skillGaps: ['ROS2 Nav2 Stack', 'Gazebo Physics Simulators']
    },
    {
      id: 'automation',
      title: 'Automation & PLC Engineer',
      fitScore: 89,
      skillsMatch: 92,
      educationMatch: 100,
      interestMatch: 84,
      experienceMatch: 78,
      icon: Factory,
      rationale: 'Direct alignment with industrial instrumentation and SCADA control labs. Strongest immediate campus drive alignment.',
      prerequisitesMet: ['PLC Ladder Logic', 'Sensor Telemetry', 'Control Systems'],
      skillGaps: ['Industrial Ethernet Protocols']
    },
    {
      id: 'mechatronics',
      title: 'Mechatronics Engineer',
      fitScore: 85,
      skillsMatch: 86,
      educationMatch: 100,
      interestMatch: 82,
      experienceMatch: 72,
      icon: Cpu,
      rationale: 'Balanced blend of electronic actuator control and CAD mechanical modeling.',
      prerequisitesMet: ['SolidWorks / Fusion 360', 'Embedded C', 'Actuator Design'],
      skillGaps: ['CAN Bus Diagnostics']
    },
    {
      id: 'automotive',
      title: 'Automotive Systems Engineer',
      fitScore: 78,
      skillsMatch: 80,
      educationMatch: 100,
      interestMatch: 70,
      experienceMatch: 60,
      icon: Car,
      rationale: 'Strong mechanical foundations; EV powertrain simulation is an emerging requirement.',
      prerequisitesMet: ['Thermodynamics', 'Vehicle Dynamics', 'MATLAB Simulink'],
      skillGaps: ['Battery Management System (BMS)']
    }
  ];

  const current = paths.find(p => p.id === selectedPath) || paths[0];

  return (
    <section id="career-discovery" className="py-20 sm:py-28 bg-slate-50 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200 text-indigo-700">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Multi-Vector Trajectory Mapping</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Your degree is a starting point, not a destination.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            Students discover expansive career trajectories calibrated from six real-world vectors: their foundational skills, technical interests, degree curriculum, completed projects, practical experience, and long-term career ambitions.
          </p>
        </div>

        {/* Interactive Example Demonstration Container */}
        <div className="mt-14 max-w-5xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          
          {/* Top Degree Context Bar */}
          <div className="bg-slate-900 text-white p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-sm">
                <Wrench className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">Starting Point Degree</span>
                  <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded border border-slate-700">
                    ILLUSTRATIVE PROFILE
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                  B.Tech in Mechanical Engineering
                </h3>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-[11px] text-slate-400 block">Candidate Vectors Analyzed</span>
              <span className="text-xs font-semibold text-slate-200">
                Skills · Interests · Projects · Coursework · Ambitions
              </span>
            </div>
          </div>

          {/* Body: Left Paths Selector & Right Detailed Fit Analysis */}
          <div className="grid md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-slate-200">
            
            {/* Paths Selector */}
            <div className="md:col-span-5 p-4 sm:p-6 space-y-2.5 bg-slate-50/50">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                Potential Career Trajectories
              </span>

              {paths.map((p) => {
                const Icon = p.icon;
                const isSelected = p.id === selectedPath;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPath(p.id)}
                    className={`w-full p-3.5 rounded-2xl text-left transition-all flex items-center justify-between border cursor-pointer ${
                      isSelected
                        ? 'bg-white border-indigo-600 shadow-sm ring-1 ring-indigo-500/20'
                        : 'bg-white/80 border-slate-200 hover:border-slate-300 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">{p.title}</div>
                        <div className="text-[10px] text-slate-500">Degree Fit Score: {p.fitScore}%</div>
                      </div>
                    </div>
                    <span className={`text-xs font-mono font-bold ${isSelected ? 'text-indigo-600' : 'text-slate-500'}`}>
                      {p.fitScore}%
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Detailed Career-Fit Reasoning Column */}
            <div className="md:col-span-7 p-6 sm:p-7 space-y-6">
              
              {/* Fit Header */}
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                    Transparent Fit Breakdown
                  </span>
                  <h4 className="text-xl font-bold text-slate-950 mt-0.5">
                    {current.title}
                  </h4>
                </div>
                <div className="text-right">
                  <span className="text-2xl sm:text-3xl font-black text-indigo-600 font-mono">
                    {current.fitScore}%
                  </span>
                  <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Calculated Fit
                  </span>
                </div>
              </div>

              {/* Required 4-Metric Transparent Fit Gauges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
                <div className="space-y-1">
                  <span className="text-[10px] font-medium text-slate-500 block">Skills Match</span>
                  <div className="text-base font-black font-mono text-slate-900">{current.skillsMatch}%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${current.skillsMatch}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-medium text-slate-500 block">Education Match</span>
                  <div className="text-base font-black font-mono text-slate-900">{current.educationMatch}%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${current.educationMatch}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-medium text-slate-500 block">Interest Match</span>
                  <div className="text-base font-black font-mono text-slate-900">{current.interestMatch}%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${current.interestMatch}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-medium text-slate-500 block">Experience Match</span>
                  <div className="text-base font-black font-mono text-slate-900">{current.experienceMatch}%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-amber-600 h-full rounded-full" style={{ width: `${current.experienceMatch}%` }} />
                  </div>
                </div>
              </div>

              {/* Rationale Text */}
              <div className="p-3.5 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-indigo-950 font-medium leading-relaxed">
                <strong>Matching Rationale:</strong> {current.rationale}
              </div>

              {/* Met vs Gap Checklist */}
              <div className="grid sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Prerequisites Satisfied
                  </span>
                  <ul className="space-y-1 text-slate-600">
                    {current.prerequisitesMet.map((item, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    Target Skill Gaps to Bridge
                  </span>
                  <ul className="space-y-1 text-slate-600">
                    {current.skillGaps.map((item, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>
          </div>

          {/* Bottom Callout with Explicit Illustrative Label */}
          <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-slate-400 shrink-0" />
              <span>
                <strong>Illustrative Profile:</strong> Example calculated for demo purposes. Fit algorithms compute dynamically per individual verified transcript.
              </span>
            </div>

            <button
              type="button"
              onClick={onExploreCareers}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer shrink-0"
            >
              <span>Explore Career Compass →</span>
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
