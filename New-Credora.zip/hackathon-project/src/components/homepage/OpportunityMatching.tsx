import React from 'react';
import { 
  Briefcase, 
  Building2, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  ShieldCheck,
  Check,
  X
} from 'lucide-react';

interface OpportunityMatchingProps {
  onExploreOpportunities: () => void;
}

export const OpportunityMatching: React.FC<OpportunityMatchingProps> = ({ onExploreOpportunities }) => {
  return (
    <section id="opportunity-matching" className="py-20 sm:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800">
            <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
            <span>Autonomous 5-Pillar Matching Algorithm</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Stop searching. Start matching.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            Keyword queries produce noise. SkillOrbit evaluates every campus drive against your verified transcript across five auditable pillars—eliminating guesswork for both students and university placement cells.
          </p>
        </div>

        {/* Realistic Product Opportunity Card Preview */}
        <div className="mt-14 max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          
          {/* Opportunity Header */}
          <div className="p-6 sm:p-7 border-b border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50/50">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white font-black text-base flex items-center justify-center shrink-0 shadow-sm">
                GO
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                    Google (Alphabet Inc.)
                  </span>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 border border-emerald-200 px-2 py-0.2 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" /> Verified Campus Drive
                  </span>
                </div>
                <h3 className="text-xl font-black text-slate-950 mt-0.5">
                  Software Engineering Intern
                </h3>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" /> Bengaluru / Hyderabad
                  </span>
                  <span>•</span>
                  <span>Hybrid (3 Days Onsite)</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" /> Deadline: March 31, 2026
                  </span>
                </div>
              </div>
            </div>

            {/* Overall Match Badge */}
            <div className="bg-white border border-slate-200 p-3 rounded-2xl shadow-2xs text-center min-w-[130px] shrink-0">
              <div className="text-3xl font-black text-indigo-600 font-mono">
                87%
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mt-0.5">
                Composite Match
              </div>
            </div>
          </div>

          {/* 5-Pillar Score Breakdown Grid */}
          <div className="p-6 sm:p-7 space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-900">
                  Five-Pillar Breakdown Rationale
                </span>
                <span className="text-[11px] text-slate-500">
                  Audit Weighting: Skills (40%), Education (20%), Exp (20%), Loc (10%), Eligibility (10%)
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-500 block">Skills</span>
                  <div className="text-base font-black font-mono text-indigo-600">90%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full w-[90%]" />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-500 block">Education</span>
                  <div className="text-base font-black font-mono text-emerald-600">100%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full rounded-full w-[100%]" />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-500 block">Experience</span>
                  <div className="text-base font-black font-mono text-amber-600">70%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-amber-600 h-full rounded-full w-[70%]" />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-500 block">Location</span>
                  <div className="text-base font-black font-mono text-indigo-600">80%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full w-[80%]" />
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-slate-500 block">Eligibility</span>
                  <div className="text-base font-black font-mono text-emerald-600">100%</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-600 h-full rounded-full w-[100%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Why This Matches You & What You're Missing */}
            <div className="grid sm:grid-cols-2 gap-5 text-xs">
              {/* Why this matches you */}
              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 space-y-2.5">
                <span className="font-bold text-emerald-950 flex items-center gap-1.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Why this matches you
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  <li className="flex items-start gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>Possesses verified credentials in <strong>Python</strong>, <strong>Data Structures</strong>, and <strong>Algorithms</strong>.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>Graduating B.Tech CSE Class of 2026 meets the exact batch criteria.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                    <span>CGPA (8.4/10.0) comfortably exceeds minimum campus cutoff (7.5).</span>
                  </li>
                </ul>
              </div>

              {/* What you're missing */}
              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100 space-y-2.5">
                <span className="font-bold text-amber-950 flex items-center gap-1.5 text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  What you&apos;re missing (Target Gaps)
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  <li className="flex items-start gap-1.5">
                    <X className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                    <span>Preferred qualification: <strong>Go (Golang)</strong> microservices project evidence.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <X className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                    <span>System Design fundamentals assessment score pending verification.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-slate-500">
                Verified candidate transcript matches 6 out of 7 role requirements.
              </span>
              <button
                type="button"
                onClick={onExploreOpportunities}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Explore Full Opportunities Feed</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
