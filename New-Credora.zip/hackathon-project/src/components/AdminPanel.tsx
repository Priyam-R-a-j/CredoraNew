import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  Server, 
  Lock, 
  Users, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw,
  Clock
} from 'lucide-react';
import { INSTITUTIONS_DATA } from '../data/institutions';
import { COMPANIES_DATA } from '../data/companies';
import { OPPORTUNITIES_DATA } from '../data/opportunities';

export const AdminPanel: React.FC = () => {
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  const fetchLogs = async () => {
    setLoadingLogs(true);
    try {
      const res = await fetch('/api/audit-logs');
      const data = await res.json();
      setAuditLogs(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-600 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">
              Platform Governance
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Global Compliance & Infrastructure Control
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            SkillOrbit Admin Operations & Security
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Real-time cluster health, security audit trails, IP masking compliance, and institutional registry administration.
          </p>
        </div>

        <button
          onClick={fetchLogs}
          disabled={loadingLogs}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loadingLogs ? 'animate-spin' : ''}`} />
          <span>Refresh Audit Feed</span>
        </button>
      </div>

      {/* Cluster Health Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>API Health</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div className="text-xl font-black text-slate-900 mt-2">Operational</div>
          <div className="text-[11px] text-slate-500 mt-1">
            P99 Latency: 42ms · Port 3000
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Institutions Registry</span>
            <Database className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-black text-slate-900 mt-2">{INSTITUTIONS_DATA.length} Universities</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            100% Accredited & Verified
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Enterprise Partners</span>
            <Users className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-xl font-black text-slate-900 mt-2">{COMPANIES_DATA.length} Companies</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Tech, Finance, Consulting
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase tracking-wider">
            <span>Security Perimeter</span>
            <Lock className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-black text-emerald-700 mt-2">Enforced</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Zero Raw Storage · Turnstile Active
          </div>
        </div>
      </div>

      {/* Security Audit Trail */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-indigo-600" />
              <span>Immutable Security Audit Log</span>
            </h3>
            <p className="text-xs text-slate-500">
              Captures all system access, institutional verifications, and permission updates with IP masking
            </p>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            Retention: 365 Days
          </span>
        </div>

        <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
          {auditLogs.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">Loading audit log entries...</p>
          ) : (
            auditLogs.map((log) => (
              <div key={log.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900">{log.action}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-700 font-semibold px-1.5 py-0.5 rounded">
                      Role: {log.role}
                    </span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                      {log.status}
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px] mt-0.5">{log.details}</p>
                </div>

                <div className="text-right shrink-0 text-[11px] text-slate-400 font-mono">
                  <div>User: <span className="text-slate-700 font-medium">{log.userEmail}</span></div>
                  <div>IP: {log.ipMasked} · {new Date(log.timestamp).toLocaleTimeString()}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
