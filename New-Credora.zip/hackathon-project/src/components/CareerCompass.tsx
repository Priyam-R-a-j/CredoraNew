import React, { useState } from 'react';
import { 
  Sparkles, 
  Target, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  DollarSign, 
  Layers, 
  Building2,
  Check
} from 'lucide-react';
import { CareerPath, UserSkill } from '../types';
import { CAREER_PATHS_DATA } from '../data/careers';
import { calculateCareerFit } from '../utils/matching';

interface CareerCompassProps {
  skills: UserSkill[];
  currentTargetCareerId?: string;
  onSetTargetCareer: (career: CareerPath) => void;
  onNavigateToOpportunities: () => void;
}

export const CareerCompass: React.FC<CareerCompassProps> = ({
  skills,
  currentTargetCareerId,
  onSetTargetCareer,
  onNavigateToOpportunities
}) => {
  const [selectedCareer, setSelectedCareer] = useState<CareerPath>(
    CAREER_PATHS_DATA.find(c => c.id === currentTargetCareerId) || CAREER_PATHS_DATA[0]
  );

  const fitAnalysis = calculateCareerFit(selectedCareer, skills);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Career Intelligence
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Transparent Fit & Gap Analysis
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Career Compass & Trajectory
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Compare target career trajectories across Technology, Finance, and Consulting. Inspect exact core skill requirements, market compensation, and transparent fitness breakdowns.
          </p>
        </div>

        {selectedCareer.id === currentTargetCareerId ? (
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl">
            <Check className="w-4 h-4" />
            <span>Active Target Pathway</span>
          </div>
        ) : (
          <button
            onClick={() => onSetTargetCareer(selectedCareer)}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs"
          >
            <Target className="w-4 h-4" />
            <span>Set as My Target Role</span>
          </button>
        )}
      </div>

      {/* Main Grid: Career Selector (Left) + Detailed Inspector (Right) */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left: Career List */}
        <div className="space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block px-1">
            Available Career Pathways
          </span>
          {CAREER_PATHS_DATA.map((career) => {
            const fit = calculateCareerFit(career, skills);
            const isSelected = selectedCareer.id === career.id;
            const isTarget = currentTargetCareerId === career.id;

            return (
              <div
                key={career.id}
                onClick={() => setSelectedCareer(career)}
                className={`p-4 rounded-xl border transition cursor-pointer text-left ${
                  isSelected 
                    ? 'border-indigo-600 bg-indigo-50/50 shadow-xs ring-1 ring-indigo-500/20' 
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    {career.industry}
                  </span>
                  <div className="flex items-center gap-1">
                    {isTarget && (
                      <span className="text-[10px] font-bold bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded">
                        Target
                      </span>
                    )}
                    <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      {fit.fitScore}% Fit
                    </span>
                  </div>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mt-1">{career.title}</h3>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{career.summary}</p>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Demand: <strong className="text-slate-700">{career.growthOutlook}</strong></span>
                  <span className="text-indigo-600 font-semibold flex items-center gap-0.5">
                    Inspect <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Detailed Deep Dive for Selected Career */}
        <div className="lg:col-span-2 space-y-6">
          {/* Fit Overview Banner */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {selectedCareer.industry} Sector
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-1">
                  {selectedCareer.title}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">{selectedCareer.summary}</p>
              </div>

              <div className="text-left sm:text-right shrink-0 bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-xl">
                <div className="text-3xl font-extrabold text-emerald-700">{fitAnalysis.fitScore}%</div>
                <div className="text-[11px] font-semibold text-slate-500">Career Match Score</div>
              </div>
            </div>

            {/* Compensation & Growth metrics */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span>Market Entry Compensation</span>
                </div>
                <div className="text-sm font-extrabold text-slate-900 mt-1">
                  {selectedCareer.averageStartingSalary}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
                  <TrendingUp className="w-4 h-4 text-indigo-600" />
                  <span>5-Year Growth Outlook</span>
                </div>
                <div className="text-sm font-extrabold text-slate-900 mt-1">
                  {selectedCareer.growthOutlook} ({selectedCareer.industryDemandScore}/100 Industry Index)
                </div>
              </div>
            </div>

            {/* Transparent Fit Analysis: Why it matches vs What to improve */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Why This Career Matches You</span>
                </div>
                <ul className="space-y-1.5 text-xs text-emerald-800">
                  {fitAnalysis.whyItMatches.map((r, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                  <li className="flex items-start gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                    <span>Matched Core Skills: {fitAnalysis.matchingCoreSkills.join(', ') || 'Foundational competencies'}</span>
                  </li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200/80 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Identified Gaps to Bridge</span>
                </div>
                {fitAnalysis.whatToImprove.length === 0 ? (
                  <p className="text-xs text-emerald-700 font-semibold">You satisfy all core foundational competencies!</p>
                ) : (
                  <ul className="space-y-1.5 text-xs text-amber-800">
                    {fitAnalysis.whatToImprove.map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Core Required Skills Breakdown */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Core Industry Competencies Required
              </h3>
              <div className="flex flex-wrap gap-2">
                {selectedCareer.requiredCoreSkills.map((skill, idx) => {
                  const isOwned = fitAnalysis.matchingCoreSkills.includes(skill);
                  return (
                    <span
                      key={idx}
                      className={`text-xs font-semibold px-2.5 py-1 rounded-lg border flex items-center gap-1.5 ${
                        isOwned 
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      {isOwned ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <span className="w-2 h-2 rounded-full bg-amber-500" />}
                      <span>{skill}</span>
                    </span>
                  );
                })}
              </div>
            </div>

            {/* Trajectory Phases */}
            <div className="pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">
                Recommended Milestone Roadmap
              </h3>
              <div className="space-y-4">
                {selectedCareer.typicalTrajectory.map((step) => (
                  <div key={step.step} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row gap-4">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 text-white font-bold text-xs flex items-center justify-center shrink-0">
                      {step.step}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{step.title}</span>
                        <span className="text-[10px] text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200 font-medium">
                          {step.phase}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">{step.description}</p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {step.keyDeliverables.map((d, dIdx) => (
                          <span key={dIdx} className="text-[10px] font-semibold bg-white text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                            ✓ {d}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={onNavigateToOpportunities}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5"
              >
                <span>Find Matching Opportunities</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
