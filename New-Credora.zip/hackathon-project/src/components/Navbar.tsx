import React, { useState, useEffect, useRef } from 'react';
import { 
  Compass, 
  Layers, 
  Briefcase, 
  Building2, 
  Sparkles, 
  Search, 
  Bell, 
  ShieldCheck, 
  User as UserIcon, 
  ChevronDown, 
  HelpCircle, 
  TrendingUp, 
  Handshake, 
  Menu, 
  X, 
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  Home,
  Sun,
  Moon
} from 'lucide-react';
import { UserRole } from '../types';
import { Logo } from './homepage/Logo';
import { HOME_VIEW } from '../constants/routes';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  openSearch: () => void;
  openAuth: (mode?: 'login' | 'register') => void;
  openVerification: () => void;
  theme?: 'light' | 'dark';
  toggleTheme?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  currentRole,
  setCurrentRole,
  openSearch,
  openAuth,
  openVerification,
  theme = 'light',
  toggleTheme
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [skillsDropdownOpen, setSkillsDropdownOpen] = useState(false);
  const [mobileSkillsOpen, setMobileSkillsOpen] = useState(true);
  const skillsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (skillsRef.current && !skillsRef.current.contains(event.target as Node)) {
        setSkillsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const rolesConfig: { role: UserRole; title: string; subtitle: string; badge: string }[] = [
    { 
      role: 'student', 
      title: 'Student Persona', 
      subtitle: 'Aarav Sharma · Manipal University Jaipur',
      badge: 'BTech CSE (78% Ready)'
    },
    { 
      role: 'university_admin', 
      title: 'University Admin', 
      subtitle: 'Dr. V. K. Saxena · Dean of Academics (MUJ)',
      badge: 'Institutional View'
    },
    { 
      role: 'recruiter', 
      title: 'Corporate Recruiter', 
      subtitle: 'Sonia Kapoor · Tech Talent Lead (NVIDIA)',
      badge: 'Employer View'
    },
    { 
      role: 'platform_admin', 
      title: 'Platform Admin', 
      subtitle: 'SkillOrbit Compliance & Infrastructure',
      badge: 'Global Admin'
    }
  ];

  const currentRoleInfo = rolesConfig.find(r => r.role === currentRole) || rolesConfig[0];

  const isSkillsActive = currentView === 'verified_skills' || currentView === 'skillmap';

  const tabCommonClass = "w-[116px] h-9 px-2 py-1.5 flex items-center justify-center gap-1 rounded-xl text-[11.5px] font-semibold border transition text-center shrink-0 cursor-pointer select-none";
  const activeTabClass = "border-indigo-200/80 bg-indigo-50/80 text-indigo-700 font-bold dark:border-indigo-800 dark:bg-indigo-950/50 dark:text-indigo-300";
  const inactiveTabClass = "border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/70";

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top enterprise banner for persona indicator */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium text-slate-200">SkillOrbit Enterprise Engine</span>
          <span className="text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">Connected: Manipal University Jaipur &amp; Verified Industry Network</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded text-xs transition border border-slate-700"
            >
              <span className="text-slate-400">Role:</span>
              <span className="font-semibold text-white">{currentRoleInfo.title}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {roleDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-72 bg-white rounded-lg shadow-xl border border-slate-200 py-1 z-50 text-slate-800">
                <div className="px-3 py-2 border-b border-slate-100 bg-slate-50">
                  <p className="text-xs font-semibold text-slate-700">Switch Demonstration Role</p>
                  <p className="text-[11px] text-slate-500">Test authentic workflows across user types</p>
                </div>
                {rolesConfig.map((item) => (
                  <button
                    key={item.role}
                    onClick={() => {
                      setCurrentRole(item.role);
                      setRoleDropdownOpen(false);
                      if (item.role === 'university_admin') setCurrentView('university_dashboard');
                      else if (item.role === 'recruiter') setCurrentView('recruiter_dashboard');
                      else if (item.role === 'platform_admin') setCurrentView('admin_panel');
                      else setCurrentView('dashboard');
                    }}
                    className={`w-full text-left px-3 py-2.5 hover:bg-slate-50 flex items-start gap-2.5 transition border-l-2 ${
                      currentRole === item.role ? 'border-indigo-600 bg-indigo-50/50' : 'border-transparent'
                    }`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">{item.title}</span>
                        <span className="text-[10px] font-medium bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {item.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{item.subtitle}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Wordmark */}
          <div className="flex items-center gap-4 xl:gap-6">
            <button 
              onClick={() => setCurrentView(HOME_VIEW)}
              className="flex items-center gap-2.5 group text-left cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-lg p-0.5 shrink-0"
              title="SkillOrbit — Return to Homepage"
            >
              <Logo size="md" />
            </button>

            {/* Desktop Navigation Links — All Equal in Size */}
            <nav className="hidden lg:flex items-center gap-1 overflow-x-auto py-1">
              {/* 1. Home */}
              <button
                type="button"
                onClick={() => setCurrentView(HOME_VIEW)}
                className={`${tabCommonClass} ${currentView === HOME_VIEW ? activeTabClass : inactiveTabClass}`}
                title="Home"
              >
                <Home className={`w-3.5 h-3.5 shrink-0 ${currentView === HOME_VIEW ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Home</span>
              </button>

              {/* 2. Command Center */}
              <button
                type="button"
                onClick={() => setCurrentView('dashboard')}
                className={`${tabCommonClass} ${currentView === 'dashboard' ? activeTabClass : inactiveTabClass}`}
                title="Command Center"
              >
                <Compass className={`w-3.5 h-3.5 shrink-0 ${currentView === 'dashboard' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Command Center</span>
              </button>

              {/* 3. Skills Dropdown — Exact Equal Tab Size */}
              <div className="relative" ref={skillsRef}>
                <button
                  type="button"
                  onClick={() => setSkillsDropdownOpen(!skillsDropdownOpen)}
                  className={`${tabCommonClass} ${isSkillsActive ? activeTabClass : inactiveTabClass}`}
                  title="Skills: Verified Skills & Skill Map"
                >
                  <Layers className={`w-3.5 h-3.5 shrink-0 ${isSkillsActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <span className="truncate">Skills</span>
                  <ChevronDown className={`w-3 h-3 shrink-0 text-slate-400 transition-transform ${skillsDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {skillsDropdownOpen && (
                  <div 
                    className="absolute top-full left-1/2 -translate-x-1/2 mt-1.5 w-48 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setCurrentView('verified_skills');
                        setSkillsDropdownOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs transition cursor-pointer ${
                        currentView === 'verified_skills'
                          ? 'bg-emerald-50 text-emerald-800 font-bold dark:bg-emerald-950/40 dark:text-emerald-300'
                          : 'text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800'
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold">Verified Skills</div>
                      </div>
                      {currentView === 'verified_skills' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setCurrentView('skillmap');
                        setSkillsDropdownOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs transition cursor-pointer ${
                        currentView === 'skillmap'
                          ? 'bg-indigo-50 text-indigo-700 font-bold dark:bg-indigo-950/40 dark:text-indigo-300'
                          : 'text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Layers className="w-4 h-4 text-indigo-600 shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold">Skill Map</div>
                      </div>
                      {currentView === 'skillmap' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* 4. Career Compass */}
              <button
                type="button"
                onClick={() => setCurrentView('careercompass')}
                className={`${tabCommonClass} ${currentView === 'careercompass' ? activeTabClass : inactiveTabClass}`}
                title="Career Compass"
              >
                <Sparkles className={`w-3.5 h-3.5 shrink-0 ${currentView === 'careercompass' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Career Compass</span>
              </button>

              {/* 5. Opportunities */}
              <button
                type="button"
                onClick={() => setCurrentView('opportunities')}
                className={`${tabCommonClass} ${currentView === 'opportunities' ? activeTabClass : inactiveTabClass}`}
                title="Opportunities"
              >
                <Briefcase className={`w-3.5 h-3.5 shrink-0 ${currentView === 'opportunities' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Opportunities</span>
              </button>

              {/* 6. Companies */}
              <button
                type="button"
                onClick={() => setCurrentView('companies')}
                className={`${tabCommonClass} ${currentView === 'companies' ? activeTabClass : inactiveTabClass}`}
                title="Companies"
              >
                <Building2 className={`w-3.5 h-3.5 shrink-0 ${currentView === 'companies' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Companies</span>
              </button>

              {/* 7. Collaborations */}
              <button
                type="button"
                onClick={() => setCurrentView('collaborations')}
                className={`${tabCommonClass} ${currentView === 'collaborations' ? activeTabClass : inactiveTabClass}`}
                title="Collaborations"
              >
                <Handshake className={`w-3.5 h-3.5 shrink-0 ${currentView === 'collaborations' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Collaborations</span>
              </button>

              {/* 8. Industry Pulse */}
              <button
                type="button"
                onClick={() => setCurrentView('industrypulse')}
                className={`${tabCommonClass} ${currentView === 'industrypulse' ? activeTabClass : inactiveTabClass}`}
                title="Industry Pulse"
              >
                <TrendingUp className={`w-3.5 h-3.5 shrink-0 ${currentView === 'industrypulse' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span className="truncate">Industry Pulse</span>
              </button>
            </nav>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Global Search Trigger */}
            <button
              onClick={openSearch}
              className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200/80 text-slate-500 hover:text-slate-800 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 transition cursor-pointer"
              title="Search across companies, opportunities, skills, institutions"
            >
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Search orbit...</span>
              <kbd className="hidden sm:inline-block bg-white text-slate-600 text-[10px] px-1.5 py-0.5 rounded border border-slate-200 font-mono">
                ⌘K
              </kbd>
            </button>

            {/* Sun/Moon Theme Toggle */}
            {toggleTheme && (
              <button 
                type="button"
                onClick={toggleTheme}
                className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
                title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                aria-label={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-400" />
                ) : (
                  <Moon className="w-4 h-4 text-slate-600" />
                )}
              </button>
            )}

            {/* Notifications Trigger */}
            <div className="relative">
              <button 
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg relative transition cursor-pointer"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-600 rounded-full" />
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-50">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-800">Notifications &amp; Alerts</span>
                    <span className="text-[10px] text-indigo-600 font-semibold cursor-pointer">Mark all read</span>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                    <div className="py-2.5 text-xs">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-slate-800">Verified Match: Google SWE Intern</p>
                          <p className="text-slate-500 text-[11px] mt-0.5">Your profile matches 88% of requirements for Summer 2026.</p>
                          <span className="text-[10px] text-slate-400">2 hours ago</span>
                        </div>
                      </div>
                    </div>
                    <div className="py-2.5 text-xs">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-slate-800">Application Deadline in 48h</p>
                          <p className="text-slate-500 text-[11px] mt-0.5">JPMorgan Quantitative Research deadline approaching.</p>
                          <span className="text-[10px] text-slate-400">5 hours ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Help Center shortcut */}
            <button
              onClick={() => setCurrentView('help')}
              className={`p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition cursor-pointer ${
                currentView === 'help' ? 'text-indigo-600 bg-indigo-50' : ''
              }`}
              title="Help Center"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Profile / Verification Badge */}
            <button
              onClick={openVerification}
              className="hidden sm:flex items-center gap-2 pl-2 pr-3 py-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition text-left cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                A
              </div>
              <div className="text-[11px] leading-tight">
                <div className="font-semibold text-slate-800 flex items-center gap-1">
                  Aarav S.
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                </div>
                <div className="text-slate-600">MUJ · Verified</div>
              </div>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1">
          <button
            type="button"
            onClick={() => { setCurrentView(HOME_VIEW); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === HOME_VIEW ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentView('dashboard'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'dashboard' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Command Center</span>
          </button>

          {/* Skills Accordion */}
          <div className="rounded-xl border border-slate-200/80 overflow-hidden">
            <button
              type="button"
              onClick={() => setMobileSkillsOpen(!mobileSkillsOpen)}
              className={`w-full flex items-center justify-between px-3 py-2.5 text-xs font-semibold ${
                isSkillsActive ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                <span>Skills</span>
              </div>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${mobileSkillsOpen ? 'rotate-180' : ''}`} />
            </button>

            {mobileSkillsOpen && (
              <div className="bg-slate-50/70 border-t border-slate-200/80 px-2 py-1.5 space-y-1">
                <button
                  type="button"
                  onClick={() => { setCurrentView('verified_skills'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition ${
                    currentView === 'verified_skills' ? 'bg-emerald-100 text-emerald-900 font-bold' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Verified Skills</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setCurrentView('skillmap'); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition ${
                    currentView === 'skillmap' ? 'bg-indigo-100 text-indigo-900 font-bold' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Skill Map</span>
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => { setCurrentView('careercompass'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'careercompass' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Career Compass</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentView('opportunities'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'opportunities' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>Opportunities</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentView('companies'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'companies' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Companies</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentView('collaborations'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'collaborations' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Handshake className="w-4 h-4" />
            <span>Collaborations</span>
          </button>

          <button
            type="button"
            onClick={() => { setCurrentView('industrypulse'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
              currentView === 'industrypulse' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Industry Pulse</span>
          </button>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <button 
              onClick={() => { openVerification(); setMobileMenuOpen(false); }}
              className="text-xs font-semibold text-emerald-700 flex items-center gap-1 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              Identity Verification (Verified)
            </button>
            <button 
              onClick={() => { setCurrentView('help'); setMobileMenuOpen(false); }}
              className="text-xs font-semibold text-slate-600 cursor-pointer"
            >
              Help Center
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

