import React, { useState, useMemo } from 'react';
import { 
  Search, 
  X, 
  Building2, 
  Briefcase, 
  Sparkles, 
  Layers, 
  GraduationCap, 
  ArrowRight,
  ArrowUpRight,
  Filter
} from 'lucide-react';
import { Company, Opportunity, CareerPath, Institution } from '../types';
import { CanonicalSkill } from '../data/skills';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  companies: Company[];
  opportunities: Opportunity[];
  skills: CanonicalSkill[];
  careers: CareerPath[];
  institutions: Institution[];
  onSelectEntity: (type: 'company' | 'opportunity' | 'career' | 'skill' | 'institution', entity: any) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  companies,
  opportunities,
  skills,
  careers,
  institutions,
  onSelectEntity,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'companies' | 'opportunities' | 'skills' | 'careers' | 'institutions'>('all');

  // Unified Search Logic across all 5 dimensions
  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) {
      // Default curated popular recommendations
      return {
        companies: companies.slice(0, 3),
        opportunities: opportunities.slice(0, 3),
        skills: skills.slice(0, 3),
        careers: careers.slice(0, 2),
        institutions: institutions.slice(0, 2)
      };
    }

    // Specialized keyword handlers
    const isInternshipQuery = q.includes('intern') || q.includes('job') || q.includes('opportunity');
    const isTechQuery = q.includes('tech') || q.includes('software');
    const isFinanceQuery = q.includes('finance') || q.includes('quant') || q.includes('bank');
    const isConsultingQuery = q.includes('consult');

    // 1. Companies Matching
    const matchedCompanies = companies.filter(c => {
      if (c.name.toLowerCase().includes(q)) return true;
      if (c.industry.toLowerCase().includes(q)) return true;
      if (c.tags.some(t => t.toLowerCase().includes(q))) return true;
      if (isTechQuery && c.industry === 'Technology') return true;
      if (isFinanceQuery && c.industry === 'Finance') return true;
      if (isConsultingQuery && c.industry === 'Consulting') return true;
      return false;
    });

    // 2. Opportunities Matching
    const matchedOpportunities = opportunities.filter(o => {
      if (o.title.toLowerCase().includes(q)) return true;
      if (o.companyName.toLowerCase().includes(q)) return true;
      if (o.requiredSkills.some(s => s.toLowerCase().includes(q))) return true;
      if (o.preferredSkills.some(s => s.toLowerCase().includes(q))) return true;
      if (o.location.toLowerCase().includes(q)) return true;
      if (isInternshipQuery && (o.type === 'Internship' || o.type === 'Full-time Job')) return true;
      if (isFinanceQuery && o.industry === 'Finance') return true;
      if (isConsultingQuery && o.industry === 'Consulting') return true;
      if (isTechQuery && o.industry === 'Technology') return true;
      return false;
    });

    // 3. Skills Matching
    const matchedSkills = skills.filter(s => {
      if (s.name.toLowerCase().includes(q)) return true;
      if (s.category.toLowerCase().includes(q)) return true;
      if (s.relatedCareers.some(c => c.toLowerCase().includes(q))) return true;
      return false;
    });

    // 4. Careers Matching
    const matchedCareers = careers.filter(c => {
      if (c.title.toLowerCase().includes(q)) return true;
      if (c.industry.toLowerCase().includes(q)) return true;
      if (c.requiredCoreSkills.some(s => s.toLowerCase().includes(q))) return true;
      return false;
    });

    // 5. Institutions Matching
    const matchedInstitutions = institutions.filter(i => {
      if (i.name.toLowerCase().includes(q)) return true;
      if (i.city.toLowerCase().includes(q)) return true;
      if (i.code && i.code.toLowerCase().includes(q)) return true;
      return false;
    });

    return {
      companies: matchedCompanies.slice(0, 6),
      opportunities: matchedOpportunities.slice(0, 6),
      skills: matchedSkills.slice(0, 6),
      careers: matchedCareers.slice(0, 4),
      institutions: matchedInstitutions.slice(0, 4)
    };
  }, [searchQuery, companies, opportunities, skills, careers, institutions]);

  if (!isOpen) return null;

  const totalResultsCount = 
    searchResults.companies.length + 
    searchResults.opportunities.length + 
    searchResults.skills.length + 
    searchResults.careers.length + 
    searchResults.institutions.length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-start justify-center p-4 sm:p-6 pt-12 sm:pt-20">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Search Header */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-indigo-600 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Try 'Google internships', 'Finance internships', 'C++', or 'Manipal'..."
            className="w-full text-sm sm:text-base outline-hidden text-slate-900 placeholder:text-slate-400 bg-transparent font-medium"
            autoFocus
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button 
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-md text-xs font-mono px-2 py-1 bg-slate-100 border border-slate-200"
          >
            ESC
          </button>
        </div>

        {/* Quick Filter Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-100 bg-slate-50/70 overflow-x-auto text-xs">
          <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filter:
          </span>
          {[
            { id: 'all', label: `All (${totalResultsCount})` },
            { id: 'companies', label: `Companies (${searchResults.companies.length})` },
            { id: 'opportunities', label: `Opportunities (${searchResults.opportunities.length})` },
            { id: 'skills', label: `Skills (${searchResults.skills.length})` },
            { id: 'careers', label: `Careers (${searchResults.careers.length})` },
            { id: 'institutions', label: `Institutions (${searchResults.institutions.length})` }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedFilter(tab.id as any)}
              className={`px-2.5 py-1 rounded-md transition font-semibold shrink-0 ${
                selectedFilter === tab.id
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Unified Results Container */}
        <div className="max-h-[65vh] overflow-y-auto p-4 space-y-6">
          {totalResultsCount === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm font-semibold text-slate-700">No matching entities found</p>
              <p className="text-xs text-slate-400 mt-1">Try broad terms like "Technology", "Consulting", "Python", or "Internships"</p>
            </div>
          ) : (
            <>
              {/* Opportunities Section */}
              {(selectedFilter === 'all' || selectedFilter === 'opportunities') && searchResults.opportunities.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Briefcase className="w-3.5 h-3.5 text-indigo-600" /> Opportunities & Internships
                    </span>
                    <span className="text-[11px] text-slate-400">{searchResults.opportunities.length} found</span>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {searchResults.opportunities.map((opp) => (
                      <div
                        key={opp.id}
                        onClick={() => {
                          onSelectEntity('opportunity', opp);
                          onClose();
                        }}
                        className="p-3 rounded-xl border border-slate-200 hover:border-indigo-500 hover:shadow-xs bg-white cursor-pointer transition flex flex-col justify-between group"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition">
                              {opp.title}
                            </span>
                            <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded shrink-0">
                              {opp.type}
                            </span>
                          </div>
                          <p className="text-[11px] font-medium text-slate-600 mt-0.5">{opp.companyName} · {opp.location}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {opp.requiredSkills.slice(0, 3).map((s, idx) => (
                              <span key={idx} className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                          <span className="font-semibold text-emerald-700">{opp.stipendOrSalary.split('+')[0]}</span>
                          <span className="group-hover:translate-x-0.5 transition flex items-center gap-0.5 text-indigo-600 font-semibold">
                            View <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Companies Section */}
              {(selectedFilter === 'all' || selectedFilter === 'companies') && searchResults.companies.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-indigo-600" /> Companies Ecosystem
                    </span>
                    <span className="text-[11px] text-slate-400">{searchResults.companies.length} found</span>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-2">
                    {searchResults.companies.map((comp) => (
                      <div
                        key={comp.id}
                        onClick={() => {
                          onSelectEntity('company', comp);
                          onClose();
                        }}
                        className="p-3 rounded-xl border border-slate-200 hover:border-indigo-500 hover:shadow-xs bg-white cursor-pointer transition flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2.5 overflow-hidden">
                          <div className={`w-8 h-8 rounded-lg ${comp.logoBg} text-white flex items-center justify-center font-bold text-xs shrink-0`}>
                            {comp.logoText}
                          </div>
                          <div className="truncate">
                            <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 truncate transition">
                              {comp.name}
                            </p>
                            <p className="text-[10px] text-slate-500">{comp.industry} · {comp.activeOpportunitiesCount} open</p>
                          </div>
                        </div>
                        <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 shrink-0" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Careers Section */}
              {(selectedFilter === 'all' || selectedFilter === 'careers') && searchResults.careers.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Career Pathways
                    </span>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {searchResults.careers.map((career) => (
                      <div
                        key={career.id}
                        onClick={() => {
                          onSelectEntity('career', career);
                          onClose();
                        }}
                        className="p-3 rounded-xl border border-slate-200 hover:border-indigo-500 hover:shadow-xs bg-white cursor-pointer transition group"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition">
                            {career.title}
                          </span>
                          <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded">
                            {career.industryDemandScore}% Demand
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{career.summary}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Skills Section */}
              {(selectedFilter === 'all' || selectedFilter === 'skills') && searchResults.skills.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-indigo-600" /> Skills & Evidence
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {searchResults.skills.map((skill) => (
                      <button
                        key={skill.id}
                        onClick={() => {
                          onSelectEntity('skill', skill);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50/80 hover:bg-indigo-50 hover:border-indigo-300 text-slate-700 hover:text-indigo-700 text-xs font-semibold flex items-center gap-1.5 transition"
                      >
                        <span>{skill.name}</span>
                        <span className="text-[10px] text-slate-400 font-normal">({skill.category})</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Institutions Section */}
              {(selectedFilter === 'all' || selectedFilter === 'institutions') && searchResults.institutions.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <GraduationCap className="w-3.5 h-3.5 text-indigo-600" /> Institutions Registry
                    </span>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {searchResults.institutions.map((inst) => (
                      <div
                        key={inst.id}
                        onClick={() => {
                          onSelectEntity('institution', inst);
                          onClose();
                        }}
                        className="p-3 rounded-xl border border-slate-200 hover:border-indigo-500 bg-white cursor-pointer transition flex items-center justify-between group"
                      >
                        <div>
                          <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition">
                            {inst.name}
                          </p>
                          <p className="text-[11px] text-slate-500">{inst.city}, {inst.country} · {inst.officialEmailDomains[0]}</p>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                          {inst.verificationStatus}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Searching 100+ Enterprise Employers & Top Global Universities</span>
          <span className="font-mono text-[11px]">SkillOrbit Enterprise v2.4</span>
        </div>
      </div>
    </div>
  );
};
