import React, { useState } from 'react';
import { 
  Bookmark, 
  Send, 
  FileCheck2, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Calendar, 
  Edit3, 
  Plus, 
  ArrowRight,
  Filter,
  MessageSquare
} from 'lucide-react';
import { ApplicationRecord, ApplicationStatus } from '../types';

interface ApplicationTrackerProps {
  applications: ApplicationRecord[];
  onUpdateStatus: (applicationId: string, newStatus: ApplicationStatus, notes?: string) => void;
  onNavigateToOpportunities: () => void;
}

export const ApplicationTracker: React.FC<ApplicationTrackerProps> = ({
  applications,
  onUpdateStatus,
  onNavigateToOpportunities
}) => {
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('All');
  const [editingApp, setEditingApp] = useState<ApplicationRecord | null>(null);
  const [newStatus, setNewStatus] = useState<ApplicationStatus>('Applied');
  const [notesInput, setNotesInput] = useState('');

  const statuses: ApplicationStatus[] = [
    'Saved',
    'Applied',
    'Assessment',
    'Interview',
    'Selected',
    'Rejected',
    'Withdrawn'
  ];

  const filteredApps = applications.filter(app => 
    selectedStatusFilter === 'All' || app.status === selectedStatusFilter
  );

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingApp) return;

    onUpdateStatus(editingApp.id, newStatus, notesInput.trim());
    setEditingApp(null);
  };

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'Selected':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Interview':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'Assessment':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Applied':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Saved':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      case 'Rejected':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'Withdrawn':
        return 'bg-slate-100 text-slate-500 border-slate-200';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Placement Pipeline
            </span>
            <span className="text-xs text-slate-500 font-medium">
              End-to-End Recruitment Tracking
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Application Pipeline Tracker
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Monitor interview invitations, online assessment deadlines, technical coding rounds, and final job offers.
          </p>
        </div>

        <button
          onClick={onNavigateToOpportunities}
          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-1.5"
        >
          <span>Explore More Openings</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs flex items-center gap-1.5 overflow-x-auto text-xs">
        <button
          onClick={() => setSelectedStatusFilter('All')}
          className={`px-3 py-1.5 rounded-lg font-bold transition ${
            selectedStatusFilter === 'All' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          All Applications ({applications.length})
        </button>
        {statuses.map(st => {
          const count = applications.filter(a => a.status === st).length;
          return (
            <button
              key={st}
              onClick={() => setSelectedStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg font-semibold transition shrink-0 ${
                selectedStatusFilter === st ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {st} ({count})
            </button>
          );
        })}
      </div>

      {/* Applications List */}
      {filteredApps.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <p className="text-sm font-semibold text-slate-700">No applications in this category</p>
          <p className="text-xs text-slate-400 mt-1">Apply to opportunities or save them to your active tracker pipeline.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredApps.map((app) => (
            <div
              key={app.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {app.companyName}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                      {app.opportunityTitle}
                    </h3>
                  </div>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(app.status)}`}>
                    {app.status}
                  </span>
                </div>

                <div className="mt-3 text-xs text-slate-500 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>Applied on: <strong>{app.appliedDate}</strong></span>
                  </div>
                  {app.nextDeadline && (
                    <div className="flex items-center gap-1.5 text-indigo-700 font-semibold">
                      <Clock className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Next Round: <strong>{app.nextDeadline}</strong></span>
                    </div>
                  )}
                </div>

                {/* Candidate Notes */}
                {app.notes && (
                  <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 flex items-start gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <p className="italic">"{app.notes}"</p>
                  </div>
                )}
              </div>

              {/* Action */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">
                  Updated: {app.lastStatusUpdate}
                </span>
                <button
                  onClick={() => {
                    setEditingApp(app);
                    setNewStatus(app.status);
                    setNotesInput(app.notes || '');
                  }}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Update Status</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Status Modal */}
      {editingApp && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Update Stage: {editingApp.opportunityTitle}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{editingApp.companyName}</p>
              </div>
              <button 
                onClick={() => setEditingApp(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Recruitment Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as ApplicationStatus)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800 font-medium"
                >
                  {statuses.map(st => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Round Notes / Preparation Items</label>
                <textarea
                  rows={3}
                  placeholder="e.g. Cleared Hackerrank round (100%), System design scheduled for Thursday..."
                  value={notesInput}
                  onChange={(e) => setNotesInput(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800 outline-hidden focus:border-indigo-600"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingApp(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition shadow-xs"
                >
                  Save Pipeline Progress
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
