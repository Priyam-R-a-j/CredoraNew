import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Compass, 
  Briefcase, 
  Building2, 
  Handshake, 
  TrendingUp, 
  Lock, 
  ChevronDown, 
  ChevronUp, 
  Award,
  Users,
  GraduationCap,
  FileCheck2,
  ExternalLink
} from 'lucide-react';
import { Company, Opportunity, CareerPath } from '../types';

interface LandingPageProps {
  onGetStarted: () => void;
  onExploreOpportunities: () => void;
  companies: Company[];
  opportunities: Opportunity[];
  careers: CareerPath[];
  onSelectOpportunity: (opp: Opportunity) => void;
  onSelectCompany: (company: Company) => void;
  onNavigateToView: (view: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onExploreOpportunities,
  companies,
  opportunities,
  careers,
  onSelectOpportunity,
  onSelectCompany,
  onNavigateToView
}) => {
  const [openFaqIdx, setOpenFaqIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does SkillOrbit calculate my opportunity match score?',
      a: 'SkillOrbit employs a transparent 5-pillar matching engine: Skills Fit (40%), Education & Degree Level (20%), Project/Internship Experience (20%), Work Mode/Location Fit (10%), and Academic Eligibility (10%). We never hide behind a black-box percentage; every score itemizes exactly which skills matched and which are missing.'
    },
    {
      q: 'Why are skill proficiencies evidence-backed instead of self-rated?',
      a: 'Self-reported star ratings are unreliable for enterprise recruiters. On SkillOrbit, candidates attach verifiable evidence: public GitHub repositories, industry certification IDs, proctored coding assessments, or university semester grade sheets. Recruiters can audit proofs directly.'
    },
    {
      q: 'How does SkillOrbit protect student data and privacy?',
      a: 'We adhere to strict data minimization. We do not store raw government identification numbers on public servers. Verification is performed using cryptographically signed institutional SSO tokens. Students have granular control over recruiter visibility and contact permissions.'
    },
    {
      q: 'How do universities and companies co-sponsor capstone projects?',
      a: 'Engineering and business departments review and approve industry problem statements submitted by Fortune 500 companies. Student teams apply directly, receive industry mentorship from principal architects, and deliver production code or research papers that earn formal academic credits.'
    }
  ];

  return (
    <div className="space-y-24 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-12 sm:pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            {/* Left Copy */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full text-xs font-bold text-indigo-700">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
                <span>Next-Generation Career Intelligence & Skill Architecture</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.1]">
                Navigate your skills. <br />
                <span className="text-indigo-600">Discover your next</span> opportunity.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
                SkillOrbit connects university students, institutional placement cells, and global employers through verified skill graphs, transparent match scoring, and real-world industry capstones.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={onGetStarted}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition shadow-md shadow-indigo-600/20 flex items-center gap-2"
                >
                  <span>Get Started with University SSO</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={onExploreOpportunities}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm px-6 py-3.5 rounded-xl transition border border-slate-200"
                >
                  Explore 100+ Opportunities
                </button>
              </div>

              <div className="flex items-center gap-6 pt-4 text-xs font-semibold text-slate-500">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Institutional Domain Verification</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  <span>Transparent Match Rationale</span>
                </div>
              </div>
            </div>

            {/* Right Interactive Preview Widget */}
            <div className="lg:col-span-5 relative">
              <div className="relative bg-white rounded-3xl border border-slate-200 p-6 shadow-xl space-y-5">
                {/* Header of widget */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white font-black flex items-center justify-center text-xs">
                      AS
                    </div>
                    <div>
                      <h2 className="text-xs font-bold text-slate-900">Aarav Sharma</h2>
                      <p className="text-[11px] text-slate-500">Manipal University Jaipur · BTech CSE</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Verified
                  </span>
                </div>

                {/* Placement Readiness Gauge */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2">
                  <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                    <span>Placement Readiness Index</span>
                    <span className="text-indigo-600 font-mono text-sm">78%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full w-[78%]" />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>Technical: 88%</span>
                    <span>Evidence: 72%</span>
                    <span>Profile: 78%</span>
                  </div>
                </div>

                {/* Simulated Opportunity Card */}
                <div className="p-4 rounded-2xl border border-indigo-200 bg-indigo-50/40 space-y-2.5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-red-600 text-white font-black text-xs flex items-center justify-center">
                        GO
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">Software Engineering Intern</div>
                        <div className="text-[10px] text-slate-500">Google / Alphabet · Summer 2026</div>
                      </div>
                    </div>
                    <span className="text-xs font-extrabold text-emerald-700 bg-white border border-emerald-200 px-2 py-0.5 rounded-full">
                      88% Match
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-600 bg-white/80 p-2 rounded-lg border border-indigo-100">
                    <strong>Why it matches:</strong> Possesses verified Go, Python, and Algorithmic problem solving.
                  </div>
                </div>

                <div className="pt-2 text-center">
                  <span className="text-[11px] font-semibold text-slate-400">
                    Live candidate orbit simulation
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. HOW SKILLORBIT WORKS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded">
            Integrated Lifecycle
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            How SkillOrbit Works
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            A continuous loop uniting student learning, institutional credentials, and enterprise recruitment.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          {[
            {
              step: '01',
              title: 'Map Verified Skills',
              desc: 'Attach code repositories, certification IDs, or university grades to create an evidence-backed skill constellation.'
            },
            {
              step: '02',
              title: 'Discover Target Careers',
              desc: 'Inspect typical career trajectories, compensation benchmarks, and exact skill requirements across Tech, Finance, and Consulting.'
            },
            {
              step: '03',
              title: 'Transparent Matching',
              desc: 'Explore internships and jobs with clear rationale: why you match, your scores across 5 pillars, and exactly what to improve.'
            },
            {
              step: '04',
              title: 'Campus & Industry Capstones',
              desc: 'Participate in accredited university-industry research challenges mentored by Fortune 500 engineering directors.'
            }
          ].map((item, idx) => (
            <div key={idx} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs relative">
              <span className="text-2xl font-black text-indigo-200 font-mono block mb-2">{item.step}</span>
              <h3 className="text-sm font-bold text-slate-900 mb-1">{item.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. SKILL INTELLIGENCE & CONSTELLATION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-white overflow-hidden relative">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-5">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 bg-indigo-950 border border-indigo-800 px-3 py-1 rounded-full">
                Evidence-Backed Credentialing
              </span>
              <h2 className="text-3xl sm:text-4xl font-black tracking-tight leading-tight">
                Skill Intelligence & Verification Engine
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                SkillOrbit replaces unverified 5-star self-ratings with verifiable proof. Whether you demonstrate distributed systems in a public GitHub repository or quantitative modeling through a university capstone, your proficiency badge is permanently anchored in evidence.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700">
                  <span className="text-2xl font-extrabold text-indigo-400 block font-mono">10</span>
                  <span className="text-xs text-slate-300 font-semibold">Core Skill Categories</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700">
                  <span className="text-2xl font-extrabold text-emerald-400 block font-mono">5 Levels</span>
                  <span className="text-xs text-slate-300 font-semibold">Beginner to Expert Badging</span>
                </div>
              </div>

              <button
                onClick={() => onNavigateToView('skillmap')}
                className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-3 rounded-xl transition shadow-xs flex items-center gap-2"
              >
                <span>Explore the Skill Map</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {[
                { name: 'Python Engineering', level: 'Advanced (85/100)', verified: true, proof: 'GitHub Repository + 120 Stars' },
                { name: 'Data Structures & Algorithms', level: 'Advanced (88/100)', verified: true, proof: 'MUJ Coursework (Grade A+)' },
                { name: 'PostgreSQL Relational Design', level: 'Intermediate (72/100)', verified: true, proof: 'Production E-Commerce Backend' },
                { name: 'Cloud Native (Kubernetes)', level: 'Intermediate (68/100)', verified: true, proof: 'Istio Service Mesh Capstone' }
              ].map((s, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-slate-800/90 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{s.name}</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-[11px] font-semibold text-indigo-300">{s.level}</div>
                  <div className="text-[10px] text-slate-400 font-mono truncate">Proof: {s.proof}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 4. CAREER DISCOVERY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded">
              Career Trajectories
            </span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight mt-2">
              Career Compass & Trajectory Navigation
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
              Evaluate real market compensation, demand indicators, and step-by-step milestone roadmaps for premier tech, finance, and consulting tracks.
            </p>
          </div>
          <button
            onClick={() => onNavigateToView('careercompass')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 self-start md:self-auto"
          >
            <span>Compare all trajectories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {careers.slice(0, 3).map((career) => (
            <div key={career.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold uppercase tracking-wider text-indigo-600">{career.industry}</span>
                  <span className="text-emerald-700 font-extrabold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {career.industryDemandScore}/100 Demand
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-2">{career.title}</h3>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">{career.summary}</p>

                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500">
                  <span>Entry Comp: <strong className="text-slate-900">{career.averageStartingSalary}</strong></span>
                </div>
              </div>

              <button
                onClick={() => onNavigateToView('careercompass')}
                className="mt-5 w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold py-2 rounded-xl transition"
              >
                Inspect Trajectory
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 5. VERIFIED COMPANY ECOSYSTEM */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded">
              Enterprise Network
            </span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight mt-2">
              100+ Premier Employers in Technology, Finance & Consulting
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-xl mt-1">
              Directly partner with top global brands and high-growth industry titans participating in campus placement drives.
            </p>
          </div>
          <button
            onClick={() => onNavigateToView('companies')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 self-start md:self-auto"
          >
            <span>View all 100+ companies</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {companies.slice(0, 12).map((comp) => (
            <div
              key={comp.id}
              onClick={() => onSelectCompany(comp)}
              className="bg-white rounded-xl border border-slate-200 p-3.5 text-center hover:border-indigo-500 hover:shadow-xs transition cursor-pointer group"
            >
              <div className={`w-10 h-10 rounded-xl ${comp.logoBg} text-white font-black text-xs flex items-center justify-center mx-auto shadow-2xs group-hover:scale-105 transition-transform`}>
                {comp.logoText}
              </div>
              <h4 className="text-xs font-bold text-slate-900 mt-2 truncate group-hover:text-indigo-600">
                {comp.name}
              </h4>
              <span className="text-[10px] text-slate-500 block truncate">{comp.industry}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 6. UNIVERSITY-INDUSTRY COLLABORATIONS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-indigo-900 rounded-3xl p-8 sm:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 bg-indigo-950 px-3 py-1 rounded-full">
                Sponsorship & Research
              </span>
              <h2 className="text-3xl font-black tracking-tight leading-tight">
                University–Industry Capstones & Challenges
              </h2>
              <p className="text-sm text-indigo-100 leading-relaxed">
                Connect academic curriculum with real enterprise problems. Engineering and business student teams collaborate on sponsored projects with senior mentors from NVIDIA, JPMorgan Chase, Google, and McKinsey.
              </p>
              <button
                onClick={() => onNavigateToView('collaborations')}
                className="bg-white hover:bg-slate-100 text-indigo-950 font-bold text-xs px-5 py-3 rounded-xl transition shadow-xs flex items-center gap-2"
              >
                <span>Explore Sponsoring Challenges</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-indigo-950/80 border border-indigo-800">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-white">NVIDIA × Manipal University Jaipur</span>
                  <span className="text-emerald-400 font-bold">₹90,000 Grant</span>
                </div>
                <p className="text-xs text-indigo-200 font-medium">Distributed LLM Inference Pipeline Optimization on CUDA</p>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-950/80 border border-indigo-800">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-white">JPMorgan Chase × MAHE</span>
                  <span className="text-emerald-400 font-bold">₹85,000 Grant</span>
                </div>
                <p className="text-xs text-indigo-200 font-medium">Ultra-Low-Latency Order Book Engine in Modern C++20</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. SECURITY & PRIVACY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 sm:p-12">
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-white border border-slate-200 px-2.5 py-1 rounded">
              Compliance & Security
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Privacy by Design & Data Minimization
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Enterprise-grade safeguards built to protect student data, institutional accreditation records, and recruiter relationships.
            </p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">Zero Raw ID Storage</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                We never store government identification documents or raw student roll records. Authentication is handled via signed institutional tokens.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">Granular Recruiter Controls</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Students maintain full authority to toggle recruiter discovery on or off, and require explicit permission before direct interview contacts.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">Immutable Audit Logs</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Every enterprise access request, verification check, and administrative action is recorded in an immutable audit trail with masked client IPs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. FREQUENTLY ASKED QUESTIONS */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded">
            Got Questions?
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaqIdx === idx;
            return (
              <div key={idx} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
                <button
                  onClick={() => setOpenFaqIdx(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-slate-900 hover:bg-slate-50 transition"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />}
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. CALL TO ACTION BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-950 rounded-3xl p-8 sm:p-14 text-center text-white space-y-6 relative overflow-hidden">
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight max-w-2xl mx-auto">
            Ready to Navigate Your Skill Orbit?
          </h2>
          <p className="text-sm text-indigo-200 max-w-xl mx-auto">
            Join thousands of students and 100+ verified enterprise talent partners on SkillOrbit today.
          </p>
          <div className="flex flex-wrap justify-center items-center gap-4">
            <button
              onClick={onGetStarted}
              className="bg-white hover:bg-slate-100 text-indigo-950 font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition shadow-lg flex items-center gap-2"
            >
              <span>Verify Institutional Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigateToView('help')}
              className="bg-indigo-800/60 hover:bg-indigo-800 text-white font-semibold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition border border-indigo-700"
            >
              Visit Help Center
            </button>
          </div>
        </div>
      </section>

      {/* 10. COMPREHENSIVE ENTERPRISE FOOTER */}
      <footer className="border-t border-slate-200 bg-white pt-12 text-slate-600 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div className="col-span-2 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white font-black flex items-center justify-center text-xs">
                  SO
                </div>
                <span className="text-base font-extrabold text-slate-900 tracking-tight">
                  Skill<span className="text-indigo-600">Orbit</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
                SkillOrbit is the career intelligence, skill mapping, internship discovery, placement readiness, and university-industry collaboration platform.
              </p>
              <div className="text-[11px] text-slate-400 font-mono">
                Engine v2.4.0 · SOC-2 Compliant Architecture · TLS 1.3
              </div>
            </div>

            <div>
              <h3 className="font-bold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Platform</h3>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigateToView('dashboard')} className="hover:text-indigo-600">Career Command Center</button></li>
                <li><button onClick={() => onNavigateToView('skillmap')} className="hover:text-indigo-600">Skill Constellation</button></li>
                <li><button onClick={() => onNavigateToView('careercompass')} className="hover:text-indigo-600">Career Trajectories</button></li>
                <li><button onClick={() => onNavigateToView('opportunities')} className="hover:text-indigo-600">Verified Opportunities</button></li>
                <li><button onClick={() => onNavigateToView('collaborations')} className="hover:text-indigo-600">University Capstones</button></li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Ecosystem</h3>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigateToView('companies')} className="hover:text-indigo-600">100+ Enterprise Directory</button></li>
                <li><button onClick={() => onNavigateToView('industrypulse')} className="hover:text-indigo-600">Industry Pulse Trends</button></li>
                <li><button onClick={() => onNavigateToView('university_dashboard')} className="hover:text-indigo-600">University Admin Portal</button></li>
                <li><button onClick={() => onNavigateToView('recruiter_dashboard')} className="hover:text-indigo-600">Corporate Recruiter Portal</button></li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-slate-900 mb-3 uppercase tracking-wider text-[11px]">Governance</h3>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigateToView('help')} className="hover:text-indigo-600">Help & Knowledge Base</button></li>
                <li><button onClick={() => onNavigateToView('admin_panel')} className="hover:text-indigo-600">Security Audit Logs</button></li>
                <li><span className="text-slate-400">Data Minimization Policy</span></li>
                <li><span className="text-slate-400">Accreditation Standards</span></li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 pb-8">
            <p>© {new Date().getFullYear()} SkillOrbit Platform. All rights reserved.</p>
            <p>Institutional Partner: Manipal University Jaipur & Global University Consortium</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
