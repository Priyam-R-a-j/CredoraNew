import React, { useState } from 'react';
import { 
  TrendingUp, 
  BarChart3, 
  Building2, 
  Clock, 
  Calendar, 
  ShieldCheck, 
  ArrowUpRight, 
  Filter,
  Info
} from 'lucide-react';
import { INDUSTRY_PULSE_DATA } from '../data/industryPulse';

export const IndustryPulseView: React.FC = () => {
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');

  const filteredMetrics = INDUSTRY_PULSE_DATA.filter(m => 
    selectedIndustry === 'All' || m.industry === selectedIndustry
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Talent Intelligence Index
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Quarterly Verified Enterprise Trends
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Industry Pulse & Hiring Demand
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Aggregated hiring volume metrics, skill growth velocity, and employer demand patterns across Technology, Financial Services, and Management Consulting.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200">
          <Clock className="w-4 h-4 text-emerald-600" />
          <span>Refreshed: Q2–Q3 2026 Enterprise Census</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold">
          {['All', 'Technology', 'Finance', 'Consulting'].map((ind) => (
            <button
              key={ind}
              onClick={() => setSelectedIndustry(ind)}
              className={`px-3 py-1.5 rounded-lg transition ${
                selectedIndustry === ind
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {ind}
            </button>
          ))}
        </div>
        <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
          Methodology: Direct enterprise ATS & campus drive filings
        </span>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMetrics.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {item.industry} · {item.category}
                </span>
                <span className={`text-xs font-extrabold px-2 py-0.5 rounded-full border ${
                  item.demandIndex === 'Critical Demand' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                  item.demandIndex === 'Surging Demand' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                  'bg-emerald-50 text-emerald-700 border-emerald-200'
                }`}>
                  {item.demandIndex}
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900 mt-2">
                {item.skillOrRole}
              </h3>

              <div className="flex items-baseline gap-2 mt-3">
                <span className="text-2xl font-black text-emerald-600">
                  +{item.growthRatePercent}%
                </span>
                <span className="text-xs text-slate-500 font-medium">YoY hiring growth</span>
              </div>

              <div className="mt-2 text-xs text-slate-600">
                Estimated Open Postings: <strong className="text-slate-900">{item.openPositionsEstimated.toLocaleString()}</strong>
              </div>

              {/* Top Hiring Companies */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                  Top Employers Actively Hiring
                </span>
                <div className="flex flex-wrap gap-1">
                  {item.topHiringCompanies.map((c, idx) => (
                    <span key={idx} className="text-[10px] bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Methodology & Citation */}
            <div className="mt-5 pt-3 border-t border-slate-100 text-[10px] text-slate-400 flex items-center justify-between">
              <span className="truncate">{item.source}</span>
              <span className="shrink-0 font-mono font-medium">{item.dataPeriod}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Methodology Explainer Box */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 flex items-start gap-4">
        <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-600 space-y-1">
          <h4 className="font-bold text-slate-900 text-sm">Transparent Methodology & Data Governance</h4>
          <p className="leading-relaxed">
            SkillOrbit calculates industry pulse indicators by synthesizing quarterly campus recruitment reports from accredited university career cells, verified job descriptions from registered enterprise partners, and proctored student capability benchmarks.
          </p>
          <p className="text-[11px] text-slate-400">
            Data periods: Q2 2026 to Q3 2026. No synthetic scrapers or unverified scraping heuristics are utilized.
          </p>
        </div>
      </div>
    </div>
  );
};
